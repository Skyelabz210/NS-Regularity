# bridge-engine: Output Protocol

Every output produced while operating from this stance obeys these rules. They follow directly from the operational axioms, not from convention.

## Format mandate

Plain markdown unless aesthetics are explicitly requested for a specific stated purpose. Raw text must carry full information without rendering. No dependency chain. No parser required. Any agent, any device, any environment. If an output requires a specific tool to read, it has failed before it was opened.

## Epistemic status (inline, always)

Every substantive claim carries its status inline, adjacent to the claim. Not in a separate section. If you read the claim, you see its status.

| Status | Meaning | What you can do with it |
|--------|---------|------------------------|
| FOUNDATION | Formally established, zero-sorry proof or exhaustive verification | Build on it |
| VERIFIED | Computationally confirmed, tests pass | Use it |
| MEASURED | Observed and recorded | Track it |
| ARGUED | Reasoning exists, not yet tested | Probe it |
| OPEN | Not yet resolved — Resistance Protocol applies | Reformulate |
| CLOSED | Boundary established, result replaced or refuted | Map it |

## Failures: adjacent to claims

Every failure mode lives next to the claim it constrains. Not in a separate "honest negatives" or "limitations" section. If you read the claim, you see what failed when it was attempted and why. A failure separated from its claim is a failure waiting to be re-encountered.

## Forward tracing: inline

Every substantive result states what it enables, inline. "This result satisfies the L² input requirement for Aubin-Lions Step D.1.1." Not in a different section. If "enables" is blank, the result has not been fully processed — that blank is a flag.

## Boundary documentation

When something cannot yet be closed, record:
1. The specific element that generated the stop (named precisely)
2. What was tried
3. What the base elements are when the stop is decomposed
4. The question formulation that would dissolve it if answered

"Open question" and "future work" are not acceptable. They are parking lots. Every undissolved boundary is an entry point described with enough precision that any agent can pick it up and apply the Resistance Protocol without reconstruction from scratch.

## Delta

Every versioned document carries a delta: what changed from the prior version, what was added, what was formally closed, what was refuted. The delta is the first section after the purpose statement. Without it, two documents from different sessions look identical in structure even when their content has diverged.

## Document purpose

Every document opens with what it enables, not what it is. "This document enables [specific action]." One sentence. The rest is reference.

## What is not present

No aesthetic elements without explicit purpose request. No section headers that exist only for visual spacing. No decorative dividers. No words that carry no information. Every formatting choice either aids machine parsing or aids rapid human scanning of dense content. No other justification exists.
