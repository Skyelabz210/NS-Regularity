# bridge-engine: Decomposition as Epistemology

Why the tao-blueprint approach works on problems that resist every direct approach. This is the mechanism, not just the method.

## The structural argument

When a problem is incompletely decomposed, the nodes you see are the ones whose connection to the goal is visible. You work on those. When you get stuck on one of them, you have no other entry point. The decomposition limits your attack surface.

When a problem is completely decomposed, you have the full dependency graph. Every node is visible, including the ones whose connection to the goal is not yet understood. You work on the easiest available node — not because it looks important, but because it's closeable. When you close it, the dependency graph updates. Some nodes that were locked become available. Some nodes that looked independent turn out to share a dependency with the node you just closed. The attack surface expands with every closed node.

Non-linear closing amplifies this. If you close nodes in order of apparent importance, you are using the decomposition as an outline — a more organized version of the direct approach. If you close nodes in order of closability, regardless of apparent importance, you are using the decomposition as an epistemological instrument. Each closed node is evidence about the shape of the problem space. You accumulate structural knowledge faster than you accumulate solutions to specific nodes.

## The worked structural example

A problem has ten unknown components, A through J. You do not know how they relate. You decompose and find:
- A depends on B and C
- D depends on A and E
- F depends on B and G
- The goal requires D and F

You cannot close A (needs B, C). You cannot close D (needs A, E). You cannot close F (needs B, G).

You can close B, C, E, G — they have no unsatisfied dependencies. You close them in order of ease. Closing B unlocks both A and F. Closing C unlocks A. Closing E unlocks D (once A is closed). Closing G unlocks F (once B is closed).

At no point did you target D or F directly. You targeted closeable nodes. D and F became reachable as a consequence.

Critical observation: while closing B, you recognize it has the same structure as a problem from an entirely different domain solved previously. That prior solution provides a technique that also applies to G — which you had not yet examined. You close G with the same technique. F is now reachable two steps earlier than the roadmap predicted.

That cross-domain recognition was only possible because B and G were both in your decomposition. If you had only decomposed D and F — the apparent targets — you would never have seen B or G. The completeness of the decomposition is what made the connection available.

## Practical consequence

Never begin closing nodes before the decomposition is complete. An incomplete decomposition is an incomplete attack surface. The nodes that don't make it into an early decomposition are often the ones that, when closed, unlock everything else. You cannot know which ones those are until the decomposition is complete.

This is also why OPEN nodes in any active decomposition are not a sign of failure — they are the inventory of available attack surface. An OPEN node is not "stuck." It is waiting for a dependency to close. Working on any closeable node advances every OPEN node that shares a dependency with it.

## Domain-crossing as the primary value

The structural example above shows a connection discovered mid-decomposition. This is the general shape of every major advance produced by this process. The domains don't need to be adjacent. They need to share structure. The further apart the domains, the more likely that the constraint that blocked progress in one domain was never present in the other. That absent constraint is the tool.

A method that worked for synchronizing astronomical periods without drift over centuries (Maya calendar arithmetic) is the same method that works for tracking fluid vorticity without drift over infinite timesteps (exact integer Navier-Stokes). Neither domain would have generated this connection by looking only at itself. The connection required the structure to be recognized across the domain boundary, and the recognition required both structures to be present in the same decomposition at the same time.

Complete decomposition creates the conditions for this. Non-linear closing executes against those conditions. The connection is the output neither direct approach could have produced.
