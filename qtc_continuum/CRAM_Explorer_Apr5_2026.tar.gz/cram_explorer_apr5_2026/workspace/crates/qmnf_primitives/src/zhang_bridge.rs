//! # Zhang-QMNF Bridge: Exact Discrete Means via CRT Storage
//!
//! The running product C2 = prod p(p-2)/(p-1)^2 overflows u128 at ~25 primes.
//! Solution: CRT residues across lane primes (exact structure) + running f64 (display).
//! The CRT residues never overflow. Structural results use residues only.

pub fn ramanujan_sum(p: u64, d: u64) -> i64 {
    if d % p == 0 { p as i64 - 1 } else { -1 }
}

pub fn sieve_power(p: u64, d: u64) -> (u64, u64) {
    let c = ramanujan_sum(p, d);
    let num = (2 * p as i64 - 1 - c) as u64;
    let den = p * p;
    let g = crate::gcd(num, den);
    (num / g, den / g)
}

pub struct CrtProduct {
    pub num_residues: Vec<u64>,
    pub den_residues: Vec<u64>,
    pub lane_primes: Vec<u64>,
    pub ratio: f64,
    pub factor_count: usize,
}

impl CrtProduct {
    pub fn one(lane_primes: &[u64]) -> Self {
        CrtProduct {
            num_residues: vec![1; lane_primes.len()],
            den_residues: vec![1; lane_primes.len()],
            lane_primes: lane_primes.to_vec(),
            ratio: 1.0,
            factor_count: 0,
        }
    }

    pub fn mul_rational(&mut self, num: u64, den: u64) {
        for (i, &lp) in self.lane_primes.iter().enumerate() {
            self.num_residues[i] = crate::mulmod(self.num_residues[i], num % lp, lp);
            self.den_residues[i] = crate::mulmod(self.den_residues[i], den % lp, lp);
        }
        self.ratio *= num as f64 / den as f64;
        self.factor_count += 1;
    }

    pub fn ratio_f64(&self) -> f64 { self.ratio }

    pub fn exact_residues(&self) -> Vec<u64> {
        self.lane_primes.iter().enumerate().map(|(i, &lp)| {
            let den_inv = crate::mod_pow(self.den_residues[i], lp - 2, lp);
            crate::mulmod(self.num_residues[i], den_inv, lp)
        }).collect()
    }

    pub fn equals(&self, other: &CrtProduct) -> bool {
        if self.lane_primes != other.lane_primes { return false; }
        for (i, &lp) in self.lane_primes.iter().enumerate() {
            let lhs = crate::mulmod(self.num_residues[i], other.den_residues[i], lp);
            let rhs = crate::mulmod(other.num_residues[i], self.den_residues[i], lp);
            if lhs != rhs { return false; }
        }
        true
    }
}

pub fn twin_prime_constant_crt(primes: &[u64], lane_primes: &[u64]) -> CrtProduct {
    let mut product = CrtProduct::one(lane_primes);
    for &p in primes {
        if p < 3 || !crate::is_prime(p) { continue; }
        product.mul_rational(p * (p - 2), (p - 1) * (p - 1));
    }
    product
}

pub fn singular_series_crt(d: u64, primes: &[u64], lane_primes: &[u64]) -> CrtProduct {
    let mut product = twin_prime_constant_crt(primes, lane_primes);
    for (i, &lp) in product.lane_primes.iter().enumerate() {
        product.num_residues[i] = crate::mulmod(product.num_residues[i], 2, lp);
    }
    product.ratio *= 2.0;
    for &p in primes {
        if p < 3 || d % p != 0 || !crate::is_prime(p) { continue; }
        product.mul_rational(p - 1, p - 2);
    }
    product
}

pub fn sqr_carry(n: u64, disc_primes: &[u64]) -> Vec<u8> {
    disc_primes.iter().map(|&p| { let r = n % p; if r * r >= p { 1 } else { 0 } }).collect()
}

pub fn carry_stratified_density(lo: u64, hi: u64, d: u64, disc_primes: &[u64], primorial: u64) -> Vec<(Vec<u8>, u64, u64)> {
    use std::collections::BTreeMap;
    let mut bins: BTreeMap<Vec<u8>, (u64, u64)> = BTreeMap::new();
    for n in lo..hi {
        if crate::gcd(n, primorial) != 1 { continue; }
        let carry = sqr_carry(n, disc_primes);
        let e = bins.entry(carry).or_insert((0, 0));
        e.0 += 1;
        if crate::is_prime(n) && crate::is_prime(n + d) { e.1 += 1; }
    }
    bins.into_iter().map(|(c, (t, p))| (c, t, p)).collect()
}

pub fn non_uniformity_spread(strat: &[(Vec<u8>, u64, u64)], min_count: u64) -> f64 {
    let d: Vec<f64> = strat.iter().filter(|(_, c, _)| *c >= min_count)
        .map(|(_, c, p)| *p as f64 / *c as f64).collect();
    if d.is_empty() { return 0.0; }
    let max = d.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    let min = d.iter().cloned().fold(f64::INFINITY, f64::min);
    if min > 0.0 { max / min } else { f64::INFINITY }
}

#[cfg(test)]
mod tests {
    use super::*;
    const LANES: [u64; 7] = [998244353, 985661441, 754974721, 469762049, 167772161, 104857601, 69206017];
    const DISC: [u64; 3] = [7, 11, 13];

    #[test] fn test_ramanujan() { assert_eq!(ramanujan_sum(7, 14), 6); assert_eq!(ramanujan_sum(7, 3), -1); }
    #[test] fn test_sp() { assert_eq!(sieve_power(7, 2), (2, 7)); assert_eq!(sieve_power(7, 7), (1, 7)); }

    #[test] fn test_crt_basic() {
        let mut p = CrtProduct::one(&LANES); p.mul_rational(3, 4);
        assert!((p.ratio_f64() - 0.75).abs() < 1e-10);
    }

    #[test] fn test_c2_small() {
        let c2 = twin_prime_constant_crt(&[3, 5, 7], &LANES);
        assert!((c2.ratio_f64() - 0.6836).abs() < 0.001);
    }

    #[test] fn test_c2_p100() {
        let primes: Vec<u64> = (3..=100).filter(|&n| crate::is_prime(n)).collect();
        let c2 = twin_prime_constant_crt(&primes, &LANES);
        let gap = (c2.ratio_f64() - 0.6601618159).abs() / 0.6601618159 * 100.0;
        assert!(gap < 1.0, "gap = {:.4}%", gap);
    }

    #[test] fn test_c2_p1000_no_overflow() {
        let primes: Vec<u64> = (3..=1000).filter(|&n| crate::is_prime(n)).collect();
        let c2 = twin_prime_constant_crt(&primes, &LANES);
        assert!(c2.factor_count > 100, "Should have 168 primes");
        let gap = (c2.ratio_f64() - 0.6601618159).abs() / 0.6601618159 * 100.0;
        assert!(gap < 0.1, "gap = {:.6}%", gap);
    }

    #[test] fn test_c2_p10000_no_overflow() {
        let primes: Vec<u64> = (3..=10000).filter(|&n| crate::is_prime(n)).collect();
        let c2 = twin_prime_constant_crt(&primes, &LANES);
        assert!(c2.factor_count > 1000);
        let residues = c2.exact_residues();
        for &r in &residues { assert!(r > 0); }
    }

    #[test] fn test_convergence() {
        let c2_inf = 0.6601618159;
        for cutoff in [10u64, 100, 1000, 10000] {
            let primes: Vec<u64> = (3..=cutoff).filter(|&n| crate::is_prime(n)).collect();
            let c2 = twin_prime_constant_crt(&primes, &LANES);
            let gap = (c2.ratio_f64() - c2_inf).abs() / c2_inf * 100.0;
            assert!(gap < 10.0, "p<={} gap={:.2}%", cutoff, gap);
        }
    }

    #[test] fn test_ss_d2() {
        let primes: Vec<u64> = (3..=100).filter(|&n| crate::is_prime(n)).collect();
        let s = singular_series_crt(2, &primes, &LANES);
        let c2 = twin_prime_constant_crt(&primes, &LANES);
        let ratio = s.ratio_f64() / (2.0 * c2.ratio_f64());
        assert!((ratio - 1.0).abs() < 1e-8);
    }

    #[test] fn test_ss_d6() {
        let primes: Vec<u64> = (3..=100).filter(|&n| crate::is_prime(n)).collect();
        let s = singular_series_crt(6, &primes, &LANES);
        let c2 = twin_prime_constant_crt(&primes, &LANES);
        assert!((s.ratio_f64() / (2.0 * c2.ratio_f64()) - 2.0).abs() < 1e-8);
    }

    #[test] fn test_ss_d30() {
        let primes: Vec<u64> = (3..=100).filter(|&n| crate::is_prime(n)).collect();
        let s = singular_series_crt(30, &primes, &LANES);
        let c2 = twin_prime_constant_crt(&primes, &LANES);
        assert!((s.ratio_f64() / (2.0 * c2.ratio_f64()) - 8.0/3.0).abs() < 1e-8);
    }

    #[test] fn test_equality_exact() {
        let primes = vec![3u64, 5, 7, 11, 13];
        let a = twin_prime_constant_crt(&primes, &LANES);
        let b = twin_prime_constant_crt(&primes, &LANES);
        assert!(a.equals(&b));
    }

    #[test] fn test_carry_8bins() {
        let s = carry_stratified_density(7, 10000, 2, &DISC, 30);
        assert_eq!(s.len(), 8);
    }

    #[test] fn test_spread() {
        let s = carry_stratified_density(7, 10000, 2, &DISC, 30);
        assert!(non_uniformity_spread(&s, 50) > 1.3);
    }
}
