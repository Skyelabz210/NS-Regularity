# CRAM Explorer — April 5, 2026

Master workspace package for the QMNF research project.
Anthony Diaz (Acid) · HackFate.us / Skyelabz210 · San Antonio, Texas

## Contents

    workspace/          24 Rust crates · 706 tests · 0 failures
    session_tools/      4 Python scanning instruments (this session)
    docs/               Manifest + Tao Blueprint execution order (markdown)
    outputs/            Session plot outputs (PNG)

## Quick Start

    cd workspace
    cargo test --workspace \
      --skip test_bn_full_vs_skew \
      --skip test_bn_vs_n_campaign
    # Expected: 706 passed, 0 failed

    cd ../session_tools
    python3 qmnf_spectral_scanner.py
    python3 qmnf_lane_auditor.py
    python3 qmnf_precise_auditor.py
    python3 qmnf_shadow_disambiguator.py

## State at Package Time

- 24 crates, 706 tests, 0 failures
- DKAM subcriticality proved in Lean 4 (0 sorry on critical path)
- Ramanujan compliance: 95.4% mean, 99.6% at chimera erasure peaks  
- K-Elim lift architecture designed for N=32 Break A
- Aubin-Lions composition lemma: one step outstanding
- SD-11 Shadow Disambiguator: designed, not hardened

The crack is labeled 2 < 3.
