#!/usr/bin/env python3
"""
QMNF Shadow Disambiguator (SD-11)
===================================
Anthony Diaz (Acid) / HackFate.us / Skyelabz210 — April 5, 2026

MOTIVATION
----------
K-Elimination and CRAM are each used in many distinct contexts across
the QMNF stack. The formula is always:

    κ = (r_A - r_M) · M⁻¹  mod A

But κ might mean:

    ⌊X/M⌋ mod A        (exact RNS division — quotient extraction)
    winding on T²       (magnitude tracking in the NS solver)
    period of a^k mod N (Shor / BSGS)
    carry between lanes (CRAM internal propagation)
    oracle weight       (Grover marked-state amplitude)

In a heterogeneous pipeline where CRAM operators are different per lane,
an untagged κ that drifts from one use context to another is silent
corruption. It won't throw an exception. The arithmetic is still valid.
The *meaning* is wrong.

THE SHADOW DISAMBIGUATOR (SD-11)
---------------------------------
Uses prime p=11 (the T-SHADOW prime, unique across all five S-gates)
as the type system's universe.

The ×4 orbit on ℤ/11ℤ has order exactly 5 — matching the five S-gates:

    Orbit position k → type tag = 4^k mod 11:
      k=0  → tag=1   TYPE_QUOTIENT   ⌊X/M⌋ exact RNS division
      k=1  → tag=4   TYPE_WINDING    magnitude / winding on T²  ← shadow imprint
      k=2  → tag=5   TYPE_PERIOD     Shor / BSGS period orbit
      k=3  → tag=9   TYPE_CARRY      CRAM internal carry propagation
      k=4  → tag=3   TYPE_ORACLE     Grover oracle amplitude weight
      tag=0           TYPE_ZERO       period boundary / zero sentinel

These six states partition ℤ/11ℤ exhaustively:
    QR orbit {1,3,4,5,9} → typed operations
    tag=0                 → sentinel / boundary
    QNR {2,6,7,8,10}     → unregistered use (the probe fires here)

THE INSIDE RESIDUE LIFT (Hensel lift to ℤ/121ℤ)
-------------------------------------------------
When the shadow signature alone is ambiguous (two K-Elim results from
different contexts produce the same shadow signature), lift to ℤ/p²ℤ:

    κ_lifted = κ + 11 · orbit_position

This encodes the type context into the second p-adic digit of κ_lifted.
κ and its type tag are now inseparable in ℤ/121ℤ. The first digit
carries the residue arithmetic; the second digit carries the use class.

CROSS-LANE HETEROGENEITY CORRECTION
--------------------------------------
CRAM topologies are deliberately heterogeneous: different operators per
lane. When K-Elim's κ drifts from one lane's context to another's,
the shadow signature σ = κ mod 11 will be wrong for the target context.

Correction protocol:
    1. Compute σ_expected = type_tag(target_use_context)
    2. Compute σ_actual   = κ mod 11
    3. If σ_actual ∉ orbit AND σ_actual ≠ 0 → CONTAMINATION
    4. If σ_actual ∈ orbit but σ_actual ≠ σ_expected → CONTEXT_MISMATCH
    5. Apply lift correction: κ_corrected = κ + 11·(orbit_pos(σ_expected)
                                                    - orbit_pos(σ_actual)) mod 121

Why this works: the lift correction adjusts the type-context digit
without changing the base residue (κ mod 11 itself does not change —
only the second p-adic digit). The arithmetic content is preserved;
only the type disambiguation tag is corrected.
"""

from __future__ import annotations

import time
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Tuple, Set
from math import gcd


# ══════════════════════════════════════════════════════════════════════════════
# §0  SHADOW PRIME CONSTANTS — DERIVED FROM T-SHADOW THEOREM
# ══════════════════════════════════════════════════════════════════════════════

SHADOW_PRIME     = 11       # T-SHADOW unique prime (S1–S5 gates)
SHADOW_PRIME_SQ  = 121      # ℤ/121ℤ = ℤ/11²ℤ  — the lift target
SHADOW_IMPRINT   = 4        # 169 mod 11 = 4  (13² = boundary² casts onto shadow)
SHADOW_GENERATOR = 4        # ×4 is the orbit generator on ℤ/11ℤ
SHADOW_ORD       = 5        # ord_11(4) = 5  — number of type slots

# The five-slot type orbit: 4^k mod 11 for k in 0..4
SHADOW_ORBIT: List[int] = [
    pow(SHADOW_GENERATOR, k, SHADOW_PRIME) for k in range(SHADOW_ORD)
]
# → [1, 4, 5, 9, 3]

# QNR complement of the orbit in ℤ/11ℤ \ {0}
SHADOW_COMPLEMENT: Set[int] = (
    set(range(1, SHADOW_PRIME)) - set(SHADOW_ORBIT)
)
# → {2, 6, 7, 8, 10}

# ══════════════════════════════════════════════════════════════════════════════
# §1  USE-CONTEXT ENUM — THE FIVE TYPE SLOTS
# ══════════════════════════════════════════════════════════════════════════════

class UseContext(Enum):
    """
    The five canonical K-Elimination use contexts, indexed by shadow orbit.

    Each context corresponds to one position in the ×4 orbit on ℤ/11ℤ.
    The orbit position IS the type identifier — no external lookup needed.
    """
    TYPE_QUOTIENT = 0   # tag=1  | ⌊X/M⌋ exact RNS division
    TYPE_WINDING  = 1   # tag=4  | magnitude / winding on T²  ← IMPRINT
    TYPE_PERIOD   = 2   # tag=5  | Shor / BSGS period detection
    TYPE_CARRY    = 3   # tag=9  | CRAM internal carry propagation
    TYPE_ORACLE   = 4   # tag=3  | Grover oracle amplitude weight

    @property
    def shadow_tag(self) -> int:
        """The shadow signature for this context: 4^k mod 11."""
        return SHADOW_ORBIT[self.value]

    @property
    def orbit_position(self) -> int:
        return self.value

    @classmethod
    def from_shadow_tag(cls, tag: int) -> Optional['UseContext']:
        """Recover the UseContext from its shadow signature tag."""
        if tag == 0:
            return None   # sentinel / period boundary
        try:
            k = SHADOW_ORBIT.index(tag)
            return cls(k)
        except ValueError:
            return None   # tag ∈ complement → unregistered context

    @classmethod
    def from_kappa(cls, kappa: int) -> Optional['UseContext']:
        """Derive the use context from a bare κ value via shadow projection."""
        return cls.from_shadow_tag(kappa % SHADOW_PRIME)

    def __str__(self):
        tags = {0: "QUOTIENT(tag=1)", 1: "WINDING(tag=4)",
                2: "PERIOD(tag=5)", 3: "CARRY(tag=9)", 4: "ORACLE(tag=3)"}
        return tags[self.value]


# ══════════════════════════════════════════════════════════════════════════════
# §2  THE SHADOW DISAMBIGUATOR — CORE ENGINE
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class DisambiguationResult:
    """Full result of a shadow disambiguation check."""
    kappa:             int
    modulus_A:         int
    sigma_actual:      int         # κ mod 11
    sigma_expected:    int         # expected shadow tag for declared context
    context_declared:  UseContext
    context_inferred:  Optional[UseContext]
    is_clean:          bool        # True ↔ declared matches inferred
    is_boundary:       bool        # True ↔ κ mod 11 = 0 (period boundary)
    is_unregistered:   bool        # True ↔ σ ∈ complement (no type slot)
    kappa_lifted:      int         # κ in ℤ/121ℤ with type tag in 11s digit
    correction_applied: bool
    note:              str

    def __str__(self):
        status = "✓ CLEAN" if self.is_clean else "✗ MISMATCH"
        return (f"SD11[{status}] κ={self.kappa} σ={self.sigma_actual} "
                f"declared={self.context_declared} "
                f"inferred={self.context_inferred} "
                f"lifted={self.kappa_lifted}")


class ShadowDisambiguator:
    """
    SD-11: Type-safe K-Elimination and CRAM use-context tracker.

    Every K-Elimination result that passes through this disambiguator
    carries a shadow signature σ = κ mod 11. The signature tells you
    exactly what role κ is playing — and if it's playing the wrong
    role in a given pipeline stage, you know immediately.

    The Hensel lift to ℤ/121ℤ makes the type tag inseparable from
    the arithmetic content without changing the base residue.
    """

    def __init__(self):
        self._log: List[DisambiguationResult] = []
        self._violations: List[DisambiguationResult] = []

    # ── Core Check ────────────────────────────────────────────────────
    def check(self, kappa: int, modulus_A: int,
              declared_context: UseContext,
              auto_correct: bool = False) -> DisambiguationResult:
        """
        Verify that κ's shadow signature matches its declared use context.

        Parameters
        ----------
        kappa           : the K-Elimination output value
        modulus_A       : the ring ℤ/Aℤ in which κ lives
        declared_context: what this κ is supposed to represent
        auto_correct    : if True, apply Hensel lift correction on mismatch

        Returns
        -------
        DisambiguationResult with full provenance
        """
        sigma_actual   = kappa % SHADOW_PRIME
        sigma_expected = declared_context.shadow_tag
        inferred       = UseContext.from_shadow_tag(sigma_actual)
        is_boundary    = (sigma_actual == 0)
        is_unreg       = (sigma_actual in SHADOW_COMPLEMENT)
        is_clean       = (sigma_actual == sigma_expected)

        # Compute the Hensel lift: encode type context in 11s-digit of ℤ/121ℤ
        # κ_lifted ≡ κ (mod 11)  [base residue preserved]
        # κ_lifted ≡ orbit_position (mod 11) in the 11s-digit
        k_base       = kappa % SHADOW_PRIME
        orbit_target = declared_context.orbit_position
        # Lift: find x in ℤ/121ℤ s.t. x ≡ kappa (mod 11) and x//11 ≡ orbit_target (mod 11)
        kappa_lifted = k_base + 11 * orbit_target

        correction_applied = False
        if not is_clean and auto_correct and not is_boundary and not is_unreg:
            correction_applied = True

        # Build note
        if is_boundary:
            note = f"κ≡0 mod 11: period boundary / zero sentinel"
        elif is_unreg:
            note = (f"σ={sigma_actual} ∈ complement {{2,6,7,8,10}} — "
                    f"unregistered context, probe fires")
        elif is_clean:
            note = f"σ={sigma_actual} matches {declared_context}"
        else:
            note = (f"CONTEXT MISMATCH: σ={sigma_actual} → "
                    f"inferred={inferred}, expected σ={sigma_expected} "
                    f"for {declared_context}")

        result = DisambiguationResult(
            kappa=kappa, modulus_A=modulus_A,
            sigma_actual=sigma_actual, sigma_expected=sigma_expected,
            context_declared=declared_context, context_inferred=inferred,
            is_clean=is_clean, is_boundary=is_boundary,
            is_unregistered=is_unreg,
            kappa_lifted=kappa_lifted,
            correction_applied=correction_applied,
            note=note
        )
        self._log.append(result)
        if not is_clean and not is_boundary:
            self._violations.append(result)
        return result

    # ── Lift Helpers ──────────────────────────────────────────────────
    def lift(self, kappa: int, context: UseContext) -> int:
        """
        Hensel lift: embed κ into ℤ/121ℤ with context tag in 11s-digit.
        Result r satisfies:
          r ≡ κ    (mod 11)   — base residue preserved
          r // 11 ≡ context.orbit_position  — type tag in upper digit
        """
        return (kappa % SHADOW_PRIME) + 11 * context.orbit_position

    def unlift(self, kappa_lifted: int) -> Tuple[int, Optional[UseContext]]:
        """
        Recover (κ mod 11, UseContext) from a lifted value in ℤ/121ℤ.
        """
        base    = kappa_lifted % SHADOW_PRIME
        upper   = (kappa_lifted // SHADOW_PRIME) % SHADOW_PRIME
        context = UseContext(upper) if 0 <= upper < SHADOW_ORD else None
        return base, context

    def correct_context(self, kappa: int, wrong_ctx: UseContext,
                         right_ctx: UseContext) -> int:
        """
        Correct a context-mismatched κ by adjusting the lift digit.
        The base arithmetic (κ mod 11) is untouched — only the type tag changes.
        """
        return (kappa % SHADOW_PRIME) + 11 * right_ctx.orbit_position

    # ── Reporting ─────────────────────────────────────────────────────
    def summary(self) -> Dict:
        total  = len(self._log)
        clean  = sum(1 for r in self._log if r.is_clean)
        bound  = sum(1 for r in self._log if r.is_boundary)
        unreg  = sum(1 for r in self._log if r.is_unregistered)
        viols  = len(self._violations)
        by_ctx = {}
        for ctx in UseContext:
            by_ctx[str(ctx)] = sum(
                1 for r in self._log if r.context_declared == ctx
            )
        return {
            "total": total, "clean": clean, "boundary": bound,
            "unregistered": unreg, "violations": viols, "by_context": by_ctx
        }

    def print_orbit_table(self):
        print("\n  ╔══════════════════════════════════════════════════════════════╗")
        print("  ║  SHADOW DISAMBIGUATOR — T-SHADOW Orbit Type Table (SD-11)   ║")
        print("  ╠══════════════════════════════════════════════════════════════╣")
        print("  ║  Shadow prime p=11,  Generator=4,  ord_11(4)=5              ║")
        print(f"  ║  Shadow imprint: 169 mod 11 = 4  (13² → orbit pos 1)       ║")
        print("  ╠═════╦════════╦═══════════════╦════════════════════════════╣")
        print("  ║ k   ║ tag=4^k║ UseContext     ║ Meaning                    ║")
        print("  ╠═════╬════════╬═══════════════╬════════════════════════════╣")
        rows = [
            (0, 1, "TYPE_QUOTIENT", "⌊X/M⌋ exact RNS division"),
            (1, 4, "TYPE_WINDING",  "Magnitude / winding on T²  ← imprint"),
            (2, 5, "TYPE_PERIOD",   "Shor / BSGS period detection"),
            (3, 9, "TYPE_CARRY",    "CRAM internal carry propagation"),
            (4, 3, "TYPE_ORACLE",   "Grover oracle amplitude weight"),
        ]
        for k, tag, ctx, meaning in rows:
            print(f"  ║ {k}   ║   {tag:>4} ║ {ctx:<14}║ {meaning:<27}║")
        print("  ╠═════╬════════╬═══════════════╬════════════════════════════╣")
        print("  ║  —  ║      0 ║ SENTINEL       ║ Period boundary / zero     ║")
        print("  ║  —  ║ 2,6,7, ║ UNREGISTERED   ║ Probe fires — no type slot ║")
        print("  ║     ║ 8,10   ║                ║                            ║")
        print("  ╚═════╩════════╩═══════════════╩════════════════════════════╝")


# ══════════════════════════════════════════════════════════════════════════════
# §3  EXACT ARITHMETIC HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def mod_inv(a: int, m: int) -> int:
    if gcd(a, m) != 1:
        raise ValueError(f"gcd({a},{m}) = {gcd(a,m)} — no inverse")
    r0, r1, s0, s1 = a % m, m, 1, 0
    while r1:
        q = r0 // r1
        r0, r1 = r1, r0 - q * r1
        s0, s1 = s1, s0 - q * s1
    return s0 % m

def k_eliminate(r_M: int, r_A: int, M: int, A: int) -> int:
    """κ = (r_A - r_M) · M⁻¹ mod A.  ⌊X/M⌋ mod A. Stays in RNS."""
    return ((r_A - r_M) * mod_inv(M, A)) % A


# ══════════════════════════════════════════════════════════════════════════════
# §4  ANNOTATED K-ELIMINATION — PRODUCES TYPED RESULTS
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class TypedKappa:
    """
    A K-Elimination result with its use context bound at the point of creation.

    The Hensel lift κ_lifted ∈ ℤ/121ℤ carries:
      - bits 0–3 (mod 11):  the base residue κ mod 11 = shadow signature σ
      - bits 4–6 (//11 mod 11): the orbit position = use context type

    These two pieces of information are inseparable in κ_lifted.
    Passing κ_lifted to the wrong pipeline stage will produce a
    shadow signature mismatch — detectable without any external metadata.
    """
    kappa:      int           # raw κ value in ℤ/Aℤ
    modulus_A:  int           # the ring κ lives in
    modulus_M:  int           # the lane that was divided out
    context:    UseContext
    sigma:      int           # κ mod 11
    kappa_lifted: int         # κ in ℤ/121ℤ with type encoded
    step:       int
    source:     str           # human-readable provenance

    @property
    def is_at_boundary(self) -> bool:
        """κ mod 11 = 0 → period boundary in the underlying orbit."""
        return self.sigma == 0

    @property
    def context_is_consistent(self) -> bool:
        """Does σ match the declared context's shadow tag?"""
        return self.sigma == self.context.shadow_tag or self.is_at_boundary

    def __repr__(self):
        clean = "✓" if self.context_is_consistent else "✗"
        return (f"TypedKappa({clean} κ={self.kappa} σ={self.sigma} "
                f"ctx={self.context} lifted={self.kappa_lifted})")


class AnnotatedKElim:
    """
    K-Elimination with automatic shadow disambiguation at every call site.

    Usage:
        ke = AnnotatedKElim(disambiguator)
        typed = ke.divide(r_M=3, r_A=7, M=7, A=11, step=0,
                          context=UseContext.TYPE_WINDING)

    If the produced κ has σ = κ mod 11 ≠ context.shadow_tag, the
    disambiguator records the mismatch and auto-corrects via Hensel lift.
    """

    def __init__(self, sd: ShadowDisambiguator, auto_correct: bool = True):
        self.sd           = sd
        self.auto_correct = auto_correct
        self._history: List[TypedKappa] = []

    def divide(self, r_M: int, r_A: int, M: int, A: int,
               step: int, context: UseContext,
               provenance: str = "") -> TypedKappa:
        """
        Compute κ = ⌊X/M⌋ mod A and immediately type-stamp it.
        """
        kappa = k_eliminate(r_M, r_A, M, A)
        result = self.sd.check(kappa, A, context, auto_correct=self.auto_correct)
        lifted = self.sd.lift(kappa, context)

        src = provenance or f"step={step} r_M={r_M} r_A={r_A} M={M} A={A}"
        tk  = TypedKappa(
            kappa=kappa, modulus_A=A, modulus_M=M, context=context,
            sigma=kappa % SHADOW_PRIME,
            kappa_lifted=lifted, step=step, source=src
        )
        self._history.append(tk)
        return tk

    def quotient_exact(self, x: int, M: int, A: int, step: int) -> TypedKappa:
        """Exact RNS division context: ⌊X/M⌋ mod A."""
        return self.divide(x % M, x % A, M, A, step,
                           UseContext.TYPE_QUOTIENT,
                           f"exact_div X={x} /M={M} modA={A}")

    def track_winding(self, r_M: int, r_A: int, M: int, A: int, step: int) -> TypedKappa:
        """Magnitude/winding context: torus phase tracking."""
        return self.divide(r_M, r_A, M, A, step,
                           UseContext.TYPE_WINDING,
                           f"winding r_M={r_M} r_A={r_A}")

    def find_period(self, r_M: int, r_A: int, M: int, A: int, step: int) -> TypedKappa:
        """Period detection context: Shor / BSGS."""
        return self.divide(r_M, r_A, M, A, step,
                           UseContext.TYPE_PERIOD,
                           f"period r_M={r_M} r_A={r_A}")

    def propagate_carry(self, r_M: int, r_A: int, M: int, A: int, step: int) -> TypedKappa:
        """CRAM carry context: internal lane-to-lane carry propagation."""
        return self.divide(r_M, r_A, M, A, step,
                           UseContext.TYPE_CARRY,
                           f"CRAM_carry M={M}→A={A}")

    def weight_oracle(self, r_M: int, r_A: int, M: int, A: int, step: int) -> TypedKappa:
        """Grover oracle context: amplitude weight per residue class."""
        return self.divide(r_M, r_A, M, A, step,
                           UseContext.TYPE_ORACLE,
                           f"grover_oracle M={M} A={A}")

    def print_history(self, max_rows: int = 15):
        print(f"\n  ┌─ TypedKappa History ({len(self._history)} entries)")
        print(f"  │  {'step':>4} {'M':>6} {'A':>6} {'κ':>6} {'σ':>4} "
              f"{'lifted':>7} {'context':<18} {'status':>8}")
        print(f"  │  {'─'*72}")
        for tk in self._history[:max_rows]:
            status = "✓" if tk.context_is_consistent else "✗ MISMATCH"
            print(f"  │  {tk.step:>4} {tk.modulus_M:>6} {tk.modulus_A:>6} "
                  f"{tk.kappa:>6} {tk.sigma:>4} {tk.kappa_lifted:>7} "
                  f"{str(tk.context):<18} {status:>8}")


# ══════════════════════════════════════════════════════════════════════════════
# §5  CROSS-LANE HETEROGENEITY CORRECTOR
# ══════════════════════════════════════════════════════════════════════════════

class HeterogeneityCorrector:
    """
    Detects and corrects unintentional cross-lane context drift.

    In a CRAM pipeline with heterogeneous operators, K-Elimination
    might be invoked in different contexts across different lanes.
    If the context assignment doesn't match the operator topology,
    the shadow signature will be inconsistent across the lane set.

    This corrector checks the full lane set at each timestep and
    issues corrections via the Hensel lift when σ is inconsistent.
    """

    def __init__(self, sd: ShadowDisambiguator, ke: AnnotatedKElim):
        self.sd = sd
        self.ke = ke
        self._corrections: List[Dict] = []

    def check_lane_set(self, typed_kappas: List[TypedKappa],
                       expected_contexts: List[UseContext],
                       step: int) -> List[Dict]:
        """
        Verify that each lane's TypedKappa has the right context.
        Issue Hensel-lift corrections for mismatches.
        """
        issues = []
        for tk, expected in zip(typed_kappas, expected_contexts):
            if tk.context != expected:
                # Context drift detected
                corrected_lifted = self.sd.correct_context(
                    tk.kappa, tk.context, expected
                )
                issue = {
                    "step":        step,
                    "M":           tk.modulus_M,
                    "A":           tk.modulus_A,
                    "kappa_raw":   tk.kappa,
                    "sigma_wrong": tk.sigma,
                    "ctx_wrong":   str(tk.context),
                    "ctx_right":   str(expected),
                    "sigma_right": expected.shadow_tag,
                    "kappa_lifted_wrong":  tk.kappa_lifted,
                    "kappa_lifted_right":  corrected_lifted,
                    "base_unchanged": (corrected_lifted % SHADOW_PRIME ==
                                       tk.kappa_lifted % SHADOW_PRIME),
                }
                issues.append(issue)
                self._corrections.append(issue)
        return issues

    def print_corrections(self):
        if not self._corrections:
            print("  ✓ No heterogeneity corrections needed")
            return
        print(f"\n  ┌─ Heterogeneity Corrections ({len(self._corrections)})")
        for c in self._corrections:
            print(f"  │  step={c['step']} M={c['M']} A={c['A']}: "
                  f"{c['ctx_wrong']}(σ={c['sigma_wrong']}) → "
                  f"{c['ctx_right']}(σ={c['sigma_right']})")
            print(f"  │    κ_lifted: {c['kappa_lifted_wrong']} → "
                  f"{c['kappa_lifted_right']}  "
                  f"(base κ mod 11 = {c['sigma_wrong']} unchanged: "
                  f"{'✓' if c['base_unchanged'] else '✗'})")


# ══════════════════════════════════════════════════════════════════════════════
# §6  VISUALISER
# ══════════════════════════════════════════════════════════════════════════════

BG   = '#0A0E1A'; GR = '#1A2040'
CYAN = '#00E5FF'; ORG = '#FF6D00'; GRN = '#00C853'
PUR  = '#7C4DFF'; RED = '#FF1744'; GLD = '#FFD600'; TEAL = '#1DE9B6'

def visualise_shadow_disambiguator(
        ke: AnnotatedKElim,
        sd: ShadowDisambiguator,
        steps: int,
        path: str = '/mnt/user-data/outputs/qmnf_shadow_disambiguator.png'):

    history = ke._history
    if not history:
        return

    n = len(history)
    step_arr  = [tk.step for tk in history]
    sigma_arr = [tk.sigma for tk in history]
    kappa_arr = [tk.kappa for tk in history]
    lifted_arr = [tk.kappa_lifted for tk in history]
    ctx_arr   = [tk.context.value for tk in history]
    clean_arr = [tk.context_is_consistent for tk in history]

    # Orbit position of each sigma
    orbit_pos = []
    for s in sigma_arr:
        try:
            orbit_pos.append(SHADOW_ORBIT.index(s))
        except ValueError:
            orbit_pos.append(-1)  # sentinel or unregistered

    ctx_colors = {0: CYAN, 1: GLD, 2: GRN, 3: ORG, 4: PUR}
    ctx_names  = {0: "QUOTIENT", 1: "WINDING", 2: "PERIOD", 3: "CARRY", 4: "ORACLE"}

    fig = plt.figure(figsize=(22, 16), facecolor=BG)
    fig.suptitle(
        "QMNF Shadow Disambiguator (SD-11)\n"
        "T-SHADOW ×4 Orbit on ℤ/11ℤ as K-Elimination Type System",
        color=CYAN, fontsize=14, fontweight='bold', y=0.99
    )
    gs = GridSpec(3, 2, figure=fig, hspace=0.44, wspace=0.32,
                  left=0.07, right=0.97, top=0.94, bottom=0.06)

    def ax_style(ax, title, xl='Step index', yl=''):
        ax.set_facecolor(BG); ax.tick_params(colors='white', labelsize=8)
        ax.set_xlabel(xl, color='#888', fontsize=8)
        ax.set_ylabel(yl, color='#CCC', fontsize=9)
        ax.set_title(title, color=CYAN, fontsize=10, pad=4)
        for sp in ax.spines.values(): sp.set_color(GR)
        ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)

    # ── ① Shadow signature σ = κ mod 11 over time ─────────────────────
    ax1 = fig.add_subplot(gs[0, 0])
    for ctx_val, color in ctx_colors.items():
        mask = [i for i, tk in enumerate(history) if tk.context.value == ctx_val]
        if mask:
            ax1.scatter([step_arr[i] for i in mask],
                        [sigma_arr[i] for i in mask],
                        color=color, s=30, alpha=0.85, zorder=3,
                        label=ctx_names[ctx_val])
    # Mark the orbit values with horizontal lines
    for k, tag in enumerate(SHADOW_ORBIT):
        ax1.axhline(tag, color=ctx_colors[k], linewidth=0.7, linestyle='--', alpha=0.4)
    ax1.axhline(0, color='white', linewidth=0.7, linestyle=':', alpha=0.5, label='Boundary σ=0')
    ax1.set_ylim(-0.5, SHADOW_PRIME)
    ax1.set_yticks(list(range(SHADOW_PRIME)))
    ax1.set_yticklabels(
        [f"{i} {'←orbit' if i in SHADOW_ORBIT else '←boundary' if i==0 else ''}"
         for i in range(SHADOW_PRIME)],
        color='white', fontsize=7
    )
    ax_style(ax1, "① Shadow Signature σ = κ mod 11\nColour = declared use context. "
             "Dashes = orbit type-tag positions.", yl='σ value')
    ax1.legend(fontsize=7, facecolor='#0E1428', labelcolor='white',
               edgecolor=GR, loc='upper right')

    # ── ② Hensel lift κ_lifted ∈ ℤ/121ℤ ──────────────────────────────
    ax2 = fig.add_subplot(gs[0, 1])
    for ctx_val, color in ctx_colors.items():
        mask = [i for i, tk in enumerate(history) if tk.context.value == ctx_val]
        if mask:
            ax2.scatter([step_arr[i] for i in mask],
                        [lifted_arr[i] for i in mask],
                        color=color, s=25, alpha=0.85, zorder=3,
                        label=ctx_names[ctx_val])
    # Lane boundaries in ℤ/121ℤ: each context occupies a strip [11k, 11(k+1))
    for k in range(SHADOW_ORD + 1):
        ax2.axhline(11 * k, color='#334', linewidth=0.6, linestyle='-', alpha=0.5)
    for k in range(SHADOW_ORD):
        mid = 11 * k + 5
        ax2.text(max(step_arr) * 1.01, mid,
                 ctx_names[k], color=ctx_colors[k], fontsize=6.5,
                 verticalalignment='center')
    ax2.set_ylim(-1, SHADOW_PRIME_SQ + 1)
    ax_style(ax2, "② Hensel Lift κ_lifted ∈ ℤ/121ℤ\n"
             "Each horizontal band = one context strip [11k, 11(k+1)).\n"
             "Context encoded in 11s-digit. Base residue in units-digit.",
             yl='κ_lifted value')
    ax2.legend(fontsize=7, facecolor='#0E1428', labelcolor='white', edgecolor=GR)

    # ── ③ Orbit position over time ─────────────────────────────────────
    ax3 = fig.add_subplot(gs[1, 0])
    ax3.scatter(step_arr, orbit_pos, c=[ctx_colors[tk.context.value] for tk in history],
                s=30, alpha=0.9, zorder=3)
    ax3.set_yticks(list(range(SHADOW_ORD)) + [-1])
    ax3.set_yticklabels(
        [f"k={k} tag=4^{k}={SHADOW_ORBIT[k]}" for k in range(SHADOW_ORD)] + ["sentinel/unreg"],
        color='white', fontsize=7
    )
    ax3.set_ylim(-1.5, SHADOW_ORD)
    ax_style(ax3, "③ Orbit Position k (shadow signature → type slot)\n"
             "k = index of σ in [1,4,5,9,3]. -1 = sentinel or unregistered.",
             yl='Orbit position k')

    # ── ④ Consistency check (clean vs mismatch) ────────────────────────
    ax4 = fig.add_subplot(gs[1, 1])
    clean_steps = [step_arr[i] for i in range(n) if clean_arr[i]]
    dirty_steps = [step_arr[i] for i in range(n) if not clean_arr[i]]
    clean_sig   = [sigma_arr[i] for i in range(n) if clean_arr[i]]
    dirty_sig   = [sigma_arr[i] for i in range(n) if not clean_arr[i]]
    if clean_steps:
        ax4.scatter(clean_steps, clean_sig, color=GRN, s=25, alpha=0.8,
                    label='✓ Context consistent', zorder=3)
    if dirty_steps:
        ax4.scatter(dirty_steps, dirty_sig, color=RED, s=60, marker='X', alpha=1.0,
                    label='✗ Context mismatch', zorder=5)
    ax4.set_ylim(-0.5, SHADOW_PRIME)
    ax_style(ax4, "④ Shadow Consistency Audit\n"
             "Green = σ matches declared context. Red ✗ = mismatch detected.",
             yl='σ value')
    ax4.legend(fontsize=8, facecolor='#0E1428', labelcolor='white', edgecolor=GR)

    # ── ⑤ Orbit cycle diagram ──────────────────────────────────────────
    ax5 = fig.add_subplot(gs[2, 0])
    ax5.set_facecolor(BG); ax5.set_aspect('equal'); ax5.axis('off')
    ax5.set_title("⑤ T-SHADOW ×4 Orbit on ℤ/11ℤ — Type System", color=CYAN, fontsize=10, pad=4)

    # Draw the pentagonal orbit
    angles = [2 * math.pi * k / SHADOW_ORD - math.pi / 2 for k in range(SHADOW_ORD)]
    R = 0.38
    cx_c, cy_c = 0.5, 0.46
    node_xy = [(cx_c + R * math.cos(a), cy_c + R * math.sin(a)) for a in angles]

    for k, (x, y) in enumerate(node_xy):
        nxt = node_xy[(k + 1) % SHADOW_ORD]
        ax5.annotate("",
            xy=nxt, xytext=(x, y),
            xycoords='axes fraction', textcoords='axes fraction',
            arrowprops=dict(arrowstyle='->', color=ctx_colors[k],
                            lw=2.0, connectionstyle='arc3,rad=0.15')
        )

    for k, (x, y) in enumerate(node_xy):
        tag = SHADOW_ORBIT[k]
        color = ctx_colors[k]
        ax5.text(x, y, f"σ={tag}\n{ctx_names[k]}",
                 transform=ax5.transAxes, ha='center', va='center',
                 fontsize=8.5, fontweight='bold', color='white',
                 bbox=dict(boxstyle='round,pad=0.4', facecolor=color,
                           edgecolor='white', alpha=0.85))

    ax5.text(cx_c, 0.08, f"×4 mod 11  |  ord_11(4) = 5",
             transform=ax5.transAxes, ha='center', va='bottom',
             color='#888', fontsize=8.5, style='italic')
    ax5.text(cx_c, cy_c, "SD-11", transform=ax5.transAxes,
             ha='center', va='center', color=TEAL, fontsize=13, fontweight='bold')
    ax5.text(cx_c, 0.96, "Shadow imprint 169 mod 11 = 4 → TYPE_WINDING (orbit pos 1)",
             transform=ax5.transAxes, ha='center', va='top',
             color=GLD, fontsize=8)

    # ── ⑥ Disambiguator summary panel ─────────────────────────────────
    ax6 = fig.add_subplot(gs[2, 1])
    ax6.set_facecolor(BG); ax6.axis('off')
    ax6.set_title("⑥ Disambiguator Summary & Lift Encoding", color=CYAN, fontsize=10, pad=4)

    summary = sd.summary()
    lines = [
        f"Total checks:        {summary['total']}",
        f"Clean (σ matches):   {summary['clean']}",
        f"Boundary (σ=0):      {summary['boundary']}",
        f"Unregistered (QNR):  {summary['unregistered']}",
        f"Violations:          {summary['violations']}",
        "",
        "By context:",
    ]
    for ctx_str, count in summary['by_context'].items():
        lines.append(f"  {ctx_str:<20} {count:>5}")
    lines += [
        "",
        "Hensel Lift ℤ/11ℤ → ℤ/121ℤ:",
        "  κ_lifted = (κ mod 11) + 11·k",
        "  k = orbit position = type slot",
        "  κ_lifted mod 11  = base residue",
        "  κ_lifted // 11   = context tag",
        "  Type inseparable from arithmetic.",
        "",
        "Correction formula:",
        "  κ_corr = (κ mod 11) + 11·k_right",
        "  Base κ mod 11 unchanged. ✓",
    ]
    y = 0.97
    for line in lines:
        color = (GRN if 'Clean' in line or '✓' in line or
                        summary.get('violations', 1) == 0 and 'Violations' in line
                 else RED if 'Violations' in line and summary.get('violations', 0) > 0
                 else GLD if 'Lift' in line or 'Correction' in line
                 else 'white')
        ax6.text(0.03, y, line, transform=ax6.transAxes,
                 color=color, fontsize=8.5, fontfamily='monospace',
                 verticalalignment='top')
        y -= 0.052

    fig.text(
        0.5, 0.013,
        "SD-11: Shadow prime 11 provides exactly 5 type slots (= |T-SHADOW gates|). "
        "169 = 13² imprints as σ=4 (TYPE_WINDING). "
        "Hensel lift κ_lifted ∈ ℤ/121ℤ binds type to value. Correction adjusts 11s-digit only.",
        ha='center', va='bottom', color='#666', fontsize=7.5, style='italic'
    )

    plt.savefig(path, dpi=155, bbox_inches='tight', facecolor=BG)
    print(f"  Plot → {path}")


# ══════════════════════════════════════════════════════════════════════════════
# §7  MAIN — DEMONSTRATE ALL USE CONTEXTS + MISMATCH DETECTION
# ══════════════════════════════════════════════════════════════════════════════

def main():
    print("\n" + "═" * 70)
    print("  QMNF SHADOW DISAMBIGUATOR (SD-11)")
    print("  T-SHADOW ×4 Orbit as K-Elimination Type System")
    print("  Acid / HackFate.us — April 5, 2026")
    print("═" * 70)

    sd = ShadowDisambiguator()
    ke = AnnotatedKElim(sd, auto_correct=True)
    sd.print_orbit_table()

    # ── Verify the orbit ───────────────────────────────────────────────
    print(f"\n  ── ORBIT VERIFICATION ──────────────────────────────────────")
    print(f"  Shadow prime p = {SHADOW_PRIME}")
    print(f"  Generator      = {SHADOW_GENERATOR}")
    print(f"  Shadow imprint = 169 mod 11 = {169 % 11} (13² → orbit pos 1 = TYPE_WINDING)")
    orbit = [pow(4, k, 11) for k in range(6)]
    print(f"  ×4 orbit:      {orbit}  (closes at k=5, period={SHADOW_ORD})")
    assert orbit[5] == 1, "Orbit must close at k=5"
    assert set(orbit[:5]) == {1, 3, 4, 5, 9}, "Orbit must be {1,3,4,5,9}"
    print(f"  QR orbit:      {sorted(set(orbit[:5]))} = quadratic residues mod 11")
    print(f"  Complement:    {sorted(SHADOW_COMPLEMENT)} = QNR (unregistered contexts)")
    print(f"  ✓ Orbit verified: 5 slots, closed, covers QR(11)")

    # ── Exercise all five use contexts ─────────────────────────────────
    print(f"\n  ── ALL FIVE USE CONTEXTS ───────────────────────────────────")

    M, A = 7, 11
    test_cases = [
        # (r_M, r_A, context, description)
        (3, 7,  UseContext.TYPE_QUOTIENT, "Exact RNS division ⌊X/7⌋ mod 11"),
        (5, 4,  UseContext.TYPE_WINDING,  "NS vorticity winding on T²"),
        (2, 9,  UseContext.TYPE_PERIOD,   "BSGS period orbit detection"),
        (6, 3,  UseContext.TYPE_CARRY,    "CRAM carry lane 7→11"),
        (1, 8,  UseContext.TYPE_ORACLE,   "Grover oracle amplitude weight"),
    ]

    print(f"\n  {'Context':<20} {'r_M':>4} {'r_A':>4} {'κ':>4} "
          f"{'σ=κmod11':>9} {'expected_σ':>11} {'lifted':>7} {'status':>8}")
    print(f"  {'─'*74}")
    for r_M, r_A, ctx, desc in test_cases:
        tk = ke.divide(r_M, r_A, M, A, step=0, context=ctx, provenance=desc)
        expected_σ = ctx.shadow_tag
        status     = "✓" if tk.context_is_consistent else "✗"
        print(f"  {str(ctx):<20} {r_M:>4} {r_A:>4} {tk.kappa:>4} "
              f"{tk.sigma:>9} {expected_σ:>11} {tk.kappa_lifted:>7} {status:>8}")
        print(f"    → {desc}")

    # ── Demonstrate the Hensel lift ────────────────────────────────────
    print(f"\n  ── HENSEL LIFT DEMONSTRATION ───────────────────────────────")
    print(f"  Lifting κ into ℤ/121ℤ: type context encoded in 11s-digit")
    print(f"  Formula: κ_lifted = (κ mod 11) + 11 × orbit_position")
    print()

    kappa_example = 16   # arbitrary κ with σ = 16 mod 11 = 5
    for ctx in UseContext:
        lifted = sd.lift(kappa_example, ctx)
        base, recovered_ctx = sd.unlift(lifted)
        print(f"  κ={kappa_example}, ctx={str(ctx):<20}: "
              f"lifted={lifted:>4}  "
              f"(base={base}, type_digit={lifted//11}, "
              f"recovered={str(recovered_ctx) if recovered_ctx else 'None'})")

    # ── Context mismatch detection ─────────────────────────────────────
    print(f"\n  ── CONTEXT MISMATCH DETECTION ──────────────────────────────")
    print(f"  Feeding a CARRY κ through a QUOTIENT context — probe fires")

    # Produce a carry-context κ (will have σ matching TYPE_CARRY = 9)
    # then check it as TYPE_QUOTIENT (expected σ = 1 for TYPE_QUOTIENT)
    # We need r_M, r_A such that κ has σ=9 (TYPE_CARRY.shadow_tag)
    # 9 = (r_A - r_M) · 7⁻¹ mod 11  → 9 · 7 mod 11 = 63 mod 11 = 8
    # So r_A - r_M ≡ 8 mod 11 → e.g. r_M=0, r_A=8
    r_M_carry, r_A_carry = 0, 8
    kappa_carry = k_eliminate(r_M_carry, r_A_carry, M=7, A=11)
    print(f"  κ computed with r_M={r_M_carry}, r_A={r_A_carry}, M=7, A=11: κ={kappa_carry}")
    print(f"  σ = {kappa_carry} mod 11 = {kappa_carry % 11}  (TYPE_CARRY.shadow_tag = 9)")

    wrong_check = sd.check(kappa_carry, 11, UseContext.TYPE_QUOTIENT)
    print(f"  Checked as TYPE_QUOTIENT (expected σ={UseContext.TYPE_QUOTIENT.shadow_tag}):")
    print(f"  is_clean = {wrong_check.is_clean}")
    print(f"  note: {wrong_check.note}")

    # Correct it
    corrected = sd.correct_context(kappa_carry, UseContext.TYPE_CARRY, UseContext.TYPE_QUOTIENT)
    print(f"  Hensel correction → κ_lifted_correct = {corrected}")
    base, ctx_back = sd.unlift(corrected)
    print(f"  Recovered: base σ = {base} (unchanged), context = {ctx_back}")

    # ── Cross-lane heterogeneity corrector ─────────────────────────────
    print(f"\n  ── HETEROGENEITY CORRECTOR ─────────────────────────────────")
    print(f"  Three lanes with DIFFERENT declared contexts — checking alignment")

    corrector = HeterogeneityCorrector(sd, ke)
    # Produce TypedKappas from three different use contexts
    lane_kappas = [
        ke.track_winding(r_M=2, r_A=6, M=7, A=11, step=10),
        ke.propagate_carry(r_M=3, r_A=5, M=7, A=11, step=10),
        ke.weight_oracle(r_M=1, r_A=4, M=7, A=11, step=10),
    ]
    # Suppose we expect [WINDING, WINDING, ORACLE] — CARRY in slot 1 is wrong
    expected = [UseContext.TYPE_WINDING, UseContext.TYPE_WINDING, UseContext.TYPE_ORACLE]
    issues = corrector.check_lane_set(lane_kappas, expected, step=10)
    corrector.print_corrections()

    # ── Full run: 60 steps, mixed contexts ─────────────────────────────
    print(f"\n  ── FULL RUN: 60 STEPS, ALL CONTEXTS ───────────────────────")
    rng = np.random.default_rng(2026)
    contexts_cycle = list(UseContext)
    for s in range(60):
        ctx = contexts_cycle[s % len(contexts_cycle)]
        r_M = int(rng.integers(0, 7))
        r_A = int(rng.integers(0, 11))
        ke.divide(r_M, r_A, M=7, A=11, step=s, context=ctx)

    ke.print_history(max_rows=12)

    print(f"\n  ── DISAMBIGUATION SUMMARY ──────────────────────────────────")
    s = sd.summary()
    print(f"  Total checks:    {s['total']}")
    print(f"  Clean:           {s['clean']}")
    print(f"  Boundary (σ=0):  {s['boundary']}")
    print(f"  Unregistered:    {s['unregistered']}")
    print(f"  Violations:      {s['violations']}")
    for ctx_str, count in s['by_context'].items():
        print(f"    {ctx_str:<24}: {count}")

    print(f"\n  Generating visualisation...")
    visualise_shadow_disambiguator(ke, sd, steps=60)

    print(f"\n  ── FORMAL ATTRIBUTION ──────────────────────────────────────")
    print(f"  SD-11 is grounded in three pre-existing QMNF results:")
    print(f"    T-SHADOW: prime 11 unique across gates S1–S5")
    print(f"    Shadow imprint: 169 mod 11 = 4 → TYPE_WINDING position")
    print(f"    K-Elimination: κ stays in RNS, algebraically identical to")
    print(f"      Garner's digit but used as final quotient, not intermediate")
    print(f"  The orbit {SHADOW_ORBIT} gives exactly 5 type slots (= |S-gates|).")
    print(f"  ℤ/121ℤ = ℤ/11²ℤ gives 121 distinguishable typed K-Elim results —")
    print(f"    enough to tag every distinct use in the QMNF stack.")
    print(f"  The correction formula adjusts the type digit without")
    print(f"    touching the base residue. The arithmetic is preserved.")
    print("═" * 70)


if __name__ == '__main__':
    main()
