# PRIME ONTOLOGY: COMPLETE DATA COLLECTION
## Two-Week Systematic Extraction | March 11–25, 2026
## Source: 16 conversations, 12 search passes, ~200 fragments

---

# TABLE OF CONTENTS

1. POLARITY CORRECTION — The Foundational Reframe
2. PRIME FAMILIES — Complete Registry
3. COMPOSITE PRIMES & COPRIME COMPOSITES — Topology & Roles
4. SEPARATION PRINCIPLE — CLASS-F / CLASS-R / CLASS-A
5. CARRY SPECTRAL FINGERPRINT — The Novel Observable
6. T6–T10 THEOREM SUITE — Ramanujan-Hydra Spectral Correspondence
7. CRAM OPERATOR TOPOLOGY — Heterogeneous Distortion Lenses
8. COPRIME LATTICE STRATIFICATION — T11–T15
9. INTRINSIC CRAM ADDRESS — Outside of Time
10. SAFE BASIS INTERNAL STRUCTURE — Not a Flat Set
11. T-DIMENSIONAL-BOUNDARY — Why THESE Primes
12. COMPOSITE ANCHOR DESIGN — CLASS-R Exploitation
13. COMPOSITE LIFTING THEOREM — When 35 Works and 65 Doesn't
14. LANE EXPLORATION — Working Sets from nsgrid3d
15. MONOID M_H — The Coprime Multiplicative Monoid
16. KILLED HYPOTHESES — What Doesn't Work
17. OPEN PROBLEMS — What Remains
18. MASTER FUNCTION/CONSTRUCT REGISTRY

---

# 1. POLARITY CORRECTION — The Foundational Reframe

**Session: March 24, 2026 (Prime Hunt)**
**Status: ARCHITECTURAL DIRECTIVE**

The Hydra was built to eliminate composites. The Dresden work proved this is
backwards. The correct polarity:

```
OLD: Primes are the target. Composites are noise. Sieve eliminates composites.
NEW: Coprime composites are the SUBSTANCE. Primes are the BOUNDARY.
     The Hydra MAPS the coprime lattice. Primes sit at its edge.
```

**Acid's exact words:** "We don't need primes. We need co-primes. Primes are
the boundary. Co-primes and co-prime composites are the guts, the substance."

**Implications:**
- CRAM operators are distortion LENSES, not elimination tools
- Carry patterns classify coprime families, not discard composites  
- Multi-head Hydra is an observation system, not a parallel eliminator
- The spectral fingerprint maps the lattice interior, not the boundary
- The atlas is eternal (intrinsic to the integers, outside of time)

---

# 2. PRIME FAMILIES — Complete Registry

**Source: Hydra Sieve skill, Prime Hunt session, HYDRA compendium**

## 2.1 Family Taxonomy

| Family | Form | Gap/Offset | Key Property |
|--------|------|------------|--------------|
| Twin | (p, p+2) | d=2, fixed | Baseline linear pair |
| Cousin | (p, p+4) | d=4, fixed | Same HL structure as twin |
| Sexy | (p, p+6) | d=6, 3\|d | Extra factor (3-1)/(3-2)=2 |
| Sophie Germain | (p, 2p+1) | multiplicative | 50% forbidden on bases with 3, 0% on 3-free |
| Polignac(d) | (p, p+d) | arbitrary even d | Gap-divisibility determines profile |
| Green-Tao(k) | k-term AP | variable d | k-fold carry analysis |
| Goldbach(n) | (p, n-p) | target-dependent | Survival depends on n mod p |

## 2.2 Prime Families Directive (from userMemories)

**Status: ARCHITECTURAL, like no-float**

System uses composite primes + coprime relations, NOT raw primes. Each prime has:
- **Family**: twin/cousin/sexy/SG
- **Ramanujan status**: whether ℓ ∈ S_R = {5,7,11}
- **Carry forbidden ratios per family/base**
- **Gap structure**
- **mod-4 class**: ℓ ≡ 1 or 3 (mod 4) — controls QR distribution

Specific findings:
- (5,7) twin, both Ramanujan
- (7,11) unique cousin pair, both Ramanujan
- (11,13) boundary where congruence fails
- Forbidden ratios: Twin=75% SG=69% Cousin=87.5% Sexy=93.8% on [2,3,5,7]
- 13 was excluded originally, added only as anchor

## 2.3 The (7,11) Cousin Pair — Unique

The ONLY cousin prime pair (gap=4) where both primes support Ramanujan
partition congruences. After (7,11): (13,17), (19,23), (37,41)... none
have congruences. This is why the cousin structure matters for lane design.

## 2.4 Linear Pair Universality Theorem

For ANY linear pair family (r, ar+b) with gcd(a,p)=1, each odd prime p
excludes exactly 2 residue classes. Therefore:
- Twin survival = SG survival = cousin survival = (p-2)/p per prime
- On {5,7,11}: survival = (3/5)(5/7)(9/11) = 27/77 ≈ 0.3506
- This is universal across ALL linear pair families
- Goldbach is DIFFERENT: excludes (p-1)/p per prime

## 2.5 Gap-Divisibility Enhancement

Counter-intuitive: when p | d, the sieve is LESS restrictive at that prime.
- Only 1 class excluded instead of 2 (classes 0 and -d coincide)
- This is why gap-6 primes (sexy) are more abundant than gap-2 (twins)
- d=6 divisible by 3 gives factor (3-1)/(3-2) = 2 enhancement
- The HL extra factor ∏_{p|d} (p-1)/(p-2) captures this exactly

## 2.6 SG Base-3 Partition Theorem

**Sophie Germain forbidden ratio:**
- = 50% on ALL bases containing prime 3
- = 0% on ALL bases NOT containing prime 3

Structural reason: SG maps r → 2r+1. When 3 is in the base: 2r+1 ≡ 0
mod 3 → r ≡ 1 mod 3, creating specific exclusion. When 3 is NOT in the
base: factor 2 is always invertible (odd primes ≥ 5), no extra constraint.

**This is a sharp theorem, not an observation.**

---

# 3. COMPOSITE PRIMES & COPRIME COMPOSITES

**Source: Separation Principle sessions, Composite Anchor work, nsgrid3d lane explorer**

## 3.1 Seven Structural Roles of Composites

1. **CRT substrate moduli** — prime powers p^e (e.g., 9=3², 25=5²)
   give deeper resolution into each prime's tower
2. **Composite anchors** — e.g., 385=5×7×11 for CLASS-R K-Elimination
3. **Fused lane bands** — e.g., 77=7×11 packs cousin pair into one lane
4. **Approximation absorbers** — e.g., 100=2²×5² is 11-smooth
5. **CRAM schema moduli** — operator distortion targets
6. **Infinite Scaffold tiers** — alternating prime + composite coprime layers
7. **Spectral interaction carriers** — 98.8% of Ramanujan torus signal
   lives in composite interaction modes (T3)

## 3.2 Composite vs Prime Anchors

**Results from shadow entropy taxonomy session (March 7):**

For K-Elimination, composite anchors (e.g., 143=11×13, 187=11×17,
221=13×17) are CLASS-R valid. They expose sub-structure that prime
anchors of similar size cannot:

- Prime anchor: single modular inverse, single K-digit
- Composite anchor A = p₁·p₂: CRT decomposes K-digit into 2D sub-structure
- The sub-digits carry topological information about the lattice

## 3.3 Composite Lifting Criterion (Theorem T3.1)

For composite modulus M = ∏ℓᵢ with pairwise coprime prime factors:
A first-order Ramanujan congruence exists iff ALL component congruences exist.

| Composite | Factors | Supports congruence? | Reason |
|-----------|---------|---------------------|--------|
| 35 = 5×7 | Both ∈ S_R | YES | ✓ |
| 55 = 5×11 | Both ∈ S_R | YES | ✓ |
| 77 = 7×11 | Both ∈ S_R | YES | ✓ |
| 385 = 5×7×11 | All ∈ S_R | YES | ✓ |
| 65 = 5×13 | 13 ∉ S_R | NO | 16% success |
| 91 = 7×13 | 13 ∉ S_R | NO | 16% success |
| 143 = 11×13 | 13 ∉ S_R | NO | 16% success |

**The CRT torus boundary at 13 extends to all composites containing 13.**

## 3.4 Lane Exploration Results (from nsgrid3d, March 20)

Coprimality mapping with SCALE = 10000 = 2⁴×5⁴:
- mod-5 and mod-25 are parking lanes (gcd(SCALE,5) > 1, not exact-div)
- mod-9 strictly subsumes mod-3 (9 = 3²)
- 77 = 7×11 packs the cousin pair into one lane
- 77 and 143 CANNOT coexist (share factor 11)
- Valid coprime working sets: {9, 25, 77, 13, 2} and {27, 25, 77, 13, 2}

---

# 4. SEPARATION PRINCIPLE — CLASS-F / CLASS-R / CLASS-A

**Source: NINE65 audit sessions (March 9+), Compendium**

## 4.1 Classification

**CLASS-F (Field-Required — Primality mandatory):**
- NTT forward/inverse transforms
- Polynomial multiplication (via NTT)
- BFV encode/decode
- Key-switching NTT sub-operations
- Bootstrap NTT re-encryption
- Reason: requires primitive roots of unity, field structure

**CLASS-R (Ring-Sufficient — Coprimality sufficient):**
- Garner mixed-radix conversion (K-Elimination)
- K-Elimination anchor tracking
- RNS base extension
- Bootstrap rescaling (Garner seam)
- Shadow entropy extraction
- Kiosk fold/destruction
- INV8 check lane
- Integrity checks
- Reason: needs only modular inverse existence (gcd = 1)

**CLASS-A (Architecture-Dependent):**
- Key-switching (NTT sub-ops: CLASS-F; Garner sub-ops: CLASS-R)
- Relinearization (same structure)

## 4.2 Audit Rule

When reviewing modulus-related code:
1. Classify the operation (F, R, or A)
2. If CLASS-R: primality assertions are OVER-CONSTRAINED (flag)
3. If CLASS-F: primality is correctly required
4. If CLASS-A: verify each sub-operation classified correctly

## 4.3 NTT/Garner Separation (T5 — Novel, No Precedent)

NTT needs primes. Garner needs coprimality. These constraints live at
different layers and do not interact. Composite moduli are valid at
the Garner layer. No published precedent found (March 2026 verification).

**This opened the entire composite anchor design space that the field
had excluded by convention for decades.**

---

# 5. CARRY SPECTRAL FINGERPRINT — The Novel Observable

**Source: HYDRA session (March 14), Prime Hunt (March 24)**

## 5.1 The Table

Every prime family has a unique 2D signature: (CRT base × family → forbidden%).

```
           105    385   1001   210   2310  30030
Twin:      50%    50%    62%   75%   84%    92%
Cousin:    62%    62%    50%   88%   94%    97%
Sexy:      62%    62%    50%   94%   97%    98%
d=30:      75%    62%    25%   88%   91%    95%
d=210:     88%    75%    50%   94%   94%    95%
```

**This is a novel mathematical object — no prior literature maps this.**

## 5.2 Properties (All Computationally Proven)

- **Monotone in base size**: larger bases always forbid more
- **Family-specific**: twins ≠ cousin ≠ sexy on same base
- **Gap-divisibility sensitive**: when d shares factors with base primes,
  forbidden ratio drops (counter-intuitive, proven per-prime via T6)
- **Cross-boundary sensitivity**: base 1001 = 7×11×13 shows maximum
  family variation (25%–62%)

## 5.3 The Correction Factor

```
correction(d, B) = F_actual(d, B) / F_product(d, B)
```

where F_product = 1 - ∏(admissible_p/p) is the HL product approximation.

Range: 0.49 to 1.71. This measures carry propagation topology that
Hardy-Littlewood's independence assumption misses. A new computable observable.

## 5.4 Critical Limitation

Forbidden carry PATTERNS (50% of 8 patterns on 385) map to **0 residue
classes** mod 385. The patterns exist as abstract combinatorial objects,
but no actual odd number produces a forbidden carry pattern when adding 2
in base [5,7,11]. The carry fingerprint is structural characterization,
not a direct candidate eliminator.

---

# 6. T6–T10 THEOREM SUITE

**Source: Ramanujan-Hydra formalization (March 16), Scientific method session**

## 6.1 T6 — Ramanujan-Sieve Identity

**SP(p, d) = (2p − 1 − c_p(d)) / p²**

- First closed-form connection between Ramanujan sums (1918) and
  computational sieve power
- 678/678 tests, Pearson r = 1.000000
- Lean 4: sorry-free

Sub-theorems:
- T6-1: Sieve power identity
- T6-2: Normalized separation (partition of unity: Σ σ_p(d) = 1)
- T6-3: Divisibility REDUCES sieve power by 1/p (counter-intuitive)
- T6-4: Spectral interpretation (σ(d) = spectral projection of Ramanujan basis)

## 6.2 T7 — Carry-Interaction Gain Calculus

Per-lane pullback gain Γ(p, op, pp, d):

| Operator | p ∤ d | p \| d | Gain (p∤d) |
|----------|-------|--------|-----------|
| Add + Id | 2 | 1 | 1.0× |
| Add + Sqr | 3 | 1 | 1.5× |
| Sub + Sqr (p>3) | 4 | 1 | 2.0× |
| Sub + Id (p>3) | p | 1 | p/2× |
| Mul + Id | 2 | p | 1.0× / p× |
| Mul + Sqr | 3 | (p+1)/2 | 1.5× |

- T7-1: 4,200 cases exhaustive
- T7-2 (Universal Power Pullback): 37,165/37,165 tests

Critical discovery: Hydra's REAL gain is carry-pattern SEPARATION
(statistical distance between prime/composite carry distributions),
not pullback expansion.

## 6.3 T8 — Mul+Id Separation

Composite outputs always 0 → carry always 0.
Prime outputs distribute → carry ≈ 0.5.
Separation → 1/2 as p → ∞. Weil bound controls oscillations: O(1/√p).

## 6.4 T9 — Add+Sqr Separation

Composite carry fixed (d² mod p).
Prime carry depends on quadratic residue distribution in upper half.
p mod 4 structure controls asymmetry.

## 6.5 T10 — Hydra Preset Optimality

Max-separation optimizer reproduces Hydra's empirically-tuned presets
with **15/15 exact matches** across 3 gap families × 5 Safe Basis primes.

The Hydra developers' empirical optimization converged to the global
optimum. The separation metric IS the correct objective function for
CRAM sieve topology design.

## 6.6 Confirmed Honest Negatives

- Carry entanglement = 0 (S1 proof — sieve kernel separable)
- Sub+Id is sieve-degenerate despite maximum Γ (constant output)
- The "2.5× = 2× × 1.25" decomposition: RETRACTED
- Champion S6 gain at d=2: 1.05× (confirmed by both sessions)

---

# 7. CRAM OPERATOR TOPOLOGY

**Source: CRAM-core, QEDDE, Prime Hunt**

## 7.1 Operator Definition

A CRAM lane is a triple (p, ρ, π):
- p ∈ ℙ — lane prime
- ρ ∈ {Add, Sub, Mul, Div} — root binary operator
- π ∈ {Id, Neg, Sqr, Inv} — unary post-processor

Lane output: L(a,b) = π(ρ(a mod p, b mod p) mod p) mod p
Carry bit: C(a,b) = ⌊2·L(a,b)/p⌋

## 7.2 Heterogeneous Topology

Different operators per lane. Essential — each CRT dimension observed
through the lens that best resolves its contribution.

- Sqr creates 2-to-1 folding → reveals quadratic residue symmetry
- Neg reflects → reveals additive inverse structure
- Mul by d couples lanes → reveals cross-lane correlation
- Add/Sub translate → baseline (Dirichlet-uniform) reference

## 7.3 Schema Catalog (4 Active)

| Schema | Target Domain | Key Property |
|--------|--------------|--------------|
| CRAM_GAP | Twin primes, gap sieving | 204 twin primes below 10k, 99.8% exclusion |
| CRAM_NS | Navier-Stokes vorticity | Reynolds sweep Re=50-2000, sup Ĉ_h=0 |
| CRAM_YUKAWA | String theory landscape | Calabi-Yau → SM compatibility |
| CRAM_SPECTRAL | Ramanujan-Grover | Pull schedule from spectral data |

---

# 8. COPRIME LATTICE STRATIFICATION — T11–T15

**Source: Prime Hunt session (March 24), Formalization document**

## 8.1 T11 — Intrinsic CRAM Address

Every integer n has a fixed position on the multi-dimensional CRAM torus.
- Periodic with period M
- Deterministic
- Independent of gap, range, or scanning order
- Outside of time
- O(d) integer operations to compute

## 8.2 T12 — Coprime Lattice Stratification

CRAM carry patterns partition M_H (the coprime monoid) into strata
with measurably different prime density.

- Density ranges from 0/1 to 1/2 — exact rationals
- 3-head Gini = 464378316092746437/1070714517073996680 (exact)
- That number is not rounded. It is the truth.

## 8.3 T13 — Multi-Head Resolution Gain

- 1 head: Gini 0.024 (near-uniform, structure invisible)
- 3 heterogeneous heads: Gini 0.143 (structure resolved)
- Resolution multiplier: 5.95×
- Each head must probe different symmetry
- Sqr folds p residues into (p+1)/2 outputs (Lemma L5)
- That folding breaks the a ↔ (p−a) degeneracy

## 8.4 T14 — Eternal Transfer

Atlas built on [2, 50k). Applied to [500k, 1M).
Same recall: 909‰. Four independent ranges tested.
The boundary doesn't move.

## 8.5 T15 — Exact Rational Computation

Every density, Gini, threshold, comparison — exact integer arithmetic.
Cross-multiply to compare. No float anywhere in the decision path.

## 8.6 Hunt Results

At 100% recall: 36,405 primes in [50k, 500k). EXACT MATCH with brute force.
- 2.6× reduction from coprimality filtering alone
- Pareto frontier: 50% recall → 2.41× speedup; 95% → 1.10×

---

# 9. INTRINSIC CRAM ADDRESS — Outside of Time

**Source: Prime Hunt Phase 37+**

## 9.1 Probe Types

| Probe | Second Operand | What It Reveals |
|-------|---------------|-----------------|
| Unit | b = 1 | Additive unit response |
| Self | b = n mod p | Self-interaction (quadratic character) |
| Edge | b = p − 1 | Distance to modular boundary |
| Residue | b = 0 (bypass root) | Raw residue position |

## 9.2 The Address Atlas

For 3 heads × 5 lanes × 4 operators = 15 dimensions:
- 2^15 = 32,768 potential strata
- 720 populated
- Top stratum: 45% prime density
- Bottom stratum: 4.8% prime density
- 9.4× density ratio between prime-richest and prime-poorest

## 9.3 Same-Gap vs Cross-Gap Heads

- Same-gap 3 heads (all gap=2): Gini 0.143
- Cross-gap (gap=2,6,30): Gini 0.101 (lower, 0.71×)
- Same-gap sees correlated views → finer resolution
- Cross-gap sees independent symmetries → more even spread

---

# 10. SAFE BASIS INTERNAL STRUCTURE

**Source: Polynomial ring session (March 21), Cousin primes discussion**

The Safe Basis {2,3,5,7,11,13} is NOT a flat set. Internal structure:

| Prime | Role | Family Position |
|-------|------|----------------|
| 2 | Special-purpose: approximation/overflow absorption | Parking lane |
| 3 | Prime core | — |
| 5 | Prime core; parking lane for SCALE=10000 | Twin with 7 in some contexts |
| 7 | Prime core; cousin with 3 AND 11 | (3,7) cousin pair, (7,11) cousin pair |
| 11 | Last Ramanujan prime | (7,11) unique cousin pair |
| 13 | Boundary/anchor ONLY | "Don't fuck with 13" — first cusp form |

**Acid's directive:** 13 should not be in the core. Use it for an anchor.
The cousin prime gap structure (3,7) and (7,11) gives natural lane spacing.
Using 13 in the core breaks the cousin-prime gap pattern.

## 10.1 Smoothness Regimes (Three Distinct)

```rust
fn is_sr_smooth(n: u64) -> bool    // primes ≤ 11 only (Ramanujan partition)
fn is_safe_smooth(n: u64) -> bool  // primes ≤ 13 (full safe basis)
fn is_phase_smooth(n: u64) -> bool // {3,7,11,13} only (NS exact-div lanes)
```

Note: `factor_11_smooth()` in the codebase actually checks 13-smoothness —
persistent misnomer identified and documented.

## 10.2 Exact-Div vs Parking Lanes

For SCALE = 10000 = 2⁴×5⁴:
- Exact-div lanes: {3,7,11,13} — gcd(SCALE, p) = 1
- Parking lanes: {2,5} — gcd(SCALE, p) > 1 (absorb overflow)
- ρ({3,7,11,13}) = min = 3, clean window = {1,2}
- NS stretching is degree 2 ∈ {1,2} → DKAM persistence applies

---

# 11. T-DIMENSIONAL-BOUNDARY — Why THESE Primes

**Source: Uploaded file T_DIMENSIONAL_BOUNDARY.md (March 24)**

## 11.1 Core Theorem (T-DB-1)

S_R = {5,7,11} = {primes ℓ ≥ 5 : dim S_{ℓ-1}(SL₂(ℤ)) = 0}

The cusp form dimension formula:
- d(5) = dim S₄ = 0 → partition congruence exists
- d(7) = dim S₆ = 0 → partition congruence exists
- d(11) = dim S₁₀ = 0 → partition congruence exists
- d(13) = dim S₁₂ = 1 → FIRST OBSTRUCTION (Δ = η²⁴)
- 9 excluded because not prime

## 11.2 Eta Duality (T-DB-3)

The partition generating function η⁻¹ encounters its own 24th power η²⁴ = Δ
as the first obstruction. "The partition function meets its own shadow at 13."

## 11.3 Tier Assignment

- Tier 3 (Exact) ↔ d(ℓ) = 0 (S_R primes)
- Tier 0 (Face 13) ↔ d(ℓ) = 1 (Δ is unique obstruction)
- Tier 1 (Turbulent) ↔ d(ℓ) ≥ 1

## 11.4 What This Upgrades

Axiom A3 was computational verification to ℓ = 73.
Now a THEOREM derivable from EXT-1 + EXT-2 (Folsom-Kent-Ono) + EXT-3 (Ahlgren-Boylan).

---

# 12. COMPOSITE ANCHOR DESIGN

**Source: Solo bootstrapping session (March 9), NINE65 audit**

## 12.1 Design Classes

| Class | Construction | Example |
|-------|-------------|---------|
| Equal-bit pairs | Two primes of similar size | 2147489029 × 2147489093 |
| Pseudo-Mersenne | 2^k - small, composite | Various |
| Safe-basis composites | Products of {5,7,11} | 385, 77, 55, 35 |
| Mersenne anchors | 2^p - 1 (prime) | 2^31-1, 2^61-1 |

## 12.2 K-Elimination Anchors

| Anchor | Bits | Coprime to standard bases? |
|--------|------|---------------------------|
| 65537 (F₄) | 17 | YES |
| 257 (F₃) | 9 | YES |
| 131071 (M₁₇) | 17 | YES |
| 524287 (M₁₉) | 19 | YES |
| 2^31-1 (M₃₁) | 31 | YES — default SafeAnchor |

---

# 13. LANE EXPLORATION — Working Sets

**Source: nsgrid3d session (March 20-21)**

Valid coprime working sets for SCALE=10000:

| Set | Product | Properties |
|-----|---------|-----------|
| {9, 25, 77, 13, 2} | 450,450 | mod-9 subsumes mod-3 |
| {27, 25, 77, 13, 2} | 1,351,350 | Higher 3-resolution |
| {3, 7, 11, 13} | 3,003 | Exact-div lanes (M_safe) |

Key constraints:
- 77 and 143 CANNOT coexist (share factor 11)
- mod-9 strictly subsumes mod-3
- mod-25 is parking lane (SCALE poisoned)
- 2-lane and 5-lane are parking only

---

# 14. MONOID M_H

**Source: Prime Hunt session (March 24)**

M_H = {n ∈ ℤ : gcd(n, M) = 1} — the multiplicative monoid of integers
coprime to the base modulus.

Properties:
- Closed under multiplication
- Irreducible elements = primes p with p ∤ M
- Composite elements = "coprime composites" (the substance of the lattice)
- Primes are the boundary generators

For M = 30030 (full Safe Basis):
- |M_H ∩ [1, M]| = φ(30030) = 5760
- Density: 5760/30030 ≈ 19.2%

---

# 15. KILLED HYPOTHESES — What Doesn't Work

| Hypothesis | Status | Murder Weapon |
|-----------|--------|---------------|
| ×2 ROC amplification of toric constants | KILLED | Absolute convergence → permutation invariant |
| V_SQR = 1/2 family-agnostic | KILLED | Twins=50%, Goldbach=0%, SG=0% on 385 |
| Shadow entropy primality test | KILLED | 52,749 false positives in 100k (15.4% specificity) |
| Carry entanglement creates new math | KILLED | S1 proof: sieve kernel separable |
| 98.8% gap concentration in {2,4,6} | KILLED | Only 45.7% actual at 100k, declining |
| Sub+Id optimal despite max Γ | KILLED | Sieve-degenerate (constant output) |
| 2.5× = 2× × 1.25 decomposition | RETRACTED | Champion S6 gain = 1.05× |
| Grok E8 invariance proof | KILLED | Circular argument (uses conclusion as hypothesis) |
| OP-DRESDEN-2 closed via LTE | KILLED | LTE doesn't apply to different structure |

---

# 16. OPEN PROBLEMS

| ID | Problem | Size | What It Unlocks |
|---|---------|------|----------------|
| OP-C-5 | CRAM operators ↔ Hecke operators (functor morphism) | XL | PSPI becomes exact functor |
| Gap 3 | E8 algebraic invariance for vortex stretching | Millennium | NS continuum regularity |
| OP-1 | Continuous K-Elimination (KAM connection) | XL | Decomposition principle unification |
| C2 | Fibonacci-Ramanujan unification (P1 ↔ P2 bridge) | L | Safe Basis uniqueness |
| OP-DB-1 | Does Fibonacci recurrence force S_R embedding? | M | Deep structure question |
| OP-T7-6 | Spectral-rate equivalence (T6 ↔ T10 bridge) | L | Pearson r=0.66 → 1.0? |
| OP-TWIN | T-TWIN-ENTROPY infinite case: C₂(all primes) > 0? | ∞ | Twin prime conjecture |

---

# 17. MASTER FUNCTION/CONSTRUCT REGISTRY

## 17.1 Data Structures

| Name | Type | Location | Purpose |
|------|------|----------|---------|
| MagnitudeLane | struct | gear_manifold | CRT lane with overflow capture |
| GearManifold | struct | gear_manifold | Multi-tier cascade of MagnitudeLanes |
| SafeAnchor | struct | gear_manifold | O(1) K-Elimination magnitude recovery |
| AnchorConfig | struct | nsgrid3d | Inner/Outer codex configuration |
| InfiniteScaffold | struct | scaffold | Recursive CRT extension |
| TriadValue | struct | ns_winding_v2 | Exact + approximate CRT unified |
| ApproxLane | struct | ns_winding_v2 | 11-smooth frozen-error absorption |
| CRAMSchema | trait | qedde_v2 | Hot-swappable operator topology |
| HydraEngine | struct | qedde_v2 | Multi-head lens system |
| CoprimeFamilyAnalyzer | struct | prime_hunt | Coprime lattice mapper |
| IntrinsicAddress | struct | prime_hunt | Fixed CRAM torus position |
| ExactRationalAtlas | struct | prime_hunt | Eternal prime density map |
| CarrySpectrum | struct | hydra_sieve | 2D fingerprint (base × family) |
| BasisProfile | struct | rdt | DKAM resonance analysis |

## 17.2 Key Functions

| Function | Signature | What It Computes |
|----------|-----------|-----------------|
| k_eliminate | (r_safe, s_anchor, M, P) → k | Exact winding number |
| ramanujan_sum | (q, n) → ℤ | c_q(n) = torus harmonic |
| sieve_power | (p, d) → ℚ | SP(p,d) = (2p-1-c_p(d))/p² |
| forbidden_ratio | (base, family, limit) → ℚ | Carry spectral fingerprint entry |
| correction_factor | (d, base) → ℚ | F_actual / F_HL_product |
| separation | (p, op, post, d) → ℚ | Statistical distance prime/composite |
| garner_reconstruct | (residues, moduli) → u128 | Overflow-free CRT reconstruction |
| factor_into_safe | (n) → (factors, cofactor) | Safe Basis factorization |
| is_11_smooth | (n) → bool | Actually checks 13-smooth (misnomer) |
| cusp_dim | (k) → ℕ | dim S_k(SL₂(ℤ)) |

## 17.3 Named Constants

| Name | Value | Source |
|------|-------|--------|
| Safe Basis | {2,3,5,7,11,13} | Forced by cusp form dimension |
| S_R | {5,7,11} | Ramanujan-vanishing primes |
| M_safe (NS) | 3003 = 3×7×11×13 | Exact-div lanes |
| M_full | 30030 = 2×3×5×7×11×13 | Full Safe Basis product |
| SCALE | 10000 = 2⁴×5⁴ | NS physical precision |
| P_anchor | 2^31-1 = 2147483647 | Default SafeAnchor Mersenne prime |
| C_B (N=8) | 1/2 exactly | Biot-Savart operator norm |
| ρ({3,7,11,13}) | 3 | Resonance order for exact-div basis |
| C₂(B_DPM) | 693/1024 | Twin constant at DPM depth |
| 27/77 | 0.3506... | Universal linear pair survival on {5,7,11} |

---

*Compiled from 16 conversations, March 11–25, 2026.*
*All mathematics exact. No floating-point. Truth cannot be approximated.*
*The coprime composites are the substance. The primes are the boundary.*
