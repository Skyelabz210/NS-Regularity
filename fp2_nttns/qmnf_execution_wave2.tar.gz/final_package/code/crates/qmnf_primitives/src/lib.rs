//! QMNF Primitives — Core exact-integer arithmetic
//!
//! Kill #1: K-Elimination Theorem
//!   For coprime moduli M, A (gcd(M,A) = 1) and value X ∈ [0, MA):
//!     κ = ((v_A − v_M) · M⁻¹) mod A
//!     X = v_M + κ · M   (exactly)
//!
//! These are the foundational operations for the entire QMNF ecosystem.

/// Extended Euclidean algorithm returning modular inverse.
///
/// Computes a^{-1} mod m. Panics if gcd(a,m) ≠ 1.
///
/// # Mathematical guarantee
/// For coprime a, m: (mod_inverse(a, m) * a) ≡ 1 (mod m)
#[inline]
pub fn mod_inverse(a: u64, m: u64) -> u64 {
    if m == 1 { return 0; }
    let (mut old_r, mut r) = (a as i128, m as i128);
    let (mut old_s, mut s) = (1i128, 0i128);
    while r != 0 {
        let q = old_r / r;
        let temp_r = r;
        r = old_r - q * r;
        old_r = temp_r;
        let temp_s = s;
        s = old_s - q * s;
        old_s = temp_s;
    }
    assert!(old_r == 1, "mod_inverse: gcd({}, {}) = {} ≠ 1 — not coprime", a, m, old_r);
    ((old_s % m as i128 + m as i128) % m as i128) as u64
}

/// K-Elimination: recover the winding number κ = ⌊X/M⌋ from residues.
///
/// Given:
///   r_safe   = X mod M_safe
///   s_anchor = X mod P_anchor
///   m_safe   = M_safe (inner codex product)
///   p_anchor = P_anchor (large prime anchor)
///
/// Returns: κ = ((s_anchor - r_safe) × M_safe⁻¹) mod P_anchor
///
/// This is the deck transformation index of the covering map π: ℤ → ℤ/M_safeℤ.
#[inline]
pub fn k_eliminate(r_safe: u64, s_anchor: u64, m_safe: u64, p_anchor: u64) -> u64 {
    let inv = mod_inverse(m_safe % p_anchor, p_anchor);
    let diff = if s_anchor >= (r_safe % p_anchor) {
        s_anchor - (r_safe % p_anchor)
    } else {
        p_anchor - ((r_safe % p_anchor) - s_anchor)
    };
    // k = diff * inv mod p_anchor
    ((diff as u128 * inv as u128) % p_anchor as u128) as u64
}

/// Full reconstruction: X = r_safe + κ × M_safe
///
/// Composes k_eliminate with the reconstruction step.
/// Returns the exact value X ∈ [0, M_safe × P_anchor).
#[inline]
pub fn k_reconstruct(r_safe: u64, s_anchor: u64, m_safe: u64, p_anchor: u64) -> u128 {
    let k = k_eliminate(r_safe, s_anchor, m_safe, p_anchor) as u128;
    r_safe as u128 + k * m_safe as u128
}

/// GCD via Euclidean algorithm.
#[inline]
pub fn gcd(a: u64, b: u64) -> u64 {
    let (mut a, mut b) = (a, b);
    while b != 0 {
        let t = b;
        b = a % b;
        a = t;
    }
    a
}

/// Check coprimality.
#[inline]
pub fn coprime(a: u64, b: u64) -> bool {
    gcd(a, b) == 1
}

/// Chinese Remainder Theorem for two coprime moduli.
/// Returns x such that x ≡ r1 (mod m1) and x ≡ r2 (mod m2).
#[inline]
pub fn crt2(r1: u64, m1: u64, r2: u64, m2: u64) -> u128 {
    let inv = mod_inverse(m1 % m2, m2);
    let diff = if r2 >= (r1 % m2) {
        r2 - (r1 % m2)
    } else {
        m2 - ((r1 % m2) - r2)
    };
    let k = ((diff as u128 * inv as u128) % m2 as u128) as u64;
    r1 as u128 + k as u128 * m1 as u128
}

/// Garner's algorithm for multi-modulus CRT reconstruction.
/// residues[i] = X mod moduli[i], all moduli pairwise coprime.
/// Returns X mod (product of all moduli).
pub fn garner_reconstruct(residues: &[u64], moduli: &[u64]) -> u128 {
    assert_eq!(residues.len(), moduli.len());
    if residues.is_empty() { return 0; }
    
    let mut result: u128 = residues[0] as u128;
    let mut product: u128 = moduli[0] as u128;
    
    for i in 1..residues.len() {
        let mi = moduli[i] as u128;
        let ri = residues[i] as u128;
        let pm = product % mi;
        let inv = mod_inverse(pm as u64, moduli[i]) as u128;
        let diff = (ri + mi - (result % mi)) % mi;
        let t = (diff * inv) % mi;
        result += product * t;
        product *= mi;
    }
    result
}

// ═══════════════════════════════════════════════════════════════
// TESTS — matching the 46/46 from the full qmnf_primitives crate
// ═══════════════════════════════════════════════════════════════
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mod_inverse_basic() {
        assert_eq!((mod_inverse(3, 7) * 3) % 7, 1);
        assert_eq!((mod_inverse(5, 13) * 5) % 13, 1);
        assert_eq!((mod_inverse(7, 11) * 7) % 11, 1);
    }

    #[test]
    fn test_mod_inverse_mersenne() {
        let p = (1u64 << 31) - 1;
        let m_safe = 3u64 * 7 * 11 * 13; // 3003
        let inv = mod_inverse(m_safe % p, p);
        assert_eq!(((m_safe as u128 * inv as u128) % p as u128) as u64, 1);
    }

    #[test]
    fn test_k_eliminate_basic() {
        // X = 42, M = 5, A = 7 → v_M = 2, v_A = 0, k = ((0-2)*5^{-1}) mod 7
        // 5^{-1} mod 7 = 3 (since 5*3 = 15 ≡ 1 mod 7)
        // k = (0 - 2) * 3 mod 7 = (-6) mod 7 = 1
        // Verify: 2 + 1*5 = 7 = 42 mod 35 ✓
        let k = k_eliminate(42 % 5, 42 % 7, 5, 7);
        assert_eq!(k, (42 / 5) % 7); // k = 8 mod 7 = 1
    }

    #[test]
    fn test_k_reconstruct_exact() {
        let m_safe = 3003u64; // 3 × 7 × 11 × 13
        let p_anchor = (1u64 << 31) - 1;
        
        for &x in &[0u64, 1, 42, 360, 432, 25920, 432000, 2_000_000_000] {
            let r = x % m_safe;
            let s = x % p_anchor;
            let recon = k_reconstruct(r, s, m_safe, p_anchor);
            assert_eq!(recon, x as u128, "k_reconstruct failed for x={}", x);
        }
    }

    #[test]
    fn test_k_eliminate_ns_scale() {
        // NS campaign: SCALE=10000, P_NS=1000003
        let total = 10_000u64 + 1000 * 70_000; // 70,010,000
        let p_ns = 1_000_003u64;
        let p_mag = 1_000_033u64;
        let r_ns = total % p_ns;
        let r_mag = total % p_mag;
        let k = k_eliminate(r_ns, r_mag, p_ns, p_mag);
        assert_eq!(k, total / p_ns); // 70
    }

    #[test]
    fn test_garner_safe_basis() {
        let moduli = [2u64, 3, 5, 7, 11, 13];
        for &x in &[0u64, 1, 42, 360, 432, 25920, 30029] {
            let residues: Vec<u64> = moduli.iter().map(|&m| x % m).collect();
            let recon = garner_reconstruct(&residues, &moduli);
            assert_eq!(recon, x as u128, "Garner failed for x={}", x);
        }
    }

    #[test]
    fn test_gcd_coprime() {
        assert!(coprime(3003, (1u64 << 31) - 1));
        assert!(coprime(30030, (1u64 << 31) - 1));
        assert!(!coprime(6, 3));
        assert!(coprime(7, 13));
    }

    #[test]
    fn test_crt2_basic() {
        // X = 23: X mod 5 = 3, X mod 7 = 2
        let x = crt2(3, 5, 2, 7);
        assert_eq!(x, 23);
    }

    #[test]
    fn test_k_eliminate_all_values_small() {
        // Exhaustive test for small moduli: every X in [0, M*A)
        let m = 5u64;
        let a = 7u64;
        for x in 0..(m * a) {
            let r_m = x % m;
            let r_a = x % a;
            let k = k_eliminate(r_m, r_a, m, a);
            let recon = k_reconstruct(r_m, r_a, m, a);
            assert_eq!(recon, x as u128, "K-Elim failed for x={}", x);
            assert_eq!(k, x / m, "k wrong for x={}", x);
        }
    }
}
