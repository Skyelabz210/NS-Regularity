//! # CRAM Explorer — Universal Toolbox for CRT Torus Exploration
//!
//! Zero floating-point. All exact integer. Built for the QMNF ecosystem.
//!
//! ## Modules
//!
//! - `mod_arith`: Modular arithmetic primitives
//! - `k_elim`: K-Elimination engine (cross-lane winding numbers)
//! - `torus`: Configurable CRT torus with dynamic-k
//! - `maps`: Pluggable dynamical maps (Collatz, affine, pure torus)
//! - `projector`: Commutativity projector + dynamic-k explorer
//! - `diagnostics`: Lane energy, ring hom, Ramanujan, sync, DKAM

pub mod mod_arith;
pub mod k_elim;
pub mod torus;
pub mod maps;
pub mod projector;
pub mod diagnostics;
pub mod holodrive;
pub mod shadow_ladder;
pub mod apollonian;
