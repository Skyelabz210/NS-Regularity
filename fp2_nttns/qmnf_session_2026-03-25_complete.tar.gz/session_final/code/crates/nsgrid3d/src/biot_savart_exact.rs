//! # Exact Biot-Savart — Zero f64 Everywhere (OP-3 Complete)
//!
//! The kernel is precomputed using Q(√2) rational arithmetic.
//! All √2 factors cancel, giving exact integer kernel values.
//! No f64 in precompute. No f64 on the hot path. No f64 anywhere.
//!
//! The only approximation: final division by D=7680 truncates by ±1.
//! This is the sole error source in the entire pipeline.
//!
//! Currently supports N=8 only (kernel is a compile-time constant).
//! Extension to other N requires computing the exact kernel for that N
//! via the same Q(√2) method (see exact_kernel_n8.json).

use crate::ns_grid_3d::{NSGrid3D, SCALE};

// Re-use NTT infrastructure from biot_savart_ntt
use crate::biot_savart_ntt::{self};

/// Exact common denominator for the N=8 kernel.
/// D = 7680 = 2⁹ × 3 × 5.
/// Every kernel entry G(j)·D is an exact integer.
pub const EXACT_DENOM: i64 = 7680;

/// Precomputed exact kernel for N=8.
/// Indexed as KERNEL[j * 9 + a * 3 + b] = G_ab(delta_j) * 7680.
/// Computed in Q(√2) rational arithmetic. Zero f64.
/// Range: [-315, 315]. Fits in i16.
pub const KERNEL_N8: [i16; 4608] = [
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, 315,   0,-315,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  57,   0, -57,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -57,   0,  57,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,-315,   0, 315,   0,   0,   0,   0,   0,
     0,   0,-315,   0,   0,   0, 315,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -57,   0,   0,   0,  57,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -21,   0,   0,   0,  21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -57,   0,   0,   0,  57,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  57,   0, -57,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  21,   0, -21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -21,   0,  21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -57,   0,  57,   0,   0,   0,   0,   0,
     0,   0, -57,   0,   0,   0,  57,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -21,   0,   0,   0,  21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -11,   0,   0,   0,  11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -21,   0,   0,   0,  21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  21,   0, -21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  11,   0, -11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -11,   0,  11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -21,   0,  21,   0,   0,   0,   0,   0,
     0,   0,  57,   0,   0,   0, -57,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  21,   0,   0,   0, -21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  11,   0,   0,   0, -11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  21,   0,   0,   0, -21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  57,   0, -57,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  21,   0, -21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -21,   0,  21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -57,   0,  57,   0,   0,   0,   0,   0,
     0,   0, 315,   0,   0,   0,-315,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  57,   0,   0,   0, -57,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  21,   0,   0,   0, -21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  57,   0,   0,   0, -57,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, 315,   0,-315,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  57,   0, -57,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  21,   0, -21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  57,   0, -57,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  57,   0, -57,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  21,   0, -21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  11,   0, -11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  21,   0, -21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  21,   0, -21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  11,   0, -11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   7,   0,  -7,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  11,   0, -11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  57,   0, -57,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  21,   0, -21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  11,   0, -11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  21,   0, -21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  57,   0, -57,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  21,   0, -21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -21,   0,  21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -57,   0,  57,   0,   0,   0,   0,   0,
     0,   0, -57,   0,   0,   0,  57,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -21,   0,   0,   0,  21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -11,   0,   0,   0,  11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -21,   0,   0,   0,  21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  21,   0, -21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  11,   0, -11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -11,   0,  11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -21,   0,  21,   0,   0,   0,   0,   0,
     0,   0, -21,   0,   0,   0,  21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -11,   0,   0,   0,  11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  -7,   0,   0,   0,   7,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -11,   0,   0,   0,  11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  11,   0, -11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   7,   0,  -7,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  -7,   0,   7,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -11,   0,  11,   0,   0,   0,   0,   0,
     0,   0,  21,   0,   0,   0, -21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  11,   0,   0,   0, -11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   7,   0,   0,   0,  -7,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  11,   0,   0,   0, -11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  21,   0, -21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  11,   0, -11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -11,   0,  11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -21,   0,  21,   0,   0,   0,   0,   0,
     0,   0,  57,   0,   0,   0, -57,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  21,   0,   0,   0, -21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  11,   0,   0,   0, -11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  21,   0,   0,   0, -21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  57,   0, -57,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  21,   0, -21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  11,   0, -11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  21,   0, -21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  21,   0, -21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  11,   0, -11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   7,   0,  -7,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  11,   0, -11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  11,   0, -11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   7,   0,  -7,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   5,   0,  -5,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   7,   0,  -7,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  21,   0, -21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  11,   0, -11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   7,   0,  -7,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  11,   0, -11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  21,   0, -21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  11,   0, -11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -11,   0,  11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -21,   0,  21,   0,   0,   0,   0,   0,
     0,   0, -21,   0,   0,   0,  21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -11,   0,   0,   0,  11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  -7,   0,   0,   0,   7,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -11,   0,   0,   0,  11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  11,   0, -11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   7,   0,  -7,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  -7,   0,   7,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -11,   0,  11,   0,   0,   0,   0,   0,
     0,   0, -11,   0,   0,   0,  11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  -7,   0,   0,   0,   7,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  -5,   0,   0,   0,   5,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  -7,   0,   0,   0,   7,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   7,   0,  -7,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   5,   0,  -5,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  -5,   0,   5,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  -7,   0,   7,   0,   0,   0,   0,   0,
     0,   0,  11,   0,   0,   0, -11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   7,   0,   0,   0,  -7,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   5,   0,   0,   0,  -5,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   7,   0,   0,   0,  -7,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  11,   0, -11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   7,   0,  -7,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  -7,   0,   7,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -11,   0,  11,   0,   0,   0,   0,   0,
     0,   0,  21,   0,   0,   0, -21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  11,   0,   0,   0, -11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   7,   0,   0,   0,  -7,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  11,   0,   0,   0, -11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -57,   0,  57,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -21,   0,  21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -11,   0,  11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -21,   0,  21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -21,   0,  21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -11,   0,  11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  -7,   0,   7,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -11,   0,  11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -11,   0,  11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  -7,   0,   7,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  -5,   0,   5,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  -7,   0,   7,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -21,   0,  21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -11,   0,  11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  -7,   0,   7,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -11,   0,  11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  57,   0, -57,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  21,   0, -21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -21,   0,  21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -57,   0,  57,   0,   0,   0,   0,   0,
     0,   0, -57,   0,   0,   0,  57,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -21,   0,   0,   0,  21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -11,   0,   0,   0,  11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -21,   0,   0,   0,  21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  21,   0, -21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  11,   0, -11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -11,   0,  11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -21,   0,  21,   0,   0,   0,   0,   0,
     0,   0, -21,   0,   0,   0,  21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -11,   0,   0,   0,  11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  -7,   0,   0,   0,   7,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0, -11,   0,   0,   0,  11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  11,   0, -11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   7,   0,  -7,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  -7,   0,   7,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -11,   0,  11,   0,   0,   0,   0,   0,
     0,   0,  21,   0,   0,   0, -21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  11,   0,   0,   0, -11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   7,   0,   0,   0,  -7,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  11,   0,   0,   0, -11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  21,   0, -21,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,  11,   0, -11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -11,   0,  11,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0, -21,   0,  21,   0,   0,   0,   0,   0,
     0,   0,  57,   0,   0,   0, -57,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  21,   0,   0,   0, -21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  11,   0,   0,   0, -11,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,  21,   0,   0,   0, -21,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,-315,   0, 315,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -57,   0,  57,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -21,   0,  21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -57,   0,  57,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -57,   0,  57,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -21,   0,  21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -11,   0,  11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -21,   0,  21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -21,   0,  21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -11,   0,  11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,  -7,   0,   7,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -11,   0,  11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -57,   0,  57,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -21,   0,  21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -11,   0,  11,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0, -21,   0,  21,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,   0,
];


/// Exact Biot-Savart kernel — zero f64 everywhere.
pub struct BiotSavartExact {
    pub n: usize,
    /// NTT-domain kernel mod P1
    pub g1: Vec<[[u64; 3]; 3]>,
    /// NTT-domain kernel mod P2
    pub g2: Vec<[[u64; 3]; 3]>,
}

impl BiotSavartExact {
    /// Precompute the NTT-domain kernel from the exact integer constant.
    /// Zero f64. The kernel values come from Q(√2) rational arithmetic.
    pub fn precompute(n: usize) -> Self {
        assert_eq!(n, 8, "Exact kernel currently supports N=8 only");
        let n3 = n * n * n;

        let mut g1 = vec![[[0u64; 3]; 3]; n3];
        let mut g2 = vec![[[0u64; 3]; 3]; n3];

        for a in 0..3usize {
            for b in 0..3usize {
                // Extract column (a,b) from the flat kernel
                let mut s1: Vec<u64> = (0..n3).map(|j| {
                    let v = KERNEL_N8[j * 9 + a * 3 + b] as i64;
                    biot_savart_ntt::i64_to_mod_pub(v, biot_savart_ntt::P1_PUB)
                }).collect();
                let mut s2: Vec<u64> = (0..n3).map(|j| {
                    let v = KERNEL_N8[j * 9 + a * 3 + b] as i64;
                    biot_savart_ntt::i64_to_mod_pub(v, biot_savart_ntt::P2_PUB)
                }).collect();

                biot_savart_ntt::ntt3d_fwd_pub(&mut s1, n, biot_savart_ntt::P1_PUB, biot_savart_ntt::R1_PUB);
                biot_savart_ntt::ntt3d_fwd_pub(&mut s2, n, biot_savart_ntt::P2_PUB, biot_savart_ntt::R2_PUB);

                for k in 0..n3 {
                    g1[k][a][b] = s1[k];
                    g2[k][a][b] = s2[k];
                }
            }
        }

        BiotSavartExact { n, g1, g2 }
    }

    /// Apply the exact Biot-Savart operator.
    /// Zero f64 on the hot path. Division by D=7680 (±1 truncation).
    pub fn apply(&self, grid: &NSGrid3D) -> Vec<[i64; 3]> {
        let n = self.n;
        let n3 = n * n * n;

        // NTT vorticity
        let mut w1 = [vec![0u64; n3], vec![0u64; n3], vec![0u64; n3]];
        let mut w2 = [vec![0u64; n3], vec![0u64; n3], vec![0u64; n3]];
        for (j, cell) in grid.cells.iter().enumerate() {
            let ws = [cell.w_x, cell.w_y, cell.w_z];
            for c in 0..3 {
                w1[c][j] = biot_savart_ntt::i64_to_mod_pub(ws[c], biot_savart_ntt::P1_PUB);
                w2[c][j] = biot_savart_ntt::i64_to_mod_pub(ws[c], biot_savart_ntt::P2_PUB);
            }
        }
        for c in 0..3 {
            biot_savart_ntt::ntt3d_fwd_pub(&mut w1[c], n, biot_savart_ntt::P1_PUB, biot_savart_ntt::R1_PUB);
            biot_savart_ntt::ntt3d_fwd_pub(&mut w2[c], n, biot_savart_ntt::P2_PUB, biot_savart_ntt::R2_PUB);
        }

        // Pointwise multiply
        let mut u1 = [vec![0u64; n3], vec![0u64; n3], vec![0u64; n3]];
        let mut u2 = [vec![0u64; n3], vec![0u64; n3], vec![0u64; n3]];
        for k in 0..n3 {
            for a in 0..3usize {
                let mut acc1: u64 = 0;
                let mut acc2: u64 = 0;
                for b in 0..3usize {
                    acc1 = (acc1 + biot_savart_ntt::mulmod_pub(self.g1[k][a][b], w1[b][k], biot_savart_ntt::P1_PUB)) % biot_savart_ntt::P1_PUB;
                    acc2 = (acc2 + biot_savart_ntt::mulmod_pub(self.g2[k][a][b], w2[b][k], biot_savart_ntt::P2_PUB)) % biot_savart_ntt::P2_PUB;
                }
                u1[a][k] = acc1;
                u2[a][k] = acc2;
            }
        }

        // INTT
        for c in 0..3 {
            biot_savart_ntt::ntt3d_inv_pub(&mut u1[c], n, biot_savart_ntt::P1_PUB, biot_savart_ntt::R1_PUB);
            biot_savart_ntt::ntt3d_inv_pub(&mut u2[c], n, biot_savart_ntt::P2_PUB, biot_savart_ntt::R2_PUB);
        }

        // CRT lift + exact division by D
        let mut result = vec![[0i64; 3]; n3];
        for j in 0..n3 {
            for c in 0..3 {
                let exact = biot_savart_ntt::crt2_signed_pub(u1[c][j], u2[c][j]);
                result[j][c] = (exact / EXACT_DENOM as i128) as i64;
            }
        }
        result
    }
}

/// Apply exact Biot-Savart and write velocity to grid.
pub fn biot_savart_exact_update(kernel: &BiotSavartExact, grid: &mut NSGrid3D) {
    let velocities = kernel.apply(grid);
    for (i, cell) in grid.cells.iter_mut().enumerate() {
        cell.u_x = velocities[i][0];
        cell.u_y = velocities[i][1];
        cell.u_z = velocities[i][2];
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ns_grid_3d::*;
    use crate::biot_savart::BiotSavartKernel;

    fn taylor_green(n: usize) -> NSGrid3D {
        let dt_scaled = (SCALE as f64 * 0.001) as i64;
        let mut grid = NSGrid3D::new(n, 6, dt_scaled);
        let scale = SCALE as f64;
        let pi = std::f64::consts::PI;
        for ix in 0..n {
            for iy in 0..n {
                for iz in 0..n {
                    let x = 2.0 * pi * ix as f64 / n as f64;
                    let y = 2.0 * pi * iy as f64 / n as f64;
                    let idx = ix * n * n + iy * n + iz;
                    grid.cells[idx].w_x = (2.0 * x.cos() * y.sin() * scale) as i64;
                    grid.cells[idx].w_y = (-2.0 * x.sin() * y.cos() * scale) as i64;
                    grid.cells[idx].w_z = 0;
                }
            }
        }
        grid
    }

    #[test]
    fn test_exact_matches_f64_kernel() {
        let n = 8;
        let grid = taylor_green(n);
        let f64_kernel = BiotSavartKernel::precompute(n);
        let exact_kernel = BiotSavartExact::precompute(n);

        let u_f64 = f64_kernel.apply(&grid);
        let u_exact = exact_kernel.apply(&grid);

        let mut max_diff: i64 = 0;
        for j in 0..(n*n*n) {
            for c in 0..3 {
                let diff = (u_f64[j][c] - u_exact[j][c]).abs();
                if diff > max_diff { max_diff = diff; }
            }
        }
        println!("  Exact vs f64 kernel: max_diff = {}", max_diff);
        // Should be very small — both compute the same mathematical object
        // Difference comes only from f64 rounding in the OLD kernel vs exact here
        assert!(max_diff <= 2, "Exact and f64 kernels diverge: max_diff={}", max_diff);
    }

    #[test]
    fn test_exact_kernel_antisymmetric() {
        // G_ab(delta) = -G_ba(delta) (cross product structure)
        for j in 0..512 {
            for a in 0..3usize {
                for b in (a+1)..3usize {
                    let gab = KERNEL_N8[j * 9 + a * 3 + b];
                    let gba = KERNEL_N8[j * 9 + b * 3 + a];
                    assert_eq!(gab, -gba,
                        "Antisymmetry violated at j={}, ({},{}): {} vs {}", j, a, b, gab, gba);
                }
            }
        }
    }

    #[test]
    fn test_exact_kernel_diagonal_zero() {
        // G_aa(delta) = 0 (diagonal of cross product)
        for j in 0..512 {
            for a in 0..3usize {
                assert_eq!(KERNEL_N8[j * 9 + a * 3 + a], 0,
                    "Diagonal not zero at j={}, a={}", j, a);
            }
        }
    }

    #[test]
    fn test_exact_energy_nonzero() {
        let n = 8;
        let kernel = BiotSavartExact::precompute(n);
        let grid = taylor_green(n);
        let u = kernel.apply(&grid);

        let energy: i128 = u.iter()
            .map(|v| v[0] as i128*v[0] as i128 + v[1] as i128*v[1] as i128 + v[2] as i128*v[2] as i128)
            .sum();
        assert!(energy > 0, "Energy must be positive for TG data");
        println!("  Exact kernel energy: {}", energy);
    }
}

    #[test]
    fn test_exact_200_step_energy_defect_bounded() {
        // 200-step campaign with exact BS kernel.
        // Track energy defect, enstrophy, max|omega|, and ratio at every step.
        // The theorem says |epsilon| / E_N <= 18/SCALE = 0.0018 at every step.
        let n = 8;
        let dt_scaled = 100i64;
        let mut grid = NSGrid3D::new(n, 6, dt_scaled);
        grid.init_taylor_green(SCALE, 1, 1);

        let kernel = BiotSavartExact::precompute(n);

        let mut max_ratio: f64 = 0.0;
        let mut max_abs_defect: i128 = 0;
        let mut defect_growing = false;

        // Track defect history for trend analysis
        let mut defects: Vec<i128> = Vec::new();
        let mut enstrophies: Vec<i128> = Vec::new();
        let mut max_vorts: Vec<i64> = Vec::new();

        for step in 0..200 {
            // Apply exact Biot-Savart
            biot_savart_exact_update(&kernel, &mut grid);

            // Snapshot for advection energy computation
            let snap = grid.cells.clone();

            // Compute advection energy residual: Sum_j omega_c(j) * A^skew_c(j)
            let mut adv_residual: i128 = 0;
            for ix in 0..n {
                for iy in 0..n {
                    for iz in 0..n {
                        for comp in 0..3usize {
                            let idx = ix * n * n + iy * n + iz;
                            let w_c = match comp {
                                0 => snap[idx].w_x,
                                1 => snap[idx].w_y,
                                _ => snap[idx].w_z,
                            };
                            let adv = crate::fused_solver::skew_advection_3d(
                                &snap, n, ix, iy, iz, comp);
                            adv_residual += w_c as i128 * adv as i128;
                        }
                    }
                }
            }

            // Enstrophy
            let enstrophy = grid.total_enstrophy();

            // Max vorticity
            let max_vort = grid.vort_sup_global();

            // Ratio
            let ratio = if enstrophy > 0 {
                (adv_residual.abs() as f64) / (enstrophy as f64)
            } else { 0.0 };

            if ratio > max_ratio { max_ratio = ratio; }
            if adv_residual.abs() > max_abs_defect { max_abs_defect = adv_residual.abs(); }

            defects.push(adv_residual);
            enstrophies.push(enstrophy);
            max_vorts.push(max_vort);

            // Print every 10 steps
            if step % 10 == 0 || step < 5 || step == 199 {
                println!("  step {:3}: |eps|={:>12}, E={:>14}, max|w|={:>6}, ratio={:.2e}",
                    step, adv_residual.abs(), enstrophy, max_vort, ratio);
            }

            // Check: ratio must be below 18/SCALE = 0.0018
            assert!(ratio < 0.0018,
                "Defect-to-enstrophy ratio exceeded bound at step {}: {:.6} > 0.0018",
                step, ratio);

            // Advance vorticity
            grid.advance();
        }

        println!("\n  === 200-STEP SUMMARY ===");
        println!("  Max |epsilon|:           {}", max_abs_defect);
        println!("  Max ratio |eps|/E:       {:.6e}", max_ratio);
        println!("  Bound (18/SCALE):        {:.6e}", 18.0 / SCALE as f64);
        println!("  Ratio < bound?           {}", max_ratio < 0.0018);

        // Check trend: is the defect growing or stable?
        let first_10_avg: f64 = defects[0..10].iter().map(|d| d.abs() as f64).sum::<f64>() / 10.0;
        let last_10_avg: f64 = defects[190..200].iter().map(|d| d.abs() as f64).sum::<f64>() / 10.0;
        println!("  Avg |eps| first 10:      {:.0}", first_10_avg);
        println!("  Avg |eps| last 10:       {:.0}", last_10_avg);
        println!("  Trend:                   {}", if last_10_avg <= first_10_avg * 1.5 {
            "STABLE or DECREASING ✓"
        } else {
            "GROWING ⚠"
        });

        // Max vorticity trend (should decrease in 3D with diffusion)
        println!("  max|w| initial:          {}", max_vorts[0]);
        println!("  max|w| final:            {}", max_vorts[199]);

        // The defect must be bounded AND non-growing for the convergence argument
        assert!(max_ratio < 0.0018, "Defect bound violated");
    }
