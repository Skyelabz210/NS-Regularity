
import json, math, collections, random, statistics, sympy as sp

SAFE = [2,3,5,7,11,13]
TRANSPORT = [3,7,11,13]
PARKING = [2,5]
TIERS = [[2,3,5],[2,3,5,7],[2,3,5,7,11],[2,3,5,7,11,13]]
COMPOSITE_BASES = {
    "cp_9_25_49_11_13":[9,25,49,11,13],
    "cp_27_25_49_11_13":[27,25,49,11,13],
    "cp_27_125_49_11_13":[27,125,49,11,13],
}
N=150000

def prod(xs):
    out=1
    for x in xs:
        out*=x
    return out

def sig(n,basis):
    return tuple(n % m for m in basis)

def signature_counts(nums,basis):
    c=collections.Counter()
    for n in nums:
        c[sig(n,basis)] += 1
    return c

def family_stats_for_basis(primes_list,basis):
    c = signature_counts(primes_list,basis)
    M=prod(basis)
    units=int(sp.totient(M))
    counts=sorted(c.values(), reverse=True)
    total=sum(counts)
    probs=[x/total for x in counts] if total else []
    entropy=-sum(p*math.log(p,2) for p in probs) if probs else 0
    return {
        "basis":basis,
        "modulus":M,
        "unit_residues":units,
        "observed_prime_signatures":len(c),
        "coverage_of_unit_residues":len(c)/units if units else None,
        "entropy_bits":entropy,
        "max_count":max(counts) if counts else 0,
        "min_count":min(counts) if counts else 0,
    }, c

def factor_prime_power(n):
    f=sp.factorint(n)
    if len(f) != 1:
        raise ValueError(f"{n} is not a prime power")
    return next(iter(f.items()))

def local_unit_pair_count(modulus, g):
    p,a = factor_prime_power(modulus)
    phi = (p-1)*p**(a-1)
    if g % p == 0:
        return phi
    return p**(a-1)*(p-2)

def basis_unit_pair_stats(basis,g):
    total_units=1
    survive=1
    for m in basis:
        total_units *= int(sp.totient(m))
        survive *= local_unit_pair_count(m,g)
    return {"total_units":total_units,"survive_count":survive,"unit_survival_rate":survive/total_units}

def egcd(a,b):
    if b==0:
        return (a,1,0)
    g,x1,y1=egcd(b,a%b)
    return (g,y1,x1-(a//b)*y1)

def modinv(a,m):
    g,x,_ = egcd(a,m)
    return None if g!=1 else x%m

def k_reconstruct_stats(main_basis, anchor=13, samples=3000):
    M=prod(main_basis)
    A=anchor
    if math.gcd(M,A)!=1:
        return {"coprime":False,"main_modulus":M,"anchor":A}
    Minv=modinv(M,A)
    rng=random.Random(0)
    maxV=M*A
    ok=0
    for _ in range(samples):
        V=rng.randrange(0,maxV)
        r=V%M
        s=V%A
        k=((s-r)%A * Minv) % A
        R=r+k*M
        good=(R==V)
        ok += int(good)
    return {"coprime":True,"main_modulus":M,"anchor":A,"tests":samples,"reconstruction_rate":ok/samples}

def main():
    primes=list(sp.primerange(2, N+1))
    primes_gt13=[p for p in primes if p>13]
    prime_set=set(primes)

    print(f"Primes total: {len(primes)}")
    print(f"Primes > 13: {len(primes_gt13)}")

    # Safe shell and transport core
    for name, basis in [("safe", SAFE), ("transport", TRANSPORT), ("parking", PARKING)]:
        rep, _ = family_stats_for_basis(primes_gt13, basis)
        M = rep["modulus"]
        units = rep["unit_residues"]
        obs = rep["observed_prime_signatures"]
        cov = rep["coverage_of_unit_residues"]
        print(f"\n{name}: M={M}, phi={units}, observed={obs}, coverage={cov:.4f}")

    # Tier refinement
    print("\nTier refinement:")
    for tier in TIERS:
        c = signature_counts(primes_gt13, tier)
        M = prod(tier)
        phi = int(sp.totient(M))
        print(f"  {tier}: phi({M})={phi}, observed={len(c)}, full={'YES' if len(c)==phi else 'NO'}")

    # Gap corridors on transport core
    gap_classes=[2,4,6,8,10,12,14,16,18,20,22,24,26,28,30]
    print("\nGap corridors on transport core:")
    print(f"  {'gap':>4} {'pairs':>6} {'survival':>10}")
    for g in gap_classes:
        pair_count=0
        candidate_count=0
        for p in primes_gt13:
            q=p+g
            if q<=N:
                candidate_count += 1
                if q in prime_set:
                    pair_count += 1
        surv = pair_count/candidate_count if candidate_count else 0
        print(f"  {g:4d} {pair_count:6d} {surv:10.4f}")

    # Composite bridge law
    print("\nComposite bridge law (unit survival rates):")
    for name, basis in COMPOSITE_BASES.items():
        for g in [2, 6, 30]:
            stats = basis_unit_pair_stats(basis, g)
            print(f"  {name} gap={g}: {stats['unit_survival_rate']:.6f}")

    # K-Elimination reconstruction
    print("\nK-Elimination reconstruction on composites:")
    for label, main in [("9,25,49,11", [9,25,49,11]), ("27,25,49,11", [27,25,49,11]), ("27,125,49,11", [27,125,49,11])]:
        r = k_reconstruct_stats(main, 13)
        print(f"  [{label}] + anchor 13: {r['reconstruction_rate']*100:.1f}%")

if __name__ == "__main__":
    main()
