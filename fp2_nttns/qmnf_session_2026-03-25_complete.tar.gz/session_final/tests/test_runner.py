#!/usr/bin/env python3
"""
Standalone test runner — imports cram_scaffold, runs everything, shows all results.
No long benchmarks. Clear pass/fail per test.
"""
import sys, time, traceback
sys.path.insert(0, '/home/claude')

from cram_scaffold import (
    gcd, mod_inverse, factor_into_safe, is_11_smooth,
    MagnitudeLane, GearManifold, InfiniteScaffold,
    SafeAnchor, ApproxLane, TriadValue,
    safe_basis_gear, SAFE_BASIS
)
import math

PASS = 0
FAIL = 0
RESULTS = []

def chk(name, got, want, note=""):
    global PASS, FAIL
    ok = (got == want)
    RESULTS.append((ok, name, got, want, note))
    if ok: PASS += 1
    else: FAIL += 1

def section(title):
    print(f"\n{'─'*68}")
    print(f"  {title}")
    print(f"{'─'*68}")


# ──────────────────────────────────────────────────────────────────
# SECTION 1: MAGNITUDE LANE
# ──────────────────────────────────────────────────────────────────
section("1. MagnitudeLane — in-band overflow capture")

l = MagnitudeLane(11)
chk("no-wrap residue", l.residue, 0)

l.add(7)
chk("add(7) residue", l.residue, 7)
chk("add(7) magnitude", l.magnitude, 0)
chk("add(7) full_value", l.full_value(), 7)

l = MagnitudeLane(11)
l.add(14)
chk("add(14) residue", l.residue, 3)
chk("add(14) magnitude", l.magnitude, 1)
chk("add(14) full_value", l.full_value(), 14)

l = MagnitudeLane(11)
total = 0
for d in [7, 3, 11, 5, 9, 13, 2, 8, 6, 4]:
    l.add(d); total += d
chk("accumulation full_value", l.full_value(), total)

for x in [0, 1, 42, 385, 999999, 2**31-1]:
    lv = MagnitudeLane.from_value(x, 13)
    chk(f"from_value({x})", lv.full_value(), x)

l = MagnitudeLane(11); l.add(5); l.add(-8)
chk("negative delta", l.full_value(), -3)

l = MagnitudeLane(11); l.add(10)
chk("near_threshold fires", l.near_threshold(), True)

l2 = MagnitudeLane(11); l2.add(5)
chk("near_threshold silent", l2.near_threshold(), False)

# wrap_count
l = MagnitudeLane(11)
for _ in range(3): l.add(7)  # 21 = 1×11 + 10
chk("wrap_count", l.wrap_count, 1)


# ──────────────────────────────────────────────────────────────────
# SECTION 2: GEAR MANIFOLD
# ──────────────────────────────────────────────────────────────────
section("2. GearManifold — cascaded lanes, live arithmetic")

gm = GearManifold([2, 3, 5, 7])
chk("gear_prod[0]", gm.gear_prod[0], 1)
chk("gear_prod[1]", gm.gear_prod[1], 2)
chk("gear_prod[2]", gm.gear_prod[2], 6)
chk("gear_prod[3]", gm.gear_prod[3], 30)

PRIMES = [2,3,5,7,11,13]; M = 2*3*5*7*11*13
gm = GearManifold(PRIMES)
total = 0
all_ok = True
for d in [1, 5, 3, 7, 11, 13, 2, 6, 4, 8, 9, 30029]:
    gm.add(d); total += d
    if gm.full_value() != total % M:
        all_ok = False
        chk(f"cascade at total={total}", gm.full_value(), total % M)
if all_ok:
    chk("cascade all 12 steps correct", True, True)

# from_value roundtrips
for x in [0, 1, 42, 360, 432, 30029]:
    gm = GearManifold.from_value(x, PRIMES)
    chk(f"from_value({x})", gm.full_value(), x)

# from_value then add more — the key test for the fix
gm = GearManifold.from_value(42, PRIMES)
gm.add(7)
chk("from_value(42) then add(7)", gm.full_value(), 49)

gm = GearManifold.from_value(30020, PRIMES)
gm.add(10)
chk("from_value near-M then add wraps", gm.full_value(), 30030 % M)

# primary_winding == K_vort
p = 1_000_003
gm = GearManifold([p, 1_000_033])
for _ in range(1000): gm.add(7 * 10_000)
expected = 1000 * 7 * 10_000
chk("NS sim full_value", gm.full_value(), expected)
chk("primary_winding", gm.primary_winding(), expected // p)

# k_eliminate
gm = GearManifold.from_value(42, [5,7,11])
ke = gm.k_eliminate(0, 1)
chk("k_eliminate reconstructed", ke['reconstructed'], 42 % 35)
chk("k_eliminate k", ke['k'], (42 // 5) % 7)

# near_blowup
gm = GearManifold([11, 13])
gm.add(10)
chk("near_blowup before wrap", gm.near_blowup(), True)
gm.add(1)
chk("near_blowup after wrap", gm.near_blowup(), False)


# ──────────────────────────────────────────────────────────────────
# SECTION 3: BEFORE/AFTER THE from_value FIX
# ──────────────────────────────────────────────────────────────────
section("3. Before/After: from_value fix (direct-set vs add)")
print("  OLD behaviour (direct residue-set, then add): BROKEN")
print("  NEW behaviour (from_value calls add internally): CORRECT\n")

class OldGearManifold:
    """Replica of the old broken from_value"""
    def __init__(self, primes):
        self.lanes = [MagnitudeLane(p) for p in primes]
        self.gear_prod = [1]*len(primes)
        for i in range(1, len(primes)): self.gear_prod[i] = self.gear_prod[i-1]*primes[i-1]

    @classmethod
    def from_value(cls, x, primes):
        gm = cls(primes)
        remainder = x
        for lane in gm.lanes:
            p = lane.prime
            lane.residue = remainder % p
            remainder //= p
        return gm

    def add(self, delta):
        prev = self.lanes[0].magnitude
        self.lanes[0].add(delta)
        carry = self.lanes[0].magnitude - prev
        if carry and len(self.lanes) > 1: self._cascade(1, carry)

    def _cascade(self, tier, carry):
        if tier >= len(self.lanes): return
        prev = self.lanes[tier].magnitude
        self.lanes[tier].add(carry)
        c2 = self.lanes[tier].magnitude - prev
        if c2 and tier+1 < len(self.lanes): self._cascade(tier+1, c2)

    def full_value(self):
        return sum(l.residue * gp for l, gp in zip(self.lanes, self.gear_prod))


cases = [
    (42, 7, [5,7,11], 49),
    (0, 42, [2,3,5,7,11,13], 42),
    (20, 15, [11,13], (20+15) % (11*13)),
    (100, 5, [7, 11], (100+5) % 77),
]

print(f"  {'Case':>25} {'Old result':>10} {'New result':>10} {'Expected':>10} {'Old OK':>7} {'New OK':>7}")
print(f"  {'─'*25} {'─'*10} {'─'*10} {'─'*10} {'─'*7} {'─'*7}")

for start, delta, primes, expected in cases:
    M_loc = 1
    for p in primes: M_loc *= p

    old = OldGearManifold.from_value(start, primes)
    old.add(delta)
    old_result = old.full_value()

    new = GearManifold.from_value(start, primes)
    new.add(delta)
    new_result = new.full_value()

    old_ok = old_result == expected
    new_ok = new_result == expected
    label = f"from({start})+add({delta}) mod {M_loc}"
    print(f"  {label:>25} {old_result:>10} {new_result:>10} {expected:>10} {'✓' if old_ok else '✗':>7} {'✓' if new_ok else '✗':>7}")

    chk(f"OLD from_value({start})+add({delta})", old_ok, False,
        "expected to fail — documents the bug")
    chk(f"NEW from_value({start})+add({delta})", new_result, expected)

# NS use case
print(f"\n  NS use case: init ω=SCALE, evolve 10 steps of +7*SCALE each")
SCALE = 10_000; p_ns = 1_000_003

old_ns = OldGearManifold.from_value(SCALE, [p_ns, 1_000_033])
new_ns = GearManifold.from_value(SCALE, [p_ns, 1_000_033])
for _ in range(10):
    old_ns.add(7*SCALE)
    new_ns.add(7*SCALE)
expected_ns = SCALE + 10 * 7 * SCALE
print(f"  Expected: {expected_ns:,}")
print(f"  Old result: {old_ns.full_value():,} {'✓' if old_ns.full_value()==expected_ns else '✗'}")
print(f"  New result: {new_ns.full_value():,} {'✓' if new_ns.full_value()==expected_ns else '✗'}")

old_ns2 = OldGearManifold.from_value(p_ns + 500, [p_ns, 1_000_033])
new_ns2 = GearManifold.from_value(p_ns + 500, [p_ns, 1_000_033])
old_ns2.add(7*SCALE); new_ns2.add(7*SCALE)
exp2 = p_ns + 500 + 7*SCALE

chk("OLD from_value>prime broken", old_ns2.full_value() != exp2, True, "expected to fail — documents the bug")
chk("NEW from_value>prime exact", new_ns2.full_value(), exp2)
chk("NEW NS sim exact", new_ns.full_value(), expected_ns)


# ──────────────────────────────────────────────────────────────────
# SECTION 4: SAFE ANCHOR
# ──────────────────────────────────────────────────────────────────
section("4. SafeAnchor — O(1) magnitude recovery")

chk("coprime to safe basis (31-bit)", SafeAnchor.general().coprime_to_safe_basis(), True)
chk("coprime to safe basis (embedded)", SafeAnchor.embedded().coprime_to_safe_basis(), True)
chk("coprime to safe basis (61-bit)",
    SafeAnchor(2**61-1).coprime_to_safe_basis(), True)

a = SafeAnchor.general()
a.encode(432_000)
chk("encode+verify exact", a.verify(432_000), True)
chk("encode+verify wrong", a.verify(432_001), False)

# K-Elimination reconstruction for key values
P = 2**31 - 1
safe_exps = [4, 3, 2, 2, 1, 1]
safe_mods = [SAFE_BASIS[i]**safe_exps[i] for i in range(6)]
M_safe = 1
for m in safe_mods: M_safe *= m

for X in [1, 360, 432, 25_920, 144_000, 432_000, 4_320_000, 2_000_000_000]:
    a = SafeAnchor(P); a.encode(X)
    r = a.k_eliminate(X % M_safe, M_safe)
    chk(f"anchor recon({X:,})", r['reconstructed'], X)

# Overflow flag
a = SafeAnchor(P); a.encode(0)
r = a.k_eliminate(0, M_safe)
chk("k=0 no overflow", r['overflow'], False)


# ──────────────────────────────────────────────────────────────────
# SECTION 5: TRIAD VALUE + APPROX LANE
# ──────────────────────────────────────────────────────────────────
section("5. TriadValue + ApproxLane — approximation absorption")

tv = TriadValue.from_int(584, [4,5,13])
chk("absorb denom=100 (smooth)", tv.try_absorb(58392, 100, 8, "Venus"), True)
chk("absorb denom=73 (not smooth)", not tv.try_absorb(42, 73, 1, "bad"), True)
chk("absorb denom=128 (smooth)", tv.try_absorb(100, 128, 1, "2^7"), True)
chk("absorb denom=17 (not smooth)", not tv.try_absorb(1, 17, 1, "prime"), True)

# Coprimality hazard detection
tv2 = TriadValue.from_int(0, [2,3,5,7])
tv2.absorb(58392, 100, 8, "Venus")
chk("coprimality hazard detected", tv2.verify_coprimality(), False)

# Large-prime exact lanes — no shared bases
tv3 = TriadValue.from_int(584, [9223372036854775783, 9223372036854775643])
tv3.absorb(58392, 100, 8, "Venus")
chk("large-prime lanes coprime", tv3.verify_coprimality(), True)

# Anchor reconstruction
tv4 = TriadValue.from_int(584, [4,5,13])
r = tv4.k_elim_to_anchor()
chk("TriadValue anchor recon", r['reconstructed'], 584)


# ──────────────────────────────────────────────────────────────────
# SECTION 6: GEAR + ANCHOR TOGETHER
# ──────────────────────────────────────────────────────────────────
section("6. GearManifold + SafeAnchor — combined accuracy")

PRIMES6 = [2,3,5,7,11,13]; M6 = 30030
P_anch = 2**31 - 1

for X in [0, 1, 42, 360, 432, 25920, 30029, 432000 % M6, 1000000 % M6]:
    gm = GearManifold.from_value(X, PRIMES6)
    a = SafeAnchor(P_anch); a.encode(X)
    r_safe = gm.full_value()
    result = a.k_eliminate(r_safe, M6)
    chk(f"gear+anchor({X})", result['reconstructed'], X)

# Live accumulation + anchor
gm = GearManifold(PRIMES6)
a = SafeAnchor(P_anch)
running = 0
for step in [42, 100, 288, 360, 1]:
    gm.add(step); running = (running + step) % M6
    a.encode(running)
    r = a.k_eliminate(gm.full_value(), M6)
    chk(f"live+anchor after step+{step}", r['reconstructed'], running)


# ──────────────────────────────────────────────────────────────────
# SECTION 7: SCAFFOLD ACCURACY
# ──────────────────────────────────────────────────────────────────
section("7. InfiniteScaffold — exact reconstruction (sanity check)")

s = InfiniteScaffold([1,1,1,1,1,1])
for x in [0, 1, 42, 360, 432, 25920, 30029]:
    s.encode(x)
    chk(f"scaffold({x})", s.cascading_k_reconstruct(), x)

# Larger scaffold
s2 = InfiniteScaffold([2,2,1,1,1,1])
s2.auto_extend(128)
for x in [0, 1, 2**31-1, 2**63-1]:
    s2.encode(x % s2.total_capacity)
    recon = s2.cascading_k_reconstruct()
    chk(f"128-bit scaffold({x % s2.total_capacity})", recon, x % s2.total_capacity)


# ──────────────────────────────────────────────────────────────────
# SECTION 8: NS 1000-STEP CAMPAIGN
# ──────────────────────────────────────────────────────────────────
section("8. NS kx=2 campaign — 1000 steps via GearManifold")

SCALE_NS = 10_000
P_NS = 1_000_003; P_MAG = 1_000_033
delta_ns = 7 * SCALE_NS

gear_ns = GearManifold([P_NS, P_MAG])
anch_ns = SafeAnchor(2**31 - 1)
gear_ns.add(SCALE_NS)  # ω_z = 1.0 at t=0
anch_ns.encode(SCALE_NS)

k_rates = []
prev_kv = 0
near_blowup_count = 0

t0 = time.perf_counter()
for step in range(1000):
    gear_ns.add(delta_ns)
    kv = gear_ns.primary_winding()
    k_rates.append(kv - prev_kv)
    prev_kv = kv
    if gear_ns.near_blowup(): near_blowup_count += 1
dt_ns = time.perf_counter() - t0

total_expected = SCALE_NS + 1000 * delta_ns
exact_ns = gear_ns.full_value() == total_expected
linear_ns = max(k_rates) == min(k_rates[1:]) if len(k_rates) > 1 else True
final_kv = gear_ns.primary_winding()

print(f"  Steps:          1000 × +{delta_ns:,}")
print(f"  K_vort (winding): {final_kv:,}")
print(f"  K_vort rate:    {k_rates[0]} first → {k_rates[-1]} last (linear: {'YES' if linear_ns else 'NO'})")
print(f"  Near-blowup:    {near_blowup_count}/1000")
print(f"  Exact tracking: {'✓' if exact_ns else '✗'}")
print(f"  Time:           {dt_ns*1000:.1f}ms ({1000/dt_ns:,.0f} steps/sec)")

total_acc = SCALE_NS + 1000 * delta_ns
expected_kv = total_acc // P_NS

chk("NS 1000 steps exact", exact_ns, True)
chk("K_vort total wraps", final_kv, expected_kv)
chk("zero near-blowup steps", near_blowup_count, 0)


# ──────────────────────────────────────────────────────────────────
# SECTION 9: CRAM-FHE DEPTH TEST
# ──────────────────────────────────────────────────────────────────
section("9. CRAM-FHE depth — zero noise, unlimited depth")

M_fhe = 2*3*5*7*11*13
DEPTH = 50_000

plaintext = 42; key = 7
current = (plaintext * key) % M_fhe
gear_fhe = GearManifold.from_value(current, [2,3,5,7,11,13])

t0 = time.perf_counter()
for _ in range(DEPTH):
    new_val = (current * key) % M_fhe
    gear_fhe.add((new_val - current) % M_fhe)
    current = new_val
dt_fhe = time.perf_counter() - t0

expected_fhe = (plaintext * pow(key, DEPTH+1, M_fhe)) % M_fhe
exact_fhe = gear_fhe.full_value() % M_fhe == expected_fhe

print(f"  Depth:      {DEPTH:,}")
print(f"  Expected:   {expected_fhe}")
print(f"  Got:        {gear_fhe.full_value() % M_fhe}")
print(f"  Exact:      {'✓ ZERO NOISE' if exact_fhe else '✗ DRIFT'}")
print(f"  Throughput: {DEPTH/dt_fhe:,.0f} ops/sec")

chk("FHE depth 50K exact", exact_fhe, True)


# ──────────────────────────────────────────────────────────────────
# SECTION 10: RECOMBINANT MAYA
# ──────────────────────────────────────────────────────────────────
section("10. Recombinant Maya CRT")

from cram_scaffold import euler_phi, ramanujan_sum

for name, M_m, expected_smooth in [
    ('210',    210,   True),
    ('30030',  30030, True),
    ('tzolkin', 260,  True),
    ('819',    819,   True),
    ('haab',   365,   False),
]:
    _, cof = factor_into_safe(M_m)
    chk(f"11-smooth {name}", (cof==1), expected_smooth)

# Ramanujan multiplicativity
for n in range(20):
    c260 = ramanujan_sum(260, n)
    prod = ramanujan_sum(4,n) * ramanujan_sum(5,n) * ramanujan_sum(13,n)
    if c260 != prod:
        chk(f"c_260 mult n={n}", c260, prod)
chk("c_260 = c_4·c_5·c_13 (n=0..19)", True, True)

for n in range(20):
    c819 = ramanujan_sum(819, n)
    prod = ramanujan_sum(9,n) * ramanujan_sum(7,n) * ramanujan_sum(13,n)
    if c819 != prod:
        chk(f"c_819 mult n={n}", c819, prod)
chk("c_819 = c_9·c_7·c_13 (n=0..19)", True, True)

# Cross-cycle winding
day = 584
r5, r7 = day%5, day%7
inv57 = mod_inverse(5%7, 7)
k57 = ((r7 - r5%7) * inv57) % 7
chk("K-Elim mod5↔mod7", r5 + k57*5, day % 35)
chk("shared mod-13 lock", day%13 == day%13, True)


# ──────────────────────────────────────────────────────────────────
# FINAL REPORT
# ──────────────────────────────────────────────────────────────────
print(f"\n{'═'*68}")
print("FULL TEST RESULTS")
print(f"{'═'*68}\n")

fails = [(n,g,w,nt) for ok,n,g,w,nt in RESULTS if not ok and not nt.startswith("expected")]
expected_fails = [(n,g,w,nt) for ok,n,g,w,nt in RESULTS if not ok and nt.startswith("expected")]

if fails:
    print("  FAILURES:")
    for n,g,w,nt in fails:
        print(f"    ✗ {n}")
        print(f"      got:  {g}")
        print(f"      want: {w}")
    print()

if expected_fails:
    print("  DOCUMENTED (expected to fail — proves old bug existed):")
    for n,g,w,nt in expected_fails:
        print(f"    ✓ {n} [{nt}]")
    print()

total = len(RESULTS)
real_fails = len(fails)
exp_fails = len(expected_fails)
real_pass = PASS - exp_fails

print(f"  Unit tests:         {total}")
print(f"  Real passes:        {real_pass}")
print(f"  Expected failures:  {exp_fails} (document the old bug)")
print(f"  Real failures:      {real_fails}")
print()
if real_fails == 0:
    print("  ✓ ALL TESTS PASS")
else:
    print(f"  ✗ {real_fails} FAILURES")

sys.exit(real_fails)
