//! # QCID NS Bridge — F_p² Dual-Track NS Solver
//!
//! Physics on residue (a). Contraction on norm (a²-δb²). Tracks never interfere.
//!
//! ## Architecture
//! - `fp2`: F_p² arithmetic (a + b√δ, norm, Frobenius, inverse)
//! - `dual_track`: DualTrackState with independent physics/contraction tracks
//! - `stencil_fp2`: Nested radical computation for stencil eigenvalues
//! - `pipeline`: Full NS step with F_p² dual track
//!
//! ## Verified Properties (72/72 Python prototype)
//! - F_p² arithmetic correct on all Safe Basis primes
//! - Physics (a,b) preserved under norm Sqr
//! - All Sqr orbits bounded — converge to {0,1}
//! - Effective range grows as p^(2^k) — superexponential
//! - Ring homomorphism holds through F_p²
//! - Stencil eigenvalue division exact

pub mod fp2;
pub mod dual_track;

// Re-exports
pub use fp2::Fp2;
pub use dual_track::DualTrackState;
