#!/usr/bin/env python3
"""
INFINITE SCAFFOLD BENCHMARK
============================
How high is the sky? Stack coprime tiers indefinitely via
K-Elimination at every level. Measure capacity, reconstruction
accuracy, and performance as the scaffold grows.
"""
import time
import math
import sys
from typing import List, Tuple, Optional, Dict

# ═══════════════════════════════════════════════════════════════════
# PRIMITIVES
# ═══════════════════════════════════════════════════════════════════

SAFE_BASIS = [2, 3, 5, 7, 11, 13]

def gcd(a: int, b: int) -> int:
    while b: a, b = b, a % b
    return abs(a)

def mod_inverse(a: int, m: int) -> Optional[int]:
    if a == 0 or m == 0: return None
    old_r, r = a % m, m
    old_s, s = 1, 0
    while r != 0:
        q = old_r // r
        old_r, r = r, old_r - q * r
        old_s, s = s, old_s - q * s
    if old_r != 1: return None
    return old_s % m

def is_prime(n: int) -> bool:
    if n < 2: return False
    if n < 4: return True
    if n % 2 == 0 or n % 3 == 0: return False
    # Deterministic Miller-Rabin for 64-bit
    d, s = n - 1, 0
    while d % 2 == 0: d //= 2; s += 1
    for a in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]:
        if a >= n: continue
        x = pow(a, d, n)
        if x == 1 or x == n - 1: continue
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1: break
        else:
            return False
    return True

def next_prime_after(n: int) -> int:
    """Bertrand guarantees a prime in (n, 2n). Find it."""
    if n < 2: return 2
    candidate = n + 1 if n % 2 == 0 else n + 2
    while not is_prime(candidate):
        candidate += 2
    return candidate

def factor_into_safe(n: int) -> Tuple[List[Tuple[int,int]], int]:
    """Factor n into Safe Basis powers. Returns (factors, cofactor)."""
    factors = []
    for p in SAFE_BASIS:
        e = 0
        while n % p == 0: n //= p; e += 1
        if e > 0: factors.append((p, e))
    return factors, n

def is_11_smooth(n: int) -> bool:
    _, cofactor = factor_into_safe(n)
    return cofactor == 1

def euler_phi(n: int) -> int:
    result, temp = n, n
    p = 2
    while p * p <= temp:
        if temp % p == 0:
            while temp % p == 0: temp //= p
            result -= result // p
        p += 1
    if temp > 1: result -= result // temp
    return result

def ramanujan_sum(q: int, n: int) -> int:
    g = gcd(q, n)
    q_g = q // g
    if q_g == 1: return euler_phi(q)
    mu = 1; temp = q_g; p = 2
    while p * p <= temp:
        if temp % p == 0:
            count = 0
            while temp % p == 0: temp //= p; count += 1
            if count > 1: return 0
            mu *= -1
        p += 1
    if temp > 1: mu *= -1
    return mu * euler_phi(q) // euler_phi(q_g)


# ═══════════════════════════════════════════════════════════════════
# MAGNITUDE LANE & GEAR MANIFOLD
# ═══════════════════════════════════════════════════════════════════

class MagnitudeLane:
    """
    A single CRT lane that auto-captures its own overflow.
    Invariant at all times: full_value() == accumulated_sum_of_adds
    No silent modular wrapping. Every carry lives in self.magnitude.
    """
    __slots__ = ('prime', 'residue', 'magnitude', 'wrap_count')

    def __init__(self, prime: int):
        self.prime = prime
        self.residue = 0       # r ∈ [0, prime)
        self.magnitude = 0     # κ ∈ ℤ — lifted winding (K_vort in NS)
        self.wrap_count = 0    # total wraps since creation

    @classmethod
    def from_value(cls, x: int, prime: int) -> 'MagnitudeLane':
        lane = cls(prime)
        if x >= 0:
            lane.residue = x % prime
            lane.magnitude = x // prime
        else:
            lane.residue = (-x) % prime
            if lane.residue:
                lane.residue = prime - lane.residue
                lane.magnitude = -((-x) // prime) - 1
            else:
                lane.magnitude = -((-x) // prime)
        return lane

    def add(self, delta: int):
        """Add delta. Overflow automatically promoted to magnitude."""
        if delta >= 0:
            new_val = self.residue + delta
            if new_val >= self.prime:
                wraps = new_val // self.prime
                self.residue = new_val % self.prime
                self.magnitude += wraps
                self.wrap_count += wraps
            else:
                self.residue = new_val
        else:
            delta_abs = -delta
            if self.residue >= delta_abs:
                self.residue -= delta_abs
            else:
                deficit = delta_abs - self.residue
                wraps = (deficit + self.prime - 1) // self.prime
                self.residue = (wraps * self.prime - deficit) % self.prime
                self.magnitude -= wraps
                self.wrap_count += wraps

    def full_value(self) -> int:
        """Exact reconstruction: r + κ·p."""
        return self.residue + self.magnitude * self.prime

    def wrap_proximity(self) -> int:
        """Steps until next wrap. 0 = one step away."""
        return self.prime - self.residue - 1

    def near_threshold(self, margin: int = 1) -> bool:
        return self.wrap_proximity() < margin + 1

    def checkpoint(self) -> int:
        """Return and reset magnitude accumulator."""
        saved, self.magnitude, self.wrap_count = self.magnitude, 0, 0
        return saved

    def __repr__(self):
        return (f"MagnitudeLane(p={self.prime}, r={self.residue}, "
                f"κ={self.magnitude}, full={self.full_value()})")


class GearManifold:
    """
    Multi-tier cascade of MagnitudeLanes.

    Full value = Σᵢ lane[i].residue × gear_prod[i]
    where gear_prod[i] = Π_{j<i} prime[j]

    This is Garner reconstruction — built incrementally, live.
    For NS: vorticity in lane[0], BKM winding in lane[0].magnitude.
    """

    def __init__(self, primes: list):
        assert primes, "Need at least one prime"
        self.lanes = [MagnitudeLane(p) for p in primes]
        self.gear_prod = [1] * len(primes)
        for i in range(1, len(primes)):
            self.gear_prod[i] = self.gear_prod[i-1] * primes[i-1]

    @classmethod
    def from_value(cls, x: int, primes: list) -> 'GearManifold':
        """
        Decompose x into gear tiers via add(), keeping from_value
        and add() on identical footing — both accumulate from zero.
        """
        gm = cls(primes)
        if x != 0:
            gm.add(x)
        return gm

    def add(self, delta: int):
        """Add to primary lane, cascade wraps upward automatically."""
        prev = self.lanes[0].magnitude
        self.lanes[0].add(delta)
        carry = self.lanes[0].magnitude - prev
        if carry and len(self.lanes) > 1:
            self._cascade(1, carry)

    def _cascade(self, tier: int, carry: int):
        if tier >= len(self.lanes):
            return
        prev = self.lanes[tier].magnitude
        self.lanes[tier].add(carry)
        new_carry = self.lanes[tier].magnitude - prev
        if new_carry and tier + 1 < len(self.lanes):
            self._cascade(tier + 1, new_carry)

    def full_value(self) -> int:
        """Exact reconstruction via gear products.
        
        Returns the accumulated value MOD total capacity (product of all primes).
        For negative accumulated sums, this wraps to capacity - |sum| (non-negative).
        For signed winding number, use primary_winding().
        For signed per-lane value, use lanes[i].full_value().
        """
        return sum(l.residue * gp for l, gp in zip(self.lanes, self.gear_prod))

    def primary_residue(self) -> int:
        return self.lanes[0].residue

    def primary_winding(self) -> int:
        """K_vort = winding of the primary lane. Zero extra work."""
        return self.lanes[0].magnitude

    def total_capacity(self) -> int:
        prod = 1
        for l in self.lanes:
            prod *= l.prime
        return prod

    def near_blowup(self, margin: int = 1) -> bool:
        """True if any lane is within margin of its prime."""
        return any(l.near_threshold(margin) for l in self.lanes)

    def k_eliminate(self, from_tier: int, to_tier: int) -> Optional[Dict]:
        """
        Partial reconstruction covering tiers 0..to_tier inclusive.
        """
        if to_tier >= len(self.lanes): return None
        partial = sum(self.lanes[i].residue * self.gear_prod[i]
                      for i in range(to_tier + 1))
        k = self.lanes[to_tier].residue
        return {'k': k,
                'from_prime': self.lanes[from_tier].prime,
                'to_prime': self.lanes[to_tier].prime,
                'reconstructed': partial}

    def report(self) -> list:
        """(prime, residue, magnitude, gear_prod) for each tier."""
        return [(l.prime, l.residue, l.magnitude, gp)
                for l, gp in zip(self.lanes, self.gear_prod)]

    def __repr__(self):
        tiers = ', '.join(f'p{l.prime}:r{l.residue}/κ{l.magnitude}' for l in self.lanes)
        return f'GearManifold([{tiers}])'


# ══ Convenience: safe-basis GearManifold ═══════════════════════════
def safe_basis_gear(exponents: list = None) -> GearManifold:
    """Build a GearManifold over safe-basis prime powers."""
    if exponents is None:
        exponents = [1] * 6
    primes = [p**e for p, e in zip(SAFE_BASIS, exponents)]
    return GearManifold(primes)


# ═══════════════════════════════════════════════════════════════════
# THE SCAFFOLD
# ═══════════════════════════════════════════════════════════════════

class ScaffoldTier:
    """One tier of the infinite scaffold: a modulus with its residue."""
    __slots__ = ('modulus', 'residue', 'label', 'bits')

    def __init__(self, modulus: int, label: str):
        self.modulus = modulus
        self.residue = 0
        self.label = label
        self.bits = math.log2(modulus) if modulus > 1 else 0


class InfiniteScaffold:
    """
    Recursively extensible CRT scaffold.

    Layer 0: Safe Basis composites {2,3,5,7,11,13}
    Layer 1+: Alternating prime anchors and composite scaffolding
    ...ad infinitum.
    """

    def __init__(self, safe_exponents: List[int] = None):
        self.tiers: List[ScaffoldTier] = []
        self.total_bits = 0.0
        self.total_capacity = 1

        if safe_exponents is None:
            safe_exponents = [1] * len(SAFE_BASIS)

        for i, (p, e) in enumerate(zip(SAFE_BASIS, safe_exponents)):
            m = p ** e
            tier = ScaffoldTier(m, f"Safe({p}^{e})")
            self.tiers.append(tier)
            self.total_bits += tier.bits
            self.total_capacity *= m

    def add_prime_anchor(self, p: int) -> 'InfiniteScaffold':
        """Add a large prime as the next scaffold tier."""
        assert is_prime(p), f"{p} is not prime"
        assert all(gcd(p, t.modulus) == 1 for t in self.tiers), "Coprimality violation"
        tier = ScaffoldTier(p, f"Anchor(P={p})")
        self.tiers.append(tier)
        self.total_bits += tier.bits
        self.total_capacity *= p
        return self

    def add_composite_scaffold(self, modulus: int, label: str = "") -> 'InfiniteScaffold':
        """Add a composite coprime scaffold tier."""
        assert all(gcd(modulus, t.modulus) == 1 for t in self.tiers), \
            f"Coprimality violation: {modulus} shares factor with existing tier"
        lbl = label or f"Scaffold({modulus})"
        tier = ScaffoldTier(modulus, lbl)
        self.tiers.append(tier)
        self.total_bits += tier.bits
        self.total_capacity *= modulus
        return self

    def auto_extend(self, target_bits: int = 1000) -> 'InfiniteScaffold':
        """Automatically extend scaffold to target capacity in bits."""
        last_prime = max(t.modulus for t in self.tiers if is_prime(t.modulus)) \
            if any(is_prime(t.modulus) for t in self.tiers) else 13

        while self.total_bits < target_bits:
            p = next_prime_after(last_prime)
            if all(gcd(p, t.modulus) == 1 for t in self.tiers):
                self.add_prime_anchor(p)
                last_prime = p

                pm1 = p - 1
                safe_factors, cofactor = factor_into_safe(pm1)
                if safe_factors:
                    scaffold_mod = 1
                    for base, exp in safe_factors:
                        candidate = base ** exp
                        if all(gcd(candidate, t.modulus) == 1 for t in self.tiers):
                            scaffold_mod *= candidate
                    if scaffold_mod > 1:
                        self.add_composite_scaffold(scaffold_mod, f"Scaffold(from {p}-1)")
            else:
                last_prime = p
        return self

    def encode(self, value: int):
        """Encode a value into all scaffold tiers."""
        for tier in self.tiers:
            tier.residue = value % tier.modulus

    def k_eliminate(self, tier_a: int, tier_b: int) -> Optional[Dict]:
        """K-Elimination between two tiers by index."""
        ta = self.tiers[tier_a]
        tb = self.tiers[tier_b]
        mi = mod_inverse(ta.modulus % tb.modulus, tb.modulus)
        if mi is None: return None
        diff = (tb.residue - (ta.residue % tb.modulus)) % tb.modulus
        k = (diff * mi) % tb.modulus
        return {
            'k': k,
            'from': ta.label,
            'to': tb.label,
            'reconstructed': ta.residue + k * ta.modulus
        }

    def full_reconstruct(self) -> int:
        """Garner reconstruction across ALL tiers."""
        if not self.tiers: return 0
        result = self.tiers[0].residue
        product = self.tiers[0].modulus

        for i in range(1, len(self.tiers)):
            mi = self.tiers[i].modulus
            ri = self.tiers[i].residue

            pm = product % mi
            inv = mod_inverse(pm, mi)
            if inv is None: continue

            diff = (ri - (result % mi)) % mi
            t = (diff * inv) % mi
            result += product * t
            product *= mi

        return result

    def cascading_k_reconstruct(self) -> int:
        """
        Hierarchical K-Elimination reconstruction:
        Start from tier 0, K-Eliminate with tier 1, then with tier 2, etc.
        """
        if not self.tiers: return 0
        result = self.tiers[0].residue
        product = self.tiers[0].modulus

        for i in range(1, len(self.tiers)):
            mi = self.tiers[i].modulus
            ri = self.tiers[i].residue

            pm = product % mi
            inv = mod_inverse(pm, mi)
            if inv is None: continue

            diff = (ri - (result % mi)) % mi
            k = (diff * inv) % mi
            result = result + k * product
            product *= mi

        return result

    def verify(self, original: int) -> bool:
        """Verify that all residues are consistent with original value."""
        return all(original % t.modulus == t.residue for t in self.tiers)


# ═══════════════════════════════════════════════════════════════════
# SAFE ANCHOR
# ═══════════════════════════════════════════════════════════════════

class SafeAnchor:
    """
    Single large prime anchor for the Recombinant CRT Bridge.
    """
    ANCHORS = {
        'embedded': 8_191,                         # 13-bit (2^13 - 1)
        'general': 2_147_483_647,                   # 31-bit (2^31 - 1)
        'high': 2_305_843_009_213_693_951,           # 61-bit (2^61 - 1)
        'crtbigint': 9_223_372_036_854_775_783,      # 63-bit (existing lane 0)
    }

    def __init__(self, prime: int):
        self.prime = prime
        self.residue = 0

    @classmethod
    def general(cls) -> 'SafeAnchor':
        return cls(cls.ANCHORS['general'])

    @classmethod
    def embedded(cls) -> 'SafeAnchor':
        return cls(cls.ANCHORS['embedded'])

    def encode(self, x: int):
        """Record X's residue mod P."""
        self.residue = x % self.prime

    def k_eliminate(self, r_safe: int, m_safe: int) -> dict:
        """
        Recover the global winding number k and reconstruct X.
        """
        inv = mod_inverse(m_safe % self.prime, self.prime)
        if inv is None:
            return {'k': None, 'reconstructed': None, 'overflow': True,
                    'error': 'M_safe not invertible mod P (shared factor)'}
        diff = (self.residue - r_safe % self.prime) % self.prime
        k = (diff * inv) % self.prime
        reconstructed = r_safe + k * m_safe
        return {
            'k': k,
            'reconstructed': reconstructed,
            'overflow': (k >= self.prime),
            'capacity_used_pct': k * 100 // self.prime,
        }

    def verify(self, x: int) -> bool:
        return self.residue == x % self.prime

    def coprime_to_safe_basis(self) -> bool:
        return all(gcd(self.prime, p) == 1 for p in SAFE_BASIS)

    def total_capacity(self, m_safe: int) -> int:
        return m_safe * self.prime

    def total_bits(self, m_safe: int) -> float:
        return math.log2(m_safe) + math.log2(self.prime)

    def __repr__(self):
        return f"SafeAnchor(P={self.prime}, r={self.residue})"


# ═══════════════════════════════════════════════════════════════════
# TRIAD VALUE — Exact + Approx unified
# ═══════════════════════════════════════════════════════════════════

class ApproxLane:
    """Single prime-power sub-lane with frozen error."""
    def __init__(self, prime, exponent, scaled_value, epsilon, source):
        self.prime = prime
        self.exponent = exponent
        self.modulus = prime ** exponent
        self.residue = abs(scaled_value) % self.modulus
        self.epsilon = epsilon
        self.source = source

    def __repr__(self):
        return (f"ApproxLane(mod {self.prime}^{self.exponent}={self.modulus}, "
                f"r={self.residue}, ε={self.epsilon})")


class TriadValue:
    """
    Unified exact + approximate CRT space with anchor.
    """

    def __init__(self, exact_residues: dict, exact_moduli: list,
                 anchor: SafeAnchor = None):
        self.exact_residues = exact_residues
        self.exact_moduli = exact_moduli
        self.approx_lanes = []
        self.anchor = anchor or SafeAnchor.general()

    @classmethod
    def from_int(cls, value: int, moduli: list,
                 anchor: SafeAnchor = None) -> 'TriadValue':
        an = anchor or SafeAnchor.general()
        residues = {m: value % m for m in moduli}
        tv = cls(residues, moduli, an)
        an.encode(value)
        return tv

    def absorb(self, scaled_numerator: int, denominator: int,
               epsilon: int, source: str):
        """
        Recombinant Bridge: absorb an approximation via denominator factoring.
        Denominator must be 11-smooth (factors only in {2,3,5,7,11}).
        """
        factors, cofactor = factor_into_safe(denominator)
        assert cofactor == 1, (f"Denominator {denominator} not 11-smooth "
                               f"(cofactor {cofactor})")
        for prime, exp in factors:
            self.approx_lanes.append(
                ApproxLane(prime, exp, scaled_numerator, epsilon, source))

    def try_absorb(self, scaled_numerator: int, denominator: int,
                   epsilon: int, source: str) -> bool:
        """Like absorb() but returns False instead of asserting."""
        factors, cofactor = factor_into_safe(denominator)
        if cofactor != 1:
            return False
        for prime, exp in factors:
            self.approx_lanes.append(
                ApproxLane(prime, exp, scaled_numerator, epsilon, source))
        return True

    def exact_product(self) -> int:
        result = 1
        for m in self.exact_moduli:
            result *= m
        return result

    def k_elim_to_anchor(self) -> dict:
        """O(1) magnitude recovery via the Safe Anchor."""
        if not self.exact_moduli:
            return {'k': 0, 'reconstructed': 0, 'overflow': False}

        result = self.exact_residues[self.exact_moduli[0]]
        product = self.exact_moduli[0]

        for i in range(1, len(self.exact_moduli)):
            mi = self.exact_moduli[i]
            ri = self.exact_residues[mi]
            pm = product % mi
            inv = mod_inverse(pm, mi)
            if inv is None:
                continue
            diff = (ri - result % mi) % mi
            t = (diff * inv) % mi
            result += product * t
            product *= mi

        return self.anchor.k_eliminate(result, product)

    def verify_coprimality(self) -> bool:
        """All lanes must be pairwise coprime for CRT to be valid."""
        all_moduli = self.exact_moduli + [al.modulus for al in self.approx_lanes]
        for i in range(len(all_moduli)):
            for j in range(i + 1, len(all_moduli)):
                if gcd(all_moduli[i], all_moduli[j]) != 1:
                    return False
        return True
