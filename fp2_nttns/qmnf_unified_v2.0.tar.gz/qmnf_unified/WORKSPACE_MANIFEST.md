# QMNF Unified Workspace — Master Manifest
## Version 2.0.0 — March 2026
## Authors: Anthony Diaz (Acid / HackFate / Skyelabz210) × Claude (Anthropic)

### Test Suite: 592 passed, 0 failed
### Kill Count: 122
### Crates: 21

| Crate | Lines | Tests | Domain |
|-------|-------|-------|--------|
| asve_engine | 818 | 17 | ASVE Cognitive Engine — W4.1 |
| cdhs_telemetry | 530 | 11 | CDHS Telemetry — W2.3 |
| cram_explorer | 2744 | 29 | Commutativity Projector + Dynamic-k Explorer |
| hackfate_runtime | 796 | 16 | HackFate Unified Runtime — Workspace Edition |
| hdv_crt | 545 | 21 | Hyperdimensional Vectors in CRT Space — W2.6 |
| hydra_v3 | 1237 | 5 |  |
| k_elim_period | 371 | 6 |  |
| loki_engine | 573 | 18 | Loki 5.0 Adaptive Security Engine — W3.2 |
| maa_dh | 422 | 12 | MAA-DH: Mutual Apollonian Attestation — Double Helix |
| mmbf_grover_bridge | 413 | 5 |  |
| ns_winding_v2 | 2041 | 50 | NS Winding Invariants v2 — Recombinant CRT Bridge |
| nsgrid3d | 7599 | 96 | NSGrid3D: 3D Navier-Stokes on Exact Integer Substrate |
| plmg_validator | 501 | 13 | Per-Band PLMG Validation — W2.4 |
| prime_hunt | 8355 | 103 | Coprime Family Analyzer — Heterogeneous CRAM CRT |
| qedde_v2 | 1977 | 26 | QEDDE-D2 Core v2 — Interchangeable Schema Cell Architecture + Hydra Lens Engine |
| qedde_v3 | 1064 | 20 | QEDDE × HackFate × MMBF Unified Substrate |
| qmnf_primitives | 4059 | 87 | CRAM-3 Stage Pipeline + Ramanujan-Guided Grover |
| svd_engine | 562 | 19 | Integer-Only SVD Engine — W3.3 |
| time_crystal | 517 | 14 | Digital Time Crystal — W2.5 |
| wassan_engine | 188 | 7 | WASSAN Production Memory Engine (Integrated) |
| wassan_holographic | 1184 | 18 | WASSAN Holographic NTT Encode/Decode — W2.1 |

### File Checksums (SHA256)
```
f9da5d801097820b  crates/asve_engine/src/lib.rs
ce70ef7e3aac8a18  crates/cdhs_telemetry/src/lib.rs
762a302f2e967bbf  crates/cram_explorer/src/apollonian.rs
e55f2dbafb26b71c  crates/cram_explorer/src/diagnostics.rs
2d7d3ea25399a65c  crates/cram_explorer/src/holodrive.rs
3f005bde26334686  crates/cram_explorer/src/k_elim.rs
c9734633478ce369  crates/cram_explorer/src/lib.rs
68d6e58b6c874931  crates/cram_explorer/src/maps.rs
e037279ed438071a  crates/cram_explorer/src/mod_arith.rs
c9745c3c1bd0b9cc  crates/cram_explorer/src/projector.rs
8045d7df0fa5463f  crates/cram_explorer/src/shadow_ladder.rs
5a1702dab7304b93  crates/cram_explorer/src/torus.rs
aca3462f5bb7cd0c  crates/hackfate_runtime/src/lib.rs
3f7ab1d16806c869  crates/hackfate_runtime/src/main.rs
b4c8a1641be4a2d5  crates/hdv_crt/src/lib.rs
5735a8c682cb0128  crates/hydra_v3/src/lib.rs
3b599623adc188ad  crates/k_elim_period/src/lib.rs
3f692ba7d5f6d44f  crates/loki_engine/src/lib.rs
da34ec4695de8228  crates/maa_dh/src/lib.rs
7a1f9b16b8ff5efb  crates/mmbf_grover_bridge/src/lib.rs
352c40909f3c7954  crates/ns_winding_v2/src/energy_certificate.rs
344cfb02e4f01801  crates/ns_winding_v2/src/lib.rs
ee60e7ff6528b0fb  crates/nsgrid3d/src/biot_savart.rs
649e4c71f5f480a2  crates/nsgrid3d/src/biot_savart_exact.rs
a3b2aff000366095  crates/nsgrid3d/src/biot_savart_ntt.rs
1d258fe9cfab5b3c  crates/nsgrid3d/src/cram_amplified.rs
9f210e2269dd6f41  crates/nsgrid3d/src/cram_ns_bridge.rs
b32c99bd51751608  crates/nsgrid3d/src/dkam_monitor.rs
7084b8d104131286  crates/nsgrid3d/src/dual_tray.rs
24db4cfeb7292439  crates/nsgrid3d/src/fused_solver.rs
383d655c0a53a905  crates/nsgrid3d/src/inline_oracles.rs
315c44cc772b8ccf  crates/nsgrid3d/src/lib.rs
1e7ed6a6446c6cba  crates/nsgrid3d/src/main.rs
b35eba04c612648b  crates/nsgrid3d/src/ns_grid_3d.rs
c9a819c0c45d29d8  crates/nsgrid3d/src/regularity_tracker.rs
2c0bf5a8870a071f  crates/nsgrid3d/src/schema_program.rs
599fbbf38a0980be  crates/nsgrid3d/src/schema_sweep.rs
1005ca31c65bbdf4  crates/nsgrid3d/src/sobolev_winding.rs
cd8b3cf52e563240  crates/plmg_validator/src/lib.rs
f7b31c59cb50fff9  crates/prime_hunt/src/compete.rs
7a4f36d461919185  crates/prime_hunt/src/coprime_families.rs
86c547a1bf53a499  crates/prime_hunt/src/cram_schema.rs
f86edae5669995d9  crates/prime_hunt/src/crt.rs
ff5a1d436d4537a8  crates/prime_hunt/src/exact.rs
415efe88886760fc  crates/prime_hunt/src/gear.rs
13fe289987cdafb8  crates/prime_hunt/src/grover_hydra.rs
704b6219a2fd2d6e  crates/prime_hunt/src/helical.rs
0b931ff41ae737ec  crates/prime_hunt/src/hunter.rs
dbaf74af29e6c0a4  crates/prime_hunt/src/hydra.rs
b46b96581708eb99  crates/prime_hunt/src/intrinsic.rs
49a61ed3e25aa859  crates/prime_hunt/src/lib.rs
0a10be4ebdf5150d  crates/prime_hunt/src/monoid.rs
fcb656cd59ce1008  crates/prime_hunt/src/multi_hydra.rs
dc3a9c8a44d1acac  crates/prime_hunt/src/orbits.rs
c271b38cd99240bc  crates/prime_hunt/src/prove.rs
165558126b28c5f8  crates/prime_hunt/src/shadow.rs
364269bf5f0b49c7  crates/prime_hunt/src/sieve.rs
d6dfe2a9444316d0  crates/qedde_v2/src/hydra_lens.rs
4b986712c146bc98  crates/qedde_v2/src/lib.rs
14848a4c73a22a91  crates/qedde_v3/src/lib.rs
6799282ca66ef875  crates/qedde_v3/src/substrate.rs
440ce7a0cf2a8724  crates/qmnf_primitives/src/benchmark_kelim.rs
0d49024da07b3f2b  crates/qmnf_primitives/src/cram3_grover.rs
ba8ab8a0abd0176f  crates/qmnf_primitives/src/cram_ops.rs
363caef88f639797  crates/qmnf_primitives/src/cram_safety.rs
f2df63a541736938  crates/qmnf_primitives/src/gear_manifold.rs
ec31959fca1992be  crates/qmnf_primitives/src/lib.rs
da07b84e068c776d  crates/qmnf_primitives/src/nine65_mmbf.rs
97000301860024ee  crates/qmnf_primitives/src/sparse_toric_grover.rs
02c39d95dede7a57  crates/svd_engine/src/lib.rs
061d32c6918d4a69  crates/time_crystal/src/lib.rs
ea33ccd29905afe6  crates/wassan_engine/src/lib.rs
80412deba11ee086  crates/wassan_holographic/src/lib.rs
```
