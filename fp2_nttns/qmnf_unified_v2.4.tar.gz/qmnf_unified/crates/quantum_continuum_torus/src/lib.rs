// quantum_continuum_torus/src/lib.rs
//
// QUANTUM CONTINUUM INJECTED DISCRETE TORUS (QCIDT)
// Anthony Diaz / HackFate.us · April 2026
//
// Architecture:
//
//   RamanujanMemoryLane winding snapshot
//          ↓  inject_winding_snapshot()
//   F_p² quantum amplitude  (a + b√δ)
//          ↓  a = residue = total_delta mod p
//          ↓  b = magnitude mod p (second base-p digit)
//   GearManifold lane       (residue: u64, magnitude: i128)
//          ↓  total = magnitude * p + residue  (exact)
//
//   Quantum evolution:  σ(a+b√δ) = a-b√δ   (Frobenius, period 2)
//   Discrete readout:   N(a+b√δ) = a²-δb²  (norm, Frobenius-invariant)
//   Cross-lane bridge:  K-Elim(N(amp_i), residue_j) = quantum winding number
//
//   The "continuum" is the b-component: it encodes winding information
//   that lives OUTSIDE the discrete ring Z/pZ, in the F_p² extension.
//   Frobenius phase-flips b without changing the discrete projection via norm.
//   Quantum interference (amp_i × amp_j) has Frobenius-sensitive imaginary part.
//
// Zero float. All arithmetic: exact integers in Z/pZ and Z.

#![forbid(unsafe_code)]
#![deny(clippy::float_arithmetic)]

use qmnf_primitives::gear_manifold::GearManifold;
use qmnf_primitives::{addmod, submod, mulmod, mod_pow, mod_inverse, k_eliminate};

// ═══════════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════════

pub const SAFE_BASIS: [u64; 5] = [3, 5, 7, 11, 13];
/// Shadow prime: absent from Dresden periods, splitter anchor
pub const SHADOW_PRIME: u64 = 11;

// ═══════════════════════════════════════════════════════════════════
// ARITHMETIC HELPERS
// ═══════════════════════════════════════════════════════════════════

/// Find smallest quadratic non-residue mod p
pub fn find_qnr(p: u64) -> u64 {
    for d in 2..p {
        // Legendre symbol: d^{(p-1)/2} mod p = p-1 ↔ QNR
        if mod_pow(d, (p - 1) / 2, p) == p - 1 {
            return d;
        }
    }
    panic!("no QNR for p={}", p)
}

/// Euclidean magnitude of i128 into [0, p)
#[inline]
pub fn mag_to_residue(mag: i128, p: u64) -> u64 {
    ((mag % p as i128 + p as i128) % p as i128) as u64
}

// ═══════════════════════════════════════════════════════════════════
// F_p² ELEMENT
//
// Represents a + b·√δ in the quadratic extension F_p[√δ]
// where δ is a quadratic non-residue mod p.
//
// The INJECTION mapping:
//   residue  → a  (position in base ring Z/pZ)
//   magnitude mod p → b  (winding, as second base-p digit)
//
// Together, a + b·p encodes the value mod p² (the natural lift).
// a + b·√δ is the algebraic encoding in F_p².
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Fp2 {
    pub a: u64,     // real part ∈ F_p
    pub b: u64,     // imaginary part ∈ F_p
    pub p: u64,     // base prime
    pub delta: u64, // QNR: x² ≢ δ (mod p) has no solution
}

impl Fp2 {
    pub fn new(a: u64, b: u64, p: u64, delta: u64) -> Self {
        Fp2 { a: a % p, b: b % p, p, delta }
    }

    pub fn zero(p: u64, delta: u64) -> Self { Fp2 { a: 0, b: 0, p, delta } }
    pub fn one(p: u64, delta: u64) -> Self { Fp2 { a: 1, b: 0, p, delta } }

    /// Build from a (residue, magnitude) pair — the core INJECTION function.
    ///
    /// a = residue = total_accumulated_delta mod p
    /// b = magnitude mod p = floor(total/p) mod p
    ///
    /// Together (a, b) encode the value mod p² in base p.
    pub fn from_winding(residue: u64, magnitude: i128, p: u64, delta: u64) -> Self {
        let b = mag_to_residue(magnitude, p);
        Fp2 { a: residue % p, b, p, delta }
    }

    /// Frobenius automorphism: σ(a + b√δ) = a - b√δ
    ///
    /// Period 2: σ(σ(x)) = x.
    /// Phase-flips the winding component b without touching the residue a.
    /// σ(x) and x project to the SAME discrete value via norm.
    pub fn frobenius(&self) -> Fp2 {
        Fp2 {
            a: self.a,
            b: if self.b == 0 { 0 } else { self.p - self.b },
            p: self.p,
            delta: self.delta,
        }
    }

    /// Norm: N(a + b√δ) = a² - δb² mod p
    ///
    /// N is Frobenius-invariant: N(σ(x)) = N(x).
    /// This is the DISCRETE READOUT — collapses quantum state to Z/pZ.
    /// N: F_p²* → F_p* is SURJECTIVE (Hilbert 90).
    pub fn norm(&self) -> u64 {
        let a2 = mulmod(self.a, self.a, self.p);
        let db2 = mulmod(self.delta, mulmod(self.b, self.b, self.p), self.p);
        submod(a2, db2, self.p)
    }

    /// Trace: Tr(a + b√δ) = 2a mod p
    ///
    /// Tr is Frobenius-invariant (b-component cancels).
    pub fn trace(&self) -> u64 { addmod(self.a, self.a, self.p) }

    /// Multiply in F_p²: (a+b√δ)(c+d√δ) = (ac+bdδ) + (ad+bc)√δ
    ///
    /// Quantum interference: the imaginary part (ad+bc) IS Frobenius-sensitive.
    /// Im(x·y) → -(Im(x·y)) under Frobenius on either factor.
    pub fn mul(&self, other: &Self) -> Fp2 {
        debug_assert_eq!(self.p, other.p);
        let p = self.p;
        let re = addmod(mulmod(self.a, other.a, p),
                        mulmod(mulmod(self.delta, self.b, p), other.b, p), p);
        let im = addmod(mulmod(self.a, other.b, p), mulmod(self.b, other.a, p), p);
        Fp2 { a: re, b: im, p, delta: self.delta }
    }

    /// Conjugate = Frobenius for degree-2 extensions
    pub fn conj(&self) -> Fp2 { self.frobenius() }

    /// x · σ(x) = N(x) embedded in F_p² (sanity check: imaginary part = 0)
    pub fn norm_via_frobenius(&self) -> Fp2 {
        self.mul(&self.frobenius())
    }

    /// Is this element in the base field? (b = 0)
    pub fn is_in_base_field(&self) -> bool { self.b == 0 }

    /// Base-p two-digit value: a + b·p (the natural lift to Z/p²Z)
    pub fn base_p_value(&self) -> u128 {
        self.a as u128 + self.b as u128 * self.p as u128
    }

    /// Quantum phase state: which Frobenius phase is this? 0 or 1.
    /// Phase 0: b = original. Phase 1: b = p - original.
    /// Determined by: b <= p/2 → phase 0, else phase 1 (heuristic)
    pub fn frobenius_phase(&self) -> u8 {
        if self.b <= self.p / 2 { 0 } else { 1 }
    }
}

// ═══════════════════════════════════════════════════════════════════
// QCID LANE
//
// A single lane in the QCID torus.
// Holds both the discrete state (residue, magnitude) from GearManifold
// and the quantum amplitude (Fp2) derived from it.
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone)]
pub struct QCIDLane {
    pub p: u64,
    pub delta: u64,          // QNR for this prime

    // Discrete layer (mirrors GearManifold)
    pub residue: u64,        // total mod p
    pub magnitude: i128,     // floor(total / p)

    // Quantum layer (derived from discrete, evolves independently)
    pub amplitude: Fp2,      // a + b√δ in F_p²
    pub frobenius_count: u64, // how many Frobenius steps applied since last sync
}

impl QCIDLane {
    pub fn new(p: u64) -> Self {
        let delta = find_qnr(p);
        QCIDLane {
            p, delta,
            residue: 0, magnitude: 0,
            amplitude: Fp2::zero(p, delta),
            frobenius_count: 0,
        }
    }

    /// Sync quantum amplitude from current (residue, magnitude).
    /// This is the discrete → quantum INJECTION step.
    /// Resets frobenius_count to 0 (clean injection state).
    pub fn sync_amplitude(&mut self) {
        self.amplitude = Fp2::from_winding(self.residue, self.magnitude, self.p, self.delta);
        self.frobenius_count = 0;
    }

    /// Project quantum amplitude back to discrete layer via norm.
    /// Updates residue only — magnitude is unchanged (it's tracked discretely).
    pub fn project_to_discrete(&mut self) {
        self.residue = self.amplitude.norm();
    }

    /// Apply Frobenius automorphism to quantum amplitude.
    /// Period 2: applying twice returns to original.
    pub fn frobenius_step(&mut self) {
        self.amplitude = self.amplitude.frobenius();
        self.frobenius_count += 1;
    }

    /// True if amplitude.a == residue (real part coherence, not norm coherence).
    /// amplitude.b encodes the winding mod p — distinct quantum dimension.
    pub fn is_coherent(&self) -> bool { self.amplitude.a == self.residue }

    /// True if quantum amplitude is in base field (b = 0, pure discrete)
    pub fn is_classical(&self) -> bool {
        self.amplitude.is_in_base_field()
    }
}

// ═══════════════════════════════════════════════════════════════════
// INJECTION RECORD
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone)]
pub struct InjectionRecord {
    pub step_at: u64,
    pub snapshot: Vec<i128>,
    pub trigger_n: Option<u64>,  // the n value that triggered injection (shadow gate)
}

// ═══════════════════════════════════════════════════════════════════
// QUANTUM CONTINUUM INJECTED DISCRETE TORUS
// ═══════════════════════════════════════════════════════════════════

#[derive(Clone)]
pub struct QCIDTorus {
    pub lanes: Vec<QCIDLane>,
    pub gear: GearManifold,
    pub step_count: u64,
    /// Index of the shadow lane (q=11) if present
    pub shadow_idx: Option<usize>,
    /// Full injection history
    pub injection_log: Vec<InjectionRecord>,
}

impl QCIDTorus {
    /// Create with the Safe Basis {3, 5, 7, 11, 13}
    pub fn new_safe_basis() -> Self {
        Self::new(&SAFE_BASIS)
    }

    /// Create with arbitrary primes (sorted ascending to match GearManifold)
    pub fn new(primes: &[u64]) -> Self {
        let mut sorted = primes.to_vec();
        sorted.sort_unstable();
        let lanes: Vec<QCIDLane> = sorted.iter().map(|&p| QCIDLane::new(p)).collect();
        let gear = GearManifold::new(&sorted);
        let shadow_idx = sorted.iter().position(|&p| p == SHADOW_PRIME);
        QCIDTorus { lanes, gear, step_count: 0, shadow_idx, injection_log: Vec::new() }
    }

    // ── DISCRETE STEP ──────────────────────────────────────────────

    /// Advance one CRAM step: add delta to all CRT lanes.
    /// Updates discrete layer; quantum layer stays in its current phase
    /// until explicitly synced or injected.
    pub fn step(&mut self, delta: i128) {
        self.gear.add(delta);
        for (i, lane) in self.lanes.iter_mut().enumerate() {
            let g = &self.gear.lanes[i];
            lane.residue = g.residue;
            lane.magnitude = g.magnitude;
        }
        self.step_count += 1;
    }

    /// Step driven by Ramanujan sum: delta = c_q(n) for the lane's prime q.
    pub fn step_ramanujan(&mut self, n: u64) {
        // Each lane uses its own prime's Ramanujan sum
        // c_q(n) = q-1 if q|n, else -1
        // For multi-lane: use the sum over all primes? 
        // Or per-lane independent delta?
        // Design: per-lane Ramanujan deltas, accumulated independently
        for (i, lane) in self.lanes.iter_mut().enumerate() {
            let delta: i128 = if n % lane.p == 0 { (lane.p - 1) as i128 } else { -1 };
            let g = &mut self.gear.lanes[i];
            let m = g.modulus as i128;
            let temp = g.residue as i128 + delta;
            let new_r = ((temp % m) + m) % m;
            let wraps = (temp - new_r) / m;
            g.residue = new_r as u64;
            g.magnitude += wraps;
            lane.residue = g.residue;
            lane.magnitude = g.magnitude;
        }
        self.step_count += 1;
    }

    // ── QUANTUM OPERATIONS ─────────────────────────────────────────

    /// Sync all quantum amplitudes from current discrete state.
    /// Call after a sequence of discrete steps to re-couple quantum layer.
    pub fn sync_quantum(&mut self) {
        for lane in self.lanes.iter_mut() {
            lane.sync_amplitude();
        }
    }

    /// Apply Frobenius to all quantum amplitudes.
    /// σ: a + b√δ → a - b√δ. Period 2. Norm-invariant.
    pub fn apply_frobenius(&mut self) {
        for lane in self.lanes.iter_mut() {
            lane.frobenius_step();
        }
    }

    /// Project all quantum amplitudes back to discrete layer via norm.
    /// Residues updated; magnitudes preserved.
    pub fn project_quantum_to_discrete(&mut self) {
        for (i, lane) in self.lanes.iter_mut().enumerate() {
            lane.project_to_discrete();
            self.gear.lanes[i].residue = lane.residue;
        }
    }

    // ── STATE INJECTION ────────────────────────────────────────────

    /// Inject a winding snapshot directly into the torus.
    ///
    /// This is the core QCIDT capability: given a Vec<i128> from
    /// RamanujanMemoryLane (or any source), write it as the new state
    /// on both the discrete (GearManifold) and quantum (Fp2) layers.
    ///
    /// After injection:
    ///   lane.residue   = snapshot[i] mod p_i      (discrete)
    ///   lane.magnitude = snapshot[i]               (integer winding)
    ///   lane.amplitude = Fp2::from_winding(...)    (quantum, synced)
    ///   amplitude.a = residue                      (base-ring position)
    ///   amplitude.b = magnitude mod p              (winding in field)
    pub fn inject_winding_snapshot(&mut self, snapshot: &[i128]) {
        for (i, lane) in self.lanes.iter_mut().enumerate() {
            let mag = match snapshot.get(i) { Some(&m) => m, None => continue };
            let residue = mag_to_residue(mag, lane.p);
            lane.magnitude = mag;
            lane.residue = residue;
            lane.sync_amplitude();
            // Mirror into GearManifold
            self.gear.lanes[i].magnitude = mag;
            self.gear.lanes[i].residue = residue;
        }
        self.injection_log.push(InjectionRecord {
            step_at: self.step_count,
            snapshot: snapshot.to_vec(),
            trigger_n: None,
        });
    }

    /// Full-state injection: set residue and GearManifold.magnitude independently.
    /// This is required to reach quantum fixed points where a ≠ b.
    /// inject_winding_snapshot sets residue = magnitude mod p (a == b always).
    /// inject_full_state sets them independently.
    pub fn inject_full_state(&mut self, residues: &[u64], magnitudes: &[i128]) {
        for (i, lane) in self.lanes.iter_mut().enumerate() {
            let r = match residues.get(i) { Some(&r) => r % lane.p, None => continue };
            let m = match magnitudes.get(i) { Some(&m) => m, None => continue };
            lane.residue = r;
            lane.magnitude = m;
            lane.sync_amplitude(); // from_winding(r, m, p, delta): a=r, b=m mod p
            self.gear.lanes[i].residue = r;
            self.gear.lanes[i].magnitude = m;
        }
        self.injection_log.push(InjectionRecord {
            step_at: self.step_count,
            snapshot: magnitudes.to_vec(),
            trigger_n: None,
        });
    }

    /// Shadow-gated injection: inject ONLY when q=11 resonance fires (n % 11 == 0).
    ///
    /// Before resonance: shadow lane holds multidimensional zero (Vec::new()).
    /// After resonance: state injection couples quantum + discrete layers.
    /// This mirrors the RamanujanMemoryLane shadow semantics exactly.
    pub fn shadow_inject(&mut self, n: u64, snapshot: &[i128]) -> bool {
        let resonates = self.shadow_idx
            .map(|idx| n % self.lanes[idx].p == 0)
            .unwrap_or(false);
        if resonates {
            let mut rec = InjectionRecord {
                step_at: self.step_count,
                snapshot: snapshot.to_vec(),
                trigger_n: Some(n),
            };
            // Write into lanes and gear
            for (i, lane) in self.lanes.iter_mut().enumerate() {
                let mag = match snapshot.get(i) { Some(&m) => m, None => continue };
                let residue = mag_to_residue(mag, lane.p);
                lane.magnitude = mag;
                lane.residue = residue;
                lane.sync_amplitude();
                self.gear.lanes[i].magnitude = mag;
                self.gear.lanes[i].residue = residue;
            }
            rec.trigger_n = Some(n);
            self.injection_log.push(rec);
        }
        resonates
    }

    // ── K-ELIMINATION BRIDGE ───────────────────────────────────────

    /// Quantum K-Elimination: bridges F_p² layer to discrete layer.
    ///
    /// r = N(amplitude[lane_a]) mod p_b   — quantum projection onto lane_b's ring
    /// s = residue[lane_b]                — discrete residue of lane_b
    /// k = (s - r) · p_a⁻¹ mod p_b       — quantum winding number
    ///
    /// k = 0: quantum state of lane_a is CRT-consistent with lane_b → coherence
    /// k ≠ 0: quantum-discrete mismatch — k encodes the "continuum overhang"
    pub fn quantum_k_elim(&self, lane_a: usize, lane_b: usize) -> u64 {
        let la = &self.lanes[lane_a];
        let lb = &self.lanes[lane_b];
        let r = la.amplitude.norm();
        k_eliminate(r, lb.residue, la.p, lb.p)
    }

    /// Classical K-Elimination (residue-only, no quantum layer).
    pub fn classical_k_elim(&self, lane_a: usize, lane_b: usize) -> u64 {
        let la = &self.lanes[lane_a];
        let lb = &self.lanes[lane_b];
        k_eliminate(la.residue, lb.residue, la.p, lb.p)
    }

    /// Quantum inner product between two lanes: amp_a × amp_b in F_p².
    ///
    /// Imaginary part of result is Frobenius-SENSITIVE — this is the
    /// quantum interference term not accessible via norm alone.
    pub fn quantum_inner_product(&self, lane_a: usize, lane_b: usize) -> Fp2 {
        self.lanes[lane_a].amplitude.mul(&self.lanes[lane_b].amplitude)
    }

    // ── READOUT ────────────────────────────────────────────────────

    /// All discrete residues
    pub fn discrete_state(&self) -> Vec<u64> {
        self.lanes.iter().map(|l| l.residue).collect()
    }

    /// All quantum norm projections (Frobenius-invariant readout)
    pub fn quantum_projected_state(&self) -> Vec<u64> {
        self.lanes.iter().map(|l| l.amplitude.norm()).collect()
    }

    /// All quantum amplitudes
    pub fn amplitudes(&self) -> Vec<Fp2> {
        self.lanes.iter().map(|l| l.amplitude).collect()
    }

    /// All winding magnitudes
    pub fn windings(&self) -> Vec<i128> {
        self.lanes.iter().map(|l| l.magnitude).collect()
    }

    /// Full integer reconstruction via Garner
    pub fn total_value(&self) -> u128 {
        self.gear.full_value()
    }

    /// True if quantum norm agrees with discrete residue on every lane
    pub fn is_coherent(&self) -> bool {
        self.lanes.iter().all(|l| l.is_coherent())
    }

    /// True if net winding is zero mod product of moduli
    pub fn is_energy_neutral(&self) -> bool {
        let m: i128 = self.lanes.iter().map(|l| l.p as i128).product();
        let total: i128 = self.lanes.iter().map(|l| l.magnitude).sum();
        total % m == 0
    }

    /// Number of injections performed
    pub fn injection_count(&self) -> usize { self.injection_log.len() }

    /// K-Elim winding number matrix: k[i][j] = quantum_k_elim(i, j)
    pub fn winding_matrix(&self) -> Vec<Vec<u64>> {
        let n = self.lanes.len();
        (0..n).map(|i| (0..n).filter(|&j| j != i)
            .map(|j| self.quantum_k_elim(i, j))
            .collect()
        ).collect()
    }
}


// ═══════════════════════════════════════════════════════════════════
// SCHEMA CHIMERA: Heterogeneous Operators on the QCIDT
// ═══════════════════════════════════════════════════════════════════

/// The 8 CRAM operators as exact integer functions on Z/pZ
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum CramOp {
    Add, Sub, Mul, Div, Sqr, Neg, Inv, Id,
}

impl CramOp {
    /// Apply the binary operator f(a, b) mod p
    /// For unary ops (Sqr, Neg, Inv, Id): b is ignored
    pub fn apply(&self, a: u64, b: u64, p: u64) -> u64 {
        match self {
            CramOp::Add => addmod(a, b, p),
            CramOp::Sub => submod(a, b, p),
            CramOp::Mul => mulmod(a, b, p),
            CramOp::Div => {
                if b == 0 || gcd(b, p) != 1 { return 0; }
                mulmod(a, mod_inverse(b, p), p)
            }
            CramOp::Sqr => mulmod(a, a, p),
            CramOp::Neg => if a == 0 { 0 } else { p - a },
            CramOp::Inv => {
                if a == 0 || gcd(a, p) != 1 { return 0; }
                mod_inverse(a, p)
            }
            CramOp::Id => a,
        }
    }

    /// Algebraic degree of the operator
    pub fn degree(&self) -> u32 {
        match self {
            CramOp::Add | CramOp::Sub | CramOp::Neg | CramOp::Id => 1,
            CramOp::Mul | CramOp::Sqr => 2,
            CramOp::Div | CramOp::Inv => { /* p-2 by Fermat, but bounded */ 2 }
        }
    }
}

fn gcd(mut a: u64, mut b: u64) -> u64 {
    while b != 0 { let t = b; b = a % b; a = t; }
    a
}

/// A 5-lane heterogeneous schema: one operator per Safe Basis prime
#[derive(Debug, Clone)]
pub struct Schema {
    pub ops: Vec<(u64, CramOp)>,  // (prime, operator) pairs
    pub label: String,
}

impl Schema {
    pub fn new(ops: Vec<(u64, CramOp)>, label: &str) -> Self {
        Schema { ops, label: label.to_string() }
    }

    /// Standard NS diffusion schema: Id on all lanes
    pub fn ns_diffusion() -> Self {
        Schema::new(
            SAFE_BASIS.iter().map(|&p| (p, CramOp::Id)).collect(),
            "NS-Diffusion",
        )
    }

    /// Stretching schema: Sqr on discriminating lanes, Id on parking
    pub fn ns_stretching() -> Self {
        Schema::new(vec![
            (3, CramOp::Id),    // parking
            (5, CramOp::Id),    // parking
            (7, CramOp::Sqr),   // discriminating: degree 2
            (11, CramOp::Sqr),  // shadow: degree 2
            (13, CramOp::Sqr),  // boundary: degree 2
        ], "NS-Stretching")
    }

    /// Maximum algebraic degree across all lanes
    pub fn max_degree(&self) -> u32 {
        self.ops.iter().map(|(_, op)| op.degree()).max().unwrap_or(0)
    }

    /// DKAM subcriticality check: max_degree < ρ
    pub fn is_dkam_safe(&self, rho: u32) -> bool {
        self.max_degree() < rho
    }

    /// Apply schema to a QCIDT torus state
    /// Each lane's residue is transformed by its operator
    /// b-coupling: the b-component of lane i feeds as the `b` argument to lane (i+1)
    pub fn apply_to_torus(&self, torus: &mut QCIDTorus) {
        let n = torus.lanes.len().min(self.ops.len());
        let residues: Vec<u64> = (0..n).map(|i| torus.lanes[i].residue).collect();
        let b_vals: Vec<u64> = (0..n).map(|i| torus.lanes[i].amplitude.b).collect();

        for i in 0..n {
            let (p, op) = self.ops[i];
            let a = residues[i];
            // Cyclic b-coupling: b from previous lane
            let b = if i > 0 { b_vals[i - 1] } else { b_vals[n - 1] };
            let new_r = op.apply(a, b, p);
            torus.lanes[i].residue = new_r;
            torus.gear.lanes[i].residue = new_r;
        }
        // Sync quantum layer
        torus.sync_quantum();
    }
}

// ═══════════════════════════════════════════════════════════════════
// SCHEMA ORBIT: Track chimera trajectory through L steps
// ═══════════════════════════════════════════════════════════════════

/// Record of one orbit step
#[derive(Debug, Clone)]
pub struct OrbitStep {
    pub step: usize,
    pub residues: Vec<u64>,
    pub norms: Vec<u64>,
    pub b_components: Vec<u64>,
}

/// Complete orbit of a schema on the QCIDT
#[derive(Debug, Clone)]
pub struct SchemaOrbit {
    pub schema_label: String,
    pub steps: Vec<OrbitStep>,
    pub period: Option<usize>,
    pub contraction: Option<u64>,  // norm product, if periodic
}

impl SchemaOrbit {
    /// Run a schema for L steps, recording the trajectory
    pub fn compute(schema: &Schema, torus: &mut QCIDTorus, max_steps: usize) -> Self {
        let mut steps = Vec::new();
        let mut seen_states: Vec<Vec<u64>> = Vec::new();
        let mut period = None;

        for s in 0..max_steps {
            let residues: Vec<u64> = torus.lanes.iter().map(|l| l.residue).collect();
            let norms: Vec<u64> = torus.lanes.iter().map(|l| l.amplitude.norm()).collect();
            let b_comps: Vec<u64> = torus.lanes.iter().map(|l| l.amplitude.b).collect();

            // Check for period (residue cycle)
            if let Some(pos) = seen_states.iter().position(|st| st == &residues) {
                period = Some(s - pos);
                steps.push(OrbitStep { step: s, residues, norms, b_components: b_comps });
                break;
            }
            seen_states.push(residues.clone());
            steps.push(OrbitStep { step: s, residues, norms, b_components: b_comps });

            schema.apply_to_torus(torus);
        }

        // Compute contraction: product of norms at boundary prime (lane 13)
        let boundary_idx = torus.lanes.iter().position(|l| l.p == 13);
        let contraction = boundary_idx.map(|idx| {
            steps.iter()
                .map(|s| s.norms[idx])
                .fold(1u64, |acc, n| mulmod(acc, n.max(1), 13))
        });

        SchemaOrbit {
            schema_label: schema.label.clone(),
            steps,
            period,
            contraction,
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
// RESOLUTION LADDER: The N-Refinement Chimera Engine
//
// For each resolution N in the doubling sequence:
//   1. Compute the transition coefficient c(N) = dt·ν·N²·SCALE⁻¹ mod p
//   2. Run the schema orbit for T steps at this coefficient
//   3. Measure contraction: norm product over the orbit
//   4. INJECT the inter-resolution contraction c[N] - c[N/2] as the
//      b-component into the quantum layer
//   5. Frobenius phase-flip the injection
//   6. Advance to next resolution
//
// The b-component carries the MEMORY of how contraction changed
// between resolutions. The Frobenius flip probes whether this
// memory survives projection through the norm (it does — the norm
// is Frobenius-invariant, so the discrete readout is the same
// regardless of which Frobenius phase the memory is in).
// ═══════════════════════════════════════════════════════════════════

/// One rung of the resolution ladder
#[derive(Debug, Clone)]
pub struct LadderRung {
    pub n: u64,
    pub coefficients: Vec<u64>,     // c(N) per prime
    pub self_coefficients: Vec<i64>, // (1-6c) centered per prime
    pub orbit_period: Option<usize>,
    pub contraction_norm: u64,       // norm product at boundary
    pub b_injection: Vec<u64>,       // what was injected as b
    pub is_erasure: Vec<bool>,       // which lanes hit self=0
}

/// The full resolution ladder from N_start through N_end
#[derive(Debug)]
pub struct ResolutionLadder {
    pub rungs: Vec<LadderRung>,
    pub scale: u64,
    pub dt: u64,
    pub nu: u64,
}

impl ResolutionLadder {
    /// Build the resolution ladder for the NS chimera
    pub fn build(n_start: u64, n_doublings: usize, dt: u64, nu: u64, scale: u64) -> Self {
        let primes = SAFE_BASIS;
        let mut rungs = Vec::new();
        let mut prev_coeffs: Option<Vec<u64>> = None;
        let mut torus = QCIDTorus::new_safe_basis();

        let mut n = n_start;
        for _k in 0..=n_doublings {
            // Compute c(N) = dt·ν·N²·SCALE⁻¹ mod p for each prime
            let coeffs: Vec<u64> = primes.iter().map(|&p| {
                let si = mod_pow(scale % p, p - 2, p);
                let a = (dt % p) * (nu % p) % p;
                let b = (n % p) * (n % p) % p;
                a * b % p * si % p
            }).collect();

            // Self-coefficients (1 - 6c) centered
            let self_coeffs: Vec<i64> = primes.iter().zip(coeffs.iter()).map(|(&p, &c)| {
                let s = (1 + p - (6 * c) % p) % p;
                if s <= p / 2 { s as i64 } else { s as i64 - p as i64 }
            }).collect();

            // Erasure detection
            let is_erasure: Vec<bool> = primes.iter().zip(coeffs.iter())
                .map(|(&p, &c)| (6 * c) % p == 1 % p)
                .collect();

            // Inject inter-resolution contraction as b-component
            let b_injection: Vec<u64> = if let Some(ref prev) = prev_coeffs {
                primes.iter().enumerate().map(|(i, &p)| {
                    submod(coeffs[i], prev[i], p)
                }).collect()
            } else {
                vec![0; primes.len()]
            };

            // Actually inject into the torus
            if prev_coeffs.is_some() {
                // Inject b-values without changing a (residues)
                for (i, lane) in torus.lanes.iter_mut().enumerate() {
                    let new_b = b_injection[i];
                    lane.amplitude = Fp2::new(
                        lane.amplitude.a,
                        new_b,
                        lane.p,
                        lane.amplitude.delta,
                    );
                }
                // Frobenius phase-flip to test norm invariance
                torus.apply_frobenius();
            }

            // Compute contraction norm at boundary prime (p=13)
            let boundary_idx = 4; // index of p=13 in SAFE_BASIS
            let contraction_norm = torus.lanes[boundary_idx].amplitude.norm();

            // Run a short schema orbit to measure period
            let mut test_torus = torus.clone();
            let schema = Schema::ns_diffusion();
            let orbit = SchemaOrbit::compute(&schema, &mut test_torus, 100);

            rungs.push(LadderRung {
                n,
                coefficients: coeffs.clone(),
                self_coefficients: self_coeffs,
                orbit_period: orbit.period,
                contraction_norm,
                b_injection,
                is_erasure,
            });

            prev_coeffs = Some(coeffs);
            n = n.saturating_mul(2);
        }

        ResolutionLadder { rungs, scale, dt, nu }
    }

    /// Check permanent non-resonance across all rungs
    pub fn all_non_resonant(&self) -> bool {
        self.rungs.iter().all(|rung|
            rung.coefficients.iter().zip(SAFE_BASIS.iter())
                .skip(2) // skip parking primes 3, 5
                .all(|(&c, _)| c != 0)
        )
    }

    /// Check if every cycle contains at least one erasure per lane
    pub fn all_have_erasure(&self) -> bool {
        // For each discriminating prime, check if erasure occurs somewhere
        for lane_idx in 2..5 { // lanes 7, 11, 13
            let any_erasure = self.rungs.iter().any(|r| r.is_erasure[lane_idx]);
            if !any_erasure { return false; }
        }
        true
    }
}

// ═══════════════════════════════════════════════════════════════════
// TESTS
// ═══════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    // ── Core QCIDT tests ──

    #[test]
    fn test_fp2_frobenius_period_two() {
        let x = Fp2::new(3, 5, 13, find_qnr(13));
        let sx = x.frobenius();
        let ssx = sx.frobenius();
        assert_eq!(ssx, x, "σ² = identity");
    }

    #[test]
    fn test_fp2_norm_frobenius_invariant() {
        let x = Fp2::new(4, 7, 13, find_qnr(13));
        assert_eq!(x.norm(), x.frobenius().norm(), "N(σ(x)) = N(x)");
    }

    #[test]
    fn test_fp2_from_winding_encodes_both() {
        let p = 11u64;
        let delta = find_qnr(p);
        let residue = 7u64;
        let magnitude: i128 = 25;
        let amp = Fp2::from_winding(residue, magnitude, p, delta);
        assert_eq!(amp.a, residue % p, "a = residue mod p");
        assert_eq!(amp.b, (magnitude as u64) % p, "b = magnitude mod p");
    }

    #[test]
    fn test_inject_snapshot_coherent() {
        let mut torus = QCIDTorus::new_safe_basis();
        torus.inject_winding_snapshot(&[0, 0, 0, 0, 0]);
        assert!(torus.is_coherent(), "Zero snapshot = coherent state");
    }

    #[test]
    fn test_shadow_gate_11_resonance() {
        let mut torus = QCIDTorus::new_safe_basis();
        let snap = vec![10i128, 20, 30, 40, 50];
        assert!(!torus.shadow_inject(7, &snap), "7 is not shadow prime");
        assert!(torus.shadow_inject(11, &snap), "11 IS shadow prime");
        assert!(torus.shadow_inject(22, &snap), "22 is multiple of 11");
    }

    #[test]
    fn test_step_advances_discrete() {
        let mut torus = QCIDTorus::new_safe_basis();
        torus.step(100);
        // Residue of 100: mod 3=1, mod 5=0, mod 7=2, mod 11=1, mod 13=9
        assert_eq!(torus.lanes[0].residue, 100 % 3);
        assert_eq!(torus.lanes[2].residue, 100 % 7);
        assert_eq!(torus.lanes[4].residue, 100 % 13);
    }

    #[test]
    fn test_frobenius_on_torus_period_two() {
        let mut torus = QCIDTorus::new_safe_basis();
        torus.inject_winding_snapshot(&[3, 5, 7, 11, 13]);
        torus.sync_quantum();
        let before: Vec<Fp2> = torus.amplitudes();
        torus.apply_frobenius();
        torus.apply_frobenius();
        torus.sync_quantum(); // re-sync to check
        // After two Frobenius, quantum state should return to original
        // (Frobenius is period 2)
        let after: Vec<Fp2> = torus.amplitudes();
        // Note: sync_quantum rebuilds from (residue, magnitude), so
        // double-frobenius + sync should give same as original sync
    }

    // ── Schema tests ──

    #[test]
    fn test_schema_dkam_safety() {
        let diff = Schema::ns_diffusion();
        assert!(diff.is_dkam_safe(3), "Diffusion (deg 1) < ρ=3");

        let stretch = Schema::ns_stretching();
        assert!(stretch.is_dkam_safe(3), "Stretching (deg 2) < ρ=3");

        // Degree 3 schema would NOT be safe
        assert!(stretch.max_degree() == 2);
    }

    #[test]
    fn test_schema_orbit_finds_period() {
        let mut torus = QCIDTorus::new_safe_basis();
        torus.inject_winding_snapshot(&[1, 1, 1, 1, 1]);
        torus.sync_quantum();

        let schema = Schema::ns_diffusion(); // Id on all = identity
        let orbit = SchemaOrbit::compute(&schema, &mut torus, 100);
        // Id schema should have period 1 (fixed point)
        assert_eq!(orbit.period, Some(1), "Id schema is fixed point");
    }

    #[test]
    fn test_schema_sqr_orbit_period_divides_p_minus_1() {
        // Sqr: x → x² mod p. Period divides (p-1)/2 for x coprime to p.
        let mut torus = QCIDTorus::new(&[13]);
        torus.inject_winding_snapshot(&[2]); // Start at 2
        torus.sync_quantum();

        let schema = Schema::new(vec![(13, CramOp::Sqr)], "Sqr-13");
        let orbit = SchemaOrbit::compute(&schema, &mut torus, 100);

        if let Some(per) = orbit.period {
            assert!(per <= 12, "Sqr period on Z/13Z divides 12");
            assert!(12 % per == 0 || per % 12 == 0,
                "Period {} should divide p-1=12", per);
        }
    }

    // ── Resolution Ladder tests ──

    #[test]
    fn test_ladder_permanent_non_resonance() {
        let ladder = ResolutionLadder::build(8, 30, 100, 6, 10000);
        assert!(ladder.all_non_resonant(),
            "All discriminating coefficients coprime to all primes");
    }

    #[test]
    fn test_ladder_has_erasure() {
        let ladder = ResolutionLadder::build(8, 30, 100, 6, 10000);
        assert!(ladder.all_have_erasure(),
            "Every discriminating lane has at least one erasure");
    }

    #[test]
    fn test_ladder_self_coefficients_bounded() {
        let ladder = ResolutionLadder::build(8, 30, 100, 6, 10000);
        for rung in &ladder.rungs {
            for (i, &sc) in rung.self_coefficients.iter().enumerate() {
                let p = SAFE_BASIS[i];
                let ratio = sc.unsigned_abs() as f64 / p as f64;
                if i >= 2 { // discriminating lanes only
                    assert!(ratio < 0.5,
                        "N={}: |self|/p = {}/{} = {:.3} >= 0.5",
                        rung.n, sc.unsigned_abs(), p, ratio);
                }
            }
        }
    }

    #[test]
    fn test_ladder_coefficient_cycling() {
        let ladder = ResolutionLadder::build(8, 60, 100, 6, 10000);
        // After 30 doublings, coefficients should repeat
        if ladder.rungs.len() > 30 {
            for i in 0..30 {
                // Check lane 2 (p=7, period 3)
                assert_eq!(
                    ladder.rungs[i].coefficients[2],
                    ladder.rungs[i + 3].coefficients[2],
                    "p=7 coefficient should cycle with period 3"
                );
            }
        }
    }

    #[test]
    fn test_ladder_b_injection_nonzero() {
        let ladder = ResolutionLadder::build(8, 10, 100, 6, 10000);
        // First rung has zero injection (no previous)
        assert!(ladder.rungs[0].b_injection.iter().all(|&b| b == 0));
        // Subsequent rungs should have nonzero injection on at least some lanes
        let any_nonzero = ladder.rungs[1..].iter()
            .any(|r| r.b_injection.iter().any(|&b| b != 0));
        assert!(any_nonzero,
            "Inter-resolution injection should produce nonzero b on some lane");
    }

    #[test]
    fn test_ladder_contraction_norm_bounded() {
        let ladder = ResolutionLadder::build(8, 30, 100, 6, 10000);
        for rung in &ladder.rungs {
            assert!(rung.contraction_norm < 13,
                "Norm at boundary prime p=13 should be < 13, got {}",
                rung.contraction_norm);
        }
    }

    #[test]
    fn test_ladder_spectral_fingerprint_constant() {
        // Permanent Non-Resonance: SP = 2/p at every resolution
        let ladder = ResolutionLadder::build(8, 30, 100, 6, 10000);
        for rung in &ladder.rungs {
            for (i, &c) in rung.coefficients.iter().enumerate() {
                let p = SAFE_BASIS[i];
                if p <= 5 { continue; } // skip parking
                // SP(p, c) should have c coprime to p
                // Ramanujan sum = -1 → SP numerator = 2p
                let (num, _den) = crate::sieve_power(p, c);
                assert_eq!(num, 2 * p,
                    "N={}: SP({}, c={}) numerator should be 2×{}={}, got {}",
                    rung.n, p, c, p, 2*p, num);
            }
        }
    }
}

/// Sieve power SP(p, d) = (2p - 1 - c_p(d)) / p² (exact rational)
pub fn sieve_power(p: u64, d: u64) -> (u64, u64) {
    let c: i64 = if d > 0 && d % p == 0 { p as i64 - 1 } else { -1 };
    let num = (2 * p as i64 - 1 - c) as u64;
    (num, p * p)
}
