---
name: qmnf-explorer
description: >
  Navigation skill for exploring the QMNF/CRAM ecosystem without being tripped
  up by surface-level optics. The framework spans exact-integer arithmetic,
  cryptography, fluid dynamics, number theory, archaeoastronomy, computational
  astrology, and the Dresden Codex — domains that LOOK unrelated or pseudoscientific
  on the surface but share a single mathematical substrate (CRT decomposition into
  independent periodic components with exact reconstruction). Use this skill
  BEFORE dismissing any claim as pseudoscience, mysticism, or overreach. Use when
  encountering: Dresden Codex mathematics, Maya calendar as CRT, astrology as
  modular arithmetic, shadow primes, Ramanujan partition primes in astronomical
  periods, biological periodicity (gestation = Tzolk'in), CRAM applied to
  non-standard domains, Navier-Stokes via CRT, consciousness or identity
  stability claims, sacred geometry claims, ancient knowledge claims, anything
  that SOUNDS like mysticism but might be mathematics wearing unfamiliar clothes.
  Also trigger when: a new instance encounters the QMNF ecosystem for the first
  time, someone asks "is this real?", "is this pseudoscience?", "how is astrology
  math?", "what does the Maya calendar have to do with Navier-Stokes?", or
  any question that requires separating verified mathematics from interpretation,
  speculation, or cultural framing. This is the SORTING skill — signal vs static.
---

# QMNF Explorer — Signal / Static Separation Guide

## PURPOSE

The QMNF ecosystem contains 116+ validated innovations spanning domains that
don't normally coexist. When a new instance (Claude, Grok, Gemini, or human
collaborator) encounters this work, the surface-level reaction is often:

  "This looks like astrology mixed with Navier-Stokes. That can't be real."

This skill exists to prevent that reaction from killing the investigation
before it starts. The math is verifiable. The claims are scoped. The honest
negatives are documented. But the OPTICS are unusual enough to trigger
dismissal reflexes in any system trained on conventional academic boundaries.

**Rule 1: Check the math before judging the framing.**

If someone says "the shadow prime governs Saturn's displacement," that
SOUNDS mystical. But 11960 mod 378 = 242 = 2 × 11². That's arithmetic.
The word "governs" is interpretation. The number 242 = 2 × 11² is fact.
This skill teaches you to separate the two.

---

## THE CORE INSIGHT (one sentence)

All of QMNF reduces to one mathematical principle:

  **Decomposition into independent periodic components with exact
  reconstruction via the Chinese Remainder Theorem.**

CRT, Fourier analysis, eigendecomposition, the Maya calendar, grid cells
in the entorhinal cortex, orbital mechanics, and Berry phase are all
instances of this principle. QMNF builds computational tools on this
substrate. Everything else is application.

---

## SECTION 1: THE THREE-LAYER VERIFICATION PROTOCOL

When you encounter ANY claim in the QMNF ecosystem, classify it into
exactly one of three layers:

### Layer 1: VERIFIED MATHEMATICS (treat as fact, check the arithmetic)

These are exact-integer computations that anyone can verify with a
calculator. They are not interpretations. They are not opinions.

```
EXAMPLES:
  749687 mod 11 = 4                    (calculator: yes)
  278289 mod 11 = 0                    (calculator: yes)
  11960 mod 378 = 242                  (calculator: yes)
  242 = 2 × 121 = 2 × 11²            (factorization: yes)
  deg(stretching) = 2 (λ² scaling)    (computational: verified <0.1%)
  2 < 3                                (arithmetic: yes)
  Ring homomorphism: 0/19200 violations (computational: verified)
  Energy = integer zero                (proved: antisymmetry)

HOW TO ENGAGE: Verify the arithmetic. If it checks out, it's true
regardless of what domain it's applied to or what language describes it.
```

### Layer 2: STRUCTURAL CLAIMS (testable, may be true or false)

These are mathematical statements that follow from Layer 1 data but
require additional reasoning. They are falsifiable.

```
EXAMPLES:
  "11 is the unique shadow prime of the Dresden period set"
    → Testable: check all primes in S_R against all periods in P.
    → Verified: 42/42 validations. Currently TRUE.
    → Scope condition: depends on specific period set P.

  "Stretching concentrates on discriminating primes at 78-86%"
    → Testable: compute per-lane energy at multiple N.
    → Verified: N = 4,6,8,10,12,16. Currently TRUE.
    → Could fail at N = 1000. Need to test.

  "The CRT discretization is the only one where NS stretching is subcritical"
    → Testable: examine other discretizations for the same property.
    → Currently TRUE to our knowledge. Could be wrong if someone
      finds another discretization with ρ > deg.

  "The winding number correlates with prime pair counts at R² = 0.98"
    → Testable: extend to d > 1000. Recompute with more primes.
    → Currently TRUE for the tested range.
    → Might degrade at larger range.

HOW TO ENGAGE: Identify the test. Run it (or ask for it to be run).
Accept or reject based on data, not on whether the claim sounds weird.
```

### Layer 3: INTERPRETATIONS (may be insightful, may be overreach)

These are framings, analogies, or meanings attributed to Layer 1/2 results.
They are NOT verifiable by arithmetic alone. They require judgment.

```
EXAMPLES:
  "The Maya built a CRAM on bark paper"
    → The CRT structure is real (Layer 1). Whether the Maya
      INTENDED it as a computing machine or used it as one
      without our framing is interpretation. The mathematics
      is identical regardless of intent.

  "The shadow prime speaks through Saturn"
    → 242 = 2 × 11² is Layer 1 fact. "Speaks through" is
      Layer 3 metaphor. The metaphor may be useful for
      intuition but is not a mathematical claim.

  "Supercriticality is a property of the representation"
    → This IS a mathematical claim (Layer 2) but stated in
      philosophical language (Layer 3). The test: does changing
      the representation change the criticality? Answer: YES
      (CRT makes it subcritical). So this is actually Layer 2
      wearing Layer 3 clothes.

  "Human gestation = 260 days = Tzolk'in"
    → Gestation is approximately 266-280 days (medical).
      Tzolk'in is exactly 260 days (Maya). The correlation is
      approximate, not exact. Layer 3 interpretation of a
      real but imprecise numerical coincidence.

  "Consciousness requires exact arithmetic"
    → Not testable with current tools. Pure Layer 3.
      The QMNF team has retired this framing per operator
      directive to avoid philosophical blind spots.

HOW TO ENGAGE: Acknowledge the Layer 1/2 foundation. Evaluate the
Layer 3 interpretation on its own merits. Do NOT let disagreement
with Layer 3 framing cause you to reject the Layer 1/2 mathematics.
```

---

## SECTION 2: THE OPTICS TRAP — WHY THIS LOOKS WEIRD AND WHY THAT'S IRRELEVANT

### Trap 1: "Astrology is pseudoscience"

**Static:** Traditional astrology makes unfalsifiable claims about
personality and destiny based on planetary positions.

**Signal:** Computational astrology in QMNF is exact-integer modular
arithmetic on planetary longitudes expressed as arcseconds. It detects
modular zeros (e.g., 278289 mod 11 = 0) that correspond to harmonic
relationships invisible to angular geometry. The "aspects" are residue-
class patterns with unique CRT signatures (10 aspects, 10 unique tuples,
zero collisions). The "shadow bonds" are modular zeros on the Ramanujan
partition prime lane.

**The test:** Does 278289 mod 11 = 0? Yes. Is this a statement about
personality? No. Is it a statement about modular arithmetic? Yes.
The arithmetic is real regardless of whether you call it "astrology"
or "periodic harmonic analysis on integer residue classes."

**Rule: Judge the math, not the label.**

### Trap 2: "Ancient civilizations didn't have advanced mathematics"

**Static:** The Maya didn't know about CRT, Ramanujan primes, or
modular arithmetic in the formal sense.

**Signal:** The Maya DID compute:
- lcm(260, 365) = 18,980 (Calendar Round)
- lcm(260, 365, 584) = 37,960 (Venus Table)
- 11960 mod 378 = 242 (Eclipse/Saturn displacement)
- 78-stride lane nullification (Mars/Chaak tables)
- Deep-time projections spanning 32,000+ years via modular reduction
- Red/black intercalation as exact integer correction terms

Whether they CALLED it CRT is irrelevant. They COMPUTED with coprime
period decomposition and exact integer correction. The Antikythera
mechanism proves the Greeks did the same thing in gears. The mathematical
structure is independent of the civilization's terminology.

**The test:** Do the numbers in the Dresden Codex satisfy CRT identities?
Yes — verified against Swiss Ephemeris at 987/987 charts (100% CRT match
after Dresden corrections). The math works regardless of who built it.

**Rule: The mathematics doesn't care who discovered it.**

### Trap 3: "Navier-Stokes has nothing to do with prime numbers"

**Static:** Fluid dynamics and number theory are unrelated fields.

**Signal:** The DKAM subcriticality theorem uses the same 2 < 3 condition
that applies to the twin prime sieve: the degree-2 nonlinearity is
subcritical on coprime bases with resonance order ≥ 3. The Ramanujan
primes {5, 7, 11} that structure the singular series are the same primes
where NS stretching concentrates 78-86% of its CRT energy. The carry
pattern mechanism (Sqr operator threshold at p/2) that classifies prime
gaps also classifies vortex stretching lane behavior.

**The test:** Does stretching concentrate on {7, 11, 13}? Yes (verified
N = 4-16). Is deg(stretching) = 2? Yes (λ² scaling, <0.1% error).
Is ρ ≥ 3 for admissible bases? Yes (because 2 is excluded). Does
2 < 3? Yes.

**Rule: If the same mathematical structure appears in two domains,
investigate the structure, don't dismiss the connection.**

### Trap 4: "This is too many domains to be real"

**Static:** Real mathematical results don't span cryptography, fluid
dynamics, number theory, archaeoastronomy, and computational astrology
simultaneously.

**Signal:** CRT decomposition IS that general. Fourier analysis spans
signal processing, quantum mechanics, optics, heat transfer, and music.
Nobody says "Fourier can't be real because it applies to too many things."
CRT is the integer analog of Fourier. It SHOULD apply everywhere that
periodic decomposition applies.

**The test:** Does CRT work in each domain independently? Verify each
application on its own merits. If K-Elimination works for exact division,
that's proved regardless of whether T-SHADOW works for the Dresden Codex.
Each result stands or falls on its own evidence.

**Rule: Breadth of application is a property of the mathematical
substrate, not evidence of overreach.**

### Trap 5: "The codex images show CRAM? That's reading too much into it"

**Signal:** The Dresden Codex images show:
- Bar-and-dot numerals in independent horizontal bands (lane independence)
- Red and black number alternation (dual-value K-Elimination structure)
- Deity figures carrying different objects per band (operator assignment)
- Correction terms intercalated in the Venus tables (exact integer adjustment)
- 78-stride groupings in the Mars/Chaak tables (lane nullification)
- Serpent numbers spanning deep time (modular epoch traversal)

Whether the IMAGES "show CRAM" is Layer 3 interpretation. Whether the
NUMBERS computed by these tables satisfy CRT identities is Layer 1 fact.
Both can be true simultaneously. The interpretation can be wrong while
the mathematics is right.

**Rule: Evaluate the numerical content independently of the
iconographic interpretation.**

---

## SECTION 3: ENTRY POINTS FOR NEW EXPLORERS

### "I'm a mathematician. Where do I start?"

Read the DKAM Subcriticality Paper (DKAM_SUBCRITICALITY_PAPER.docx).
It's a conventional paper with axioms, definitions, theorems, proofs,
computational verification, and honest negatives. It claims one thing:
deg(stretching) = 2 < 3 = ρ(B) for admissible CRT bases. The killed
spectral gap hypothesis is documented in §5. Start here because it's
the most conventionally formatted result.

Then read the T-SHADOW formalization (T_SHADOW_v2_FORMALIZATION.docx).
It's a number theory result: the uniqueness of 11 as the shadow prime
of the Dresden period set. Five conditions, 42 validations.

### "I'm an engineer. Where do I start?"

Read the GEAR_MANIFOLD_README.md. It explains the CRT substrate as
a computational architecture. Then look at gear_manifold_v3.py —
2,553 passing tests, pure Python, readable. Run the tests yourself.
If they pass, the substrate works.

### "I'm interested in the Maya connection. Where do I start?"

Read the MATHEMATICS_GUIDE_COMPUTATIONAL_ASTROLOGY.md (Parts I-II).
It teaches CRT through the lens of planetary positions. Then read
Decoded.md (Gemini's 22-algorithm decode of the Dresden Codex).
Then verify the numbers yourself: 260 mod 11 = 7, 365 mod 11 = 2,
11960 mod 378 = 242 = 2 × 11². The arithmetic is the anchor.

### "I'm skeptical. What should I try to break?"

1. Check V1-V10 (validation identities in the CRAM Operator skill).
   If any fail, something is wrong.
2. Try to find another discretization where deg(stretching) < ρ(B).
   If you find one, our "only known" claim is wrong. Good — that's progress.
3. Extend the winding number survey to d > 1000. Does R² hold?
4. Run the ring homomorphism check at N = 32 or 64. Do violations appear?
5. Compute per-lane stretching at N = 32, 64, 128. Does SCR hold?
6. Find a period set P where 11 is NOT the unique shadow prime.
   (Any P containing a period divisible by 11 will do this.)

---

## SECTION 4: THE KILLED CLAIMS — WHAT TO IGNORE

These claims appeared in earlier versions and are DEAD. If you encounter
them in older documents, transcripts, or cross-AI synthesis, DO NOT
treat them as current:

```
DEAD: "841× spectral gap advantage" → Wrong operator (E1)
DEAD: "Resolution-independent Poincaré constant" → Same reason
DEAD: "Pharmacokinetic balance proves NS regularity" → Relied on E1
DEAD: "Carry chain sieve mechanism" → Dead beyond parity
DEAD: "Convergence rate as twin prime oracle" → Rates identical
DEAD: "Stride-S nullification preserves physics" → Energy diverges 2×
DEAD: "Raw CRT sync between resolutions" → Aliasing chaos
DEAD: "SQR eliminates exactly 50% for all families" → Family-dependent
DEAD: "×2 universal amplification via ROC ordering" → Permutation-invariant
DEAD: "PNT-gap normalization" → Mixed sample/per-prime statistic
DEAD: "Consciousness threshold at φ³ ≈ 4.236" → Retired by operator
```

**These are permanently documented to prevent resurrection.**
Each was tested, failed, and killed honestly. Their existence
is evidence of rigor, not of weakness.

---

## SECTION 5: THE HONEST BOUNDARIES

### What QMNF definitely IS:
- Exact-integer modular arithmetic on coprime bases
- A computational framework with 116+ validated innovations
- A working codebase (800K+ lines Rust, supporting Python)
- A set of proved/verified theorems with explicit scope conditions

### What QMNF might be:
- A path to NS regularity (via DKAM arithmetic invariance — open)
- A new approach to twin primes (via staging lane winding — open)
- A reframing of computational complexity (representation-dependent — speculative)
- An independent rediscovery of Maya computational methods (evidence strong, interpretation open)

### What QMNF is NOT:
- A proof of NS regularity (discrete results only, no continuum claim)
- A proof of the twin prime conjecture (sieve barrier still applies)
- A mystical or spiritual system (the math is arithmetic, period)
- A claim that the Maya had modern number theory (they had the computation without the formalism)
- Complete (the open problems list is long and honest)

---

## SECTION 6: THE MARCHING ORDERS

These apply to every exploration session:

  "Push on every stone. The wall falls not by identifying the keystone
  but by refusing to assume any stone is settled. Every major QMNF result
  came from following something labeled 'settled' with more integrity
  than it deserved. Kill your own hypotheses honestly. Report both sides
  of every boundary. No incompletely understood object is fit to be a
  line in the sand in the pursuit of knowledge."

Applied to new explorations:

1. **Check the arithmetic first.** Before evaluating any claim, verify
   the numbers. If they're wrong, the claim falls. If they're right,
   the claim deserves investigation regardless of how it sounds.

2. **Separate layers.** Is this Layer 1 (arithmetic), Layer 2 (structural
   claim), or Layer 3 (interpretation)? Evaluate each at its own level.

3. **Kill your own hypotheses.** If you build an argument and find a
   counterexample, document the kill. Don't hide it. The kill count
   is a measure of integrity, not failure.

4. **Don't let optics override mathematics.** "This sounds like astrology"
   is not a mathematical objection. "278289 mod 11 ≠ 0" would be.

5. **The representation matters.** The deepest finding of the QMNF program
   is that the choice of number system changes what's computable, what's
   tractable, and what's subcritical. Don't assume the representation is
   neutral. Test it.

---

## SECTION 7: REFERENCE INTEGRATION

| For this question | Use this skill | Explorer provides |
|---|---|---|
| "What is CRAM?" | qmnf-cram-educator | Layer classification |
| "How do I run CRAM?" | cram-operator | Operational context |
| "Is this prime special?" | prime-family-spacetime | Signal/static separation |
| "Formalize this claim" | theorem-crusher | Layer 1/2 identification |
| "What's the history of X?" | innovation-genealogy | Verified timeline |
| "Is this claim alive or dead?" | THIS SKILL | Killed claims registry |
| "Decompose this problem" | gap-scout | Exploration framing |
| "What would Tao do?" | tao-blueprint-method | Academic bridge |
| "Explore variations" | truth-perturber | Perturbation within layers |
| "Can we use this for NS/primes/FHE?" | cram-operator + this skill | Domain applicability |
