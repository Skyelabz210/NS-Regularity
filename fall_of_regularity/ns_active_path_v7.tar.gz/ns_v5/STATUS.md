# STATUS.md — Single Source of Truth
# NS Regularity Workspace — April 4, 2026
# 138 tests / 0 failures / ZERO float / 7,475 lines Rust

This document is the CANONICAL status reference for the entire workspace.
All other status documents (SHUTDOWN_CHECKLIST.md, SESSION_AUDIT.md,
THEOREM_STACK.md, ACTIVE_PATH.md, COMPENDIUM.md) are superseded by this file.

## Claim Label Definitions

| Label | Meaning | Verification |
|-------|---------|-------------|
| `[CODE FACT]` | Verified by `cargo test`. Pure arithmetic identity. | 109 instances in code |
| `[DISCRETE THEOREM]` | Proved for the lifted discrete scheme at N=8. | 84 instances in code |
| `[SCAFFOLDED]` | Infrastructure in place. Standard PDE theory applies IF discrete bounds transfer to N→∞. | Documented, not computed |
| `[OPEN]` | Honest gap. Requires either continuum PDE argument or further computation. | 23 instances in code |

## Three-Tier Claim Structure

### TIER 1: DISCRETE PROVED

These results are computationally verified for the exact-integer N=8 scheme.
They do NOT automatically transfer to the continuum limit.

| Result | Module | Label | Tests |
|--------|--------|-------|-------|
| 4-prime NTT exactness (roots, matrices, roundtrip) | ns3d.rs | CODE FACT | 8 |
| Garner 4-prime reconstruction | ns3d.rs | CODE FACT | 1 |
| Biot-Savart exact via NTT (N=8, M=71,213,617) | ns3d.rs | DISCRETE THEOREM | 3 |
| Discrete Laplacian (6-point, exact, zero truncation) | ns3d.rs | DISCRETE THEOREM | 2 |
| Discrete advection/stretching (TRUNC ≤ 1/cell) | ns3d.rs | DISCRETE THEOREM | 1 |
| Maximum principle under pure diffusion (3D, 20 steps) | ns3d.rs | DISCRETE THEOREM | 1 |
| Enstrophy non-increasing under pure diffusion (30 steps) | ns3d.rs | DISCRETE THEOREM | 1 |
| CFL condition (integer check) | ns3d.rs | CODE FACT | 1 |
| Kill #113: skew-symmetric advection = INTEGER ZERO | ns3d_energy.rs | CODE FACT | 5 |
| Kill #121: energy residual = 0 in all NTT prime lanes | ns3d_energy.rs | CODE FACT | 1 |
| Energy non-increasing under ns_step_skew (15 steps) | ns3d_energy.rs | DISCRETE THEOREM | 1 |
| Uniform H¹ bound (Aubin-Lions condition i) | ns3d_energy.rs | DISCRETE THEOREM | 1 |
| Time-derivative bound (Aubin-Lions condition ii) | ns3d_energy.rs | DISCRETE THEOREM | 1 |
| H¹/H² seminorms via summation by parts (exact i128) | ns3d_sobolev.rs | CODE FACT | 6 |
| Sobolev embedding ‖ω‖²∞ ≤ C·‖ω‖²H² | ns3d_sobolev.rs | DISCRETE THEOREM | 2 |
| Contraction bound B(N) ≤ 90/1001 (algebraic, N=1..1001) | lib.rs | CODE FACT | 4 |
| Recumbent tiered exact integer (corridor/overflow/hot) | recumbent.rs | CODE FACT | 13 |
| WASSAN persistence roundtrip | wassan.rs + ns3d_wassan.rs | CODE FACT | 7+15 |
| NS evolution stable for TG (10 steps, full NS) | ns3d.rs | DISCRETE THEOREM | 1 |
| NS evolution stable for random 3D (20 steps, normalized BS) | ns3d_sobolev.rs | DISCRETE THEOREM | 1 |
| Nonzero stretching measured for random 3D field | ns3d_sobolev.rs | CODE FACT | 1 |

### TIER 2: CONTINUUM SCAFFOLDED

These results follow from TIER 1 by standard PDE theory (Lions 1969,
Beale-Kato-Majda 1984, Aubin-Lions lemma) IF the discrete bounds
transfer uniformly as N → ∞. The scaffolding is documented in code
and tests, but the N→∞ limit itself is NOT computationally verified.

| Result | Depends On | Standard Reference |
|--------|-----------|-------------------|
| Aubin-Lions compactness: ω_N → ω strongly in L²(0,T;L²) | H¹ uniform bound (TIER 1) + time-derivative bound (TIER 1) | Lions 1969 |
| Nonlinear passage: bilinear terms converge in distributions | Aubin-Lions + consistency (TIER 1) | Standard weak convergence |
| Leray-Hopf weak solution exists | Aubin-Lions + nonlinear passage | Leray 1934 |
| BKM regularity: if ∫‖ω‖∞ < ∞ then smooth | L∞ bound from discrete max principle | Beale-Kato-Majda 1984 |

### TIER 3: OPEN

These are honest gaps. They are NOT claimed as solved.

| Gap | What Would Close It | Current Evidence |
|-----|-------------------|-----------------|
| Super-threshold stretching bound: is C_stretch bounded for large 3D data? | Measure C_stretch at higher amplitudes where stretching is nonzero; prove independence of N | Random field at amp~100: SIP=-5005, solution decays. ABC at high amp: blows up (Beltrami class). |
| Uniform-in-N limit: do discrete bounds transfer as N→∞? | Run N=16, N=32 with extended NTT primes; verify same qualitative behavior | Only N=8 data available. N=16 requires larger NTT prime set. |
| Integer Fujita-Kato threshold T_FK(N): does it grow with N? | Compute T_FK at N=8, 16, 32; analyze scaling | T_FK ~ SCALE × √(SCALE/N) → decreases with N (standard Fujita-Kato). |

## BS Normalization

The NTT-based Biot-Savart has an amplification factor of N⁶ = 262,144 at N=8.
The `biot_savart_normalized()` function corrects this.

| Function | Velocity | Stability |
|----------|----------|-----------|
| `biot_savart_n8()` (raw) | 264,000 × |ω| | Only stable for zero-stretching flows (TG, ABC) |
| `biot_savart_normalized()` (÷N⁶) | 1 × |ω| | Stable for 3D random fields at amplitude ~100 |

The raw BS is used by all existing tests (they pass because TG/ABC have zero stretching).
The normalized BS is used for stretching measurement (seam tests).
The N⁶ factor needs analytical derivation — currently empirically calibrated.

## Flow Classification

| Flow | ⟨ω, (ω·∇)u⟩ | Reason | Regularity |
|------|-------------|--------|------------|
| Taylor-Green | = 0 EXACTLY | 2D (ωz = 0) | DISCRETE PROVED |
| ABC | = 0 EXACTLY | Beltrami (ω ∝ u, ∇·u = 0) | DISCRETE PROVED |
| Sheared tube | = 0 EXACTLY | Structural cancellation in sum | DISCRETE PROVED |
| Random 3D | = -5005 (nonzero) | No symmetry | DISCRETE PROVED (decays at amp~100) |
| Random 3D (large amp) | nonzero, large | No symmetry | OPEN |

## File Inventory

| File | Lines | Role | Status |
|------|-------|------|--------|
| src/ns3d.rs | 1326 | 3D exact solver, NTT-BS, operators, NS step | Active, primary |
| src/ns3d_energy.rs | 814 | Kill #113, energy identity, Aubin-Lions, BKM | Active, primary |
| src/ns3d_sobolev.rs | 1694 | H^s norms, Sobolev embedding, stretching measurement | Active, primary |
| src/ns3d_wassan.rs | 664 | CRTBigInt-backed WASSAN persistence for NS | Active, primary |
| src/recumbent.rs | 751 | Tiered exact integer (corridor/overflow/hot) | Active, primary |
| src/wassan.rs | 326 | WASSAN drive (key-value persistence) | Active, primary |
| src/lib.rs | 681 | Contraction bound T1-T10, Lean formalization | Active, regression |
| src/cram_ns.rs | 169 | 1D CRT-lane NS (archived regression) | Archived |
| qmnf_crtbigint/src/lib.rs | 1050 | CRTBigInt v3.1 arithmetic core | Active, dependency |

## What This Workspace IS

A computational framework that:
1. Implements exact-integer 3D Navier-Stokes on an N=8 periodic grid
2. Proves discrete energy conservation (Kill #113) as an exact integer identity
3. Proves discrete stability (enstrophy, H¹, H², max principle) for diffusion
4. Measures nonzero stretching for generic 3D flows
5. Demonstrates that diffusion dominates stretching for small-data random fields
6. Scaffolds the continuum limit via standard PDE theory (Aubin-Lions, BKM)
7. Honestly identifies the three open gaps (super-threshold, N→∞, T_FK scaling)

## What This Workspace IS NOT

A proof of the Clay Millennium Problem. The super-threshold 3D case and the
uniform-in-N transfer remain open. The workspace provides the computational
infrastructure to attack these gaps but does not close them.

## Build and Test

```bash
tar xzf ns_active_path_v6.tar.gz
cd ns_v5
cargo test  # Expected: 138 passed, 0 failed, ~10 seconds
```
