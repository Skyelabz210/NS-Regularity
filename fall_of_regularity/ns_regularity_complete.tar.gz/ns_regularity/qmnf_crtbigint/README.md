# qmnf_crtbigint

`qmnf_crtbigint` is a CRT-native exact arithmetic substrate built around eight 63-bit prime lanes, Montgomery modular arithmetic, and K-Elimination bridges.

## Core capabilities

- Exact residue-lane integer representation across 8 coprime 63-bit primes
- Lane-local modular add/sub/mul with `u128` intermediates
- Montgomery multiplication and exponentiation
- Garner-style bounded reconstruction helpers
- K-Elimination between coprime lanes
- Safe Basis smooth-factor decomposition over `{2,3,5,7,11,13}`
- Approximation sub-lanes and triadic composition
- Safe Anchor, WASSAN bands, PLMG validator, Double Helix, and scaffold tiers

## Architectural note

This crate is best understood as a **stackable exact block**, not as a flat monolithic bigint decoder. The local CRT arithmetic is exact inside each lane block; larger range is intended to be extended structurally through anchor, band, and scaffold composition rather than by forcing a one-shot decode of the full multi-lane state.

## Important limitation

Some helper reconstruction APIs return `u128`. Those helpers are suitable for bounded decode paths, debugging, and small-value recovery, but they do **not** by themselves certify full-width flattening of the entire multi-lane state.
