Tidying pass applied:

- moved `lib.rs` into conventional `src/lib.rs`
- simplified manifest and removed unused `criterion` dev-dependency
- tightened crate description and added README
- preserved the uploaded API surface and implementation as-is

Not changed in this pass:

- arithmetic semantics
- public type names
- reconstruction behavior
- K-Elimination behavior
- test bodies embedded in `src/lib.rs`

Recommended next hardening pass:

1. split the file into modules (`montgomery`, `crt`, `kelim`, `smooth`, `wassan`, `plmg`, `scaffold`)
2. replace `u128` reconstruction helpers with explicit bounded/full reconstruction APIs
3. audit sign semantics in `Add` and `Sub`
4. add `cargo fmt`, `clippy`, and `cargo test` once Rust tooling is available
