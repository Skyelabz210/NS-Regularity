//! # Recumbent CRTBigInt v1.0 — Production Rust Port
//!
//! Tiered exact integer with corridor + overflow + hot lane.
//! This is the overflow-geometry law for the NS regularity argument.
//!
//! ## Architecture
//!
//! ```text
//! qmnf_crtbigint    →  arithmetic core (8×63-bit lanes)
//! recumbent.rs       →  overflow-geometry law (this file)
//! cram_ns.rs         →  NS evolution consumer
//! WASSAN             →  persistence/depth fabric
//! ```
//!
//! ## Split Rule
//!
//! For value v with corridor radius R:
//!   if |v| < R:   primary = v, overflow = None, hot = None
//!   if |v| ≥ R:   primary = sign(v)·(R-1), overflow = v - primary
//!   if |overflow| ≥ T:  promote overflow → hot lane
//!
//! ## Demotion Rule (NEW — critical for NS)
//!
//! After each operation, if the total |v| < R, DEMOTE:
//!   clear overflow and hot, set primary = v.
//! This is how diffusion brings vorticity back into the corridor.
//!
//! ## Reconstruction Invariant
//!
//! For ANY sequence of operations:
//!   reconstruct() = primary.value + overflow.overflow + hot.value
//!                 = the exact mathematical result
//! This invariant is tested exhaustively.

use std::collections::HashMap;

/// Integer periodic initial condition. No float.
/// Parabolic arch: peak = SCALE at j = N/4.
/// Smooth (C1), periodic, zero-mean. All integer arithmetic.
pub fn integer_ic(n: usize, scale: i64) -> Vec<i64> {
    let half = n / 2;
    let half_sq = (half * half) as i64;
    (0..n).map(|j| {
        if j < half {
            let jj = j as i64;
            scale * 4 * jj * (half as i64 - jj) / half_sq
        } else {
            let jj = (j - half) as i64;
            -(scale * 4 * jj * (half as i64 - jj) / half_sq)
        }
    }).collect()
}

// ═══════════════════════════════════════════════════════════════════════
// LANE TYPES
// ═══════════════════════════════════════════════════════════════════════

/// Primary lane: value within centered corridor [-R, R).
/// CRT contraction bound B ≤ 90/1001 operates HERE.
#[derive(Clone, Debug, PartialEq)]
pub struct PrimaryLane {
    pub value: i64,
    pub radius: i64,
}

impl PrimaryLane {
    pub fn fits(&self) -> bool { self.value.abs() < self.radius }
}

/// Composite overflow lane: exact excess beyond primary corridor.
/// Tracks stretching transient. Diffusion reduces this toward zero.
#[derive(Clone, Debug, PartialEq)]
pub struct OverflowLane {
    pub overflow: i64,
    pub threshold: i64,
}

impl OverflowLane {
    pub fn should_promote(&self) -> bool { self.overflow.abs() >= self.threshold }
}

/// Hot lane: promoted overflow for values far beyond corridor.
/// Phase-locked to primary via K-Elimination winding number.
#[derive(Clone, Debug, PartialEq)]
pub struct HotLane {
    pub value: i64,
}

// ═══════════════════════════════════════════════════════════════════════
// RECUMBENT CORE
// ═══════════════════════════════════════════════════════════════════════

/// Recumbent CRTBigInt: tiered exact integer.
/// reconstruct() = primary + overflow + hot = EXACT, always.
#[derive(Clone, Debug)]
pub struct Recumbent {
    pub primary: PrimaryLane,
    pub overflow: Option<OverflowLane>,
    pub hot: Option<HotLane>,
    pub primary_radius: i64,
    pub promotion_threshold: i64,
    /// Tracks how many operations this value has spent outside corridor.
    pub overflow_steps: u64,
}

impl Recumbent {
    /// Split rule: decompose integer into primary + overflow + hot.
    pub fn new(value: i64, primary_radius: i64, promotion_threshold: i64) -> Self {
        let mut r = Recumbent {
            primary: PrimaryLane { value: 0, radius: primary_radius },
            overflow: None,
            hot: None,
            primary_radius,
            promotion_threshold,
            overflow_steps: 0,
        };
        r.assign(value);
        r
    }

    /// The split/demotion assignment. Called on every construction and operation.
    fn assign(&mut self, value: i64) {
        if value.abs() < self.primary_radius {
            // DEMOTION: value fits in corridor. Clear overflow and hot.
            self.primary.value = value;
            self.overflow = None;
            self.hot = None;
            // overflow_steps stays — it's a cumulative counter
        } else {
            // Split: primary saturates at corridor boundary
            let (pv, ovf) = if value >= 0 {
                (self.primary_radius - 1, value - (self.primary_radius - 1))
            } else {
                (-self.primary_radius + 1, value - (-self.primary_radius + 1))
            };
            self.primary.value = pv;
            self.overflow_steps += 1;

            if ovf.abs() >= self.promotion_threshold {
                // Promote to hot lane
                self.overflow = None;
                self.hot = Some(HotLane { value: ovf });
            } else {
                self.overflow = Some(OverflowLane {
                    overflow: ovf,
                    threshold: self.promotion_threshold,
                });
                self.hot = None;
            }
        }
    }

    /// NS-default constructor: R = SCALE, T = SCALE²
    pub fn from_ns(value: i64) -> Self {
        Self::new(value, 10_000, 100_000_000)
    }

    /// Reconstruct the EXACT integer. INVARIANT: never loses information.
    pub fn reconstruct(&self) -> i64 {
        let mut v = self.primary.value;
        if let Some(ref o) = self.overflow { v += o.overflow; }
        if let Some(ref h) = self.hot { v += h.value; }
        v
    }

    /// Is the value entirely within the primary corridor?
    pub fn in_corridor(&self) -> bool {
        self.overflow.is_none() && self.hot.is_none()
    }

    /// Which tier is active?
    pub fn tier(&self) -> &str {
        if self.in_corridor() { "PRIMARY" }
        else if self.hot.is_some() { "HOT" }
        else { "OVERFLOW" }
    }

    /// The overflow magnitude (0 if in corridor).
    pub fn overflow_magnitude(&self) -> i64 {
        if let Some(ref o) = self.overflow { o.overflow.abs() }
        else if let Some(ref h) = self.hot { h.value.abs() }
        else { 0 }
    }

    // ── Arithmetic (reconstruct → compute → re-split) ──

    pub fn add(&self, other: &Recumbent) -> Recumbent {
        let mut r = Recumbent::new(0, self.primary_radius, self.promotion_threshold);
        r.overflow_steps = self.overflow_steps.max(other.overflow_steps);
        r.assign(self.reconstruct() + other.reconstruct());
        r
    }

    pub fn sub(&self, other: &Recumbent) -> Recumbent {
        let mut r = Recumbent::new(0, self.primary_radius, self.promotion_threshold);
        r.overflow_steps = self.overflow_steps.max(other.overflow_steps);
        r.assign(self.reconstruct() - other.reconstruct());
        r
    }

    pub fn mul(&self, other: &Recumbent) -> Recumbent {
        let mut r = Recumbent::new(0, self.primary_radius, self.promotion_threshold);
        r.overflow_steps = self.overflow_steps.max(other.overflow_steps);
        r.assign(self.reconstruct().checked_mul(other.reconstruct()).unwrap_or(i64::MAX));
        r
    }

    /// K-Elimination division: exact integer division toward zero.
    pub fn k_div(&self, d: i64) -> Recumbent {
        let v = self.reconstruct();
        let q = if (v >= 0) == (d > 0) { v.abs() / d.abs() } else { -(v.abs() / d.abs()) };
        let mut r = Recumbent::new(0, self.primary_radius, self.promotion_threshold);
        r.overflow_steps = self.overflow_steps;
        r.assign(q);
        r
    }

    /// In-place push: add integer directly (for step-by-step evolution).
    pub fn push(&mut self, delta: i64) {
        let new_val = self.reconstruct() + delta;
        self.assign(new_val);
    }

    /// Force demotion check (call after diffusion step).
    pub fn try_demote(&mut self) {
        let v = self.reconstruct();
        self.assign(v);
    }
}

// ═══════════════════════════════════════════════════════════════════════
// WASSAN HOLOGRAPHIC DRIVE (persistence layer)
// ═══════════════════════════════════════════════════════════════════════

/// Stores Recumbent states by key. Reconstruction-safe:
/// write stores the exact integer, read rebuilds the tiered structure.
pub struct WassonDrive {
    primary_radius: i64,
    promotion_threshold: i64,
    data: HashMap<String, i64>,
}

impl WassonDrive {
    pub fn new(primary_radius: i64, promotion_threshold: i64) -> Self {
        WassonDrive { primary_radius, promotion_threshold, data: HashMap::new() }
    }

    pub fn ns_default() -> Self { Self::new(10_000, 100_000_000) }

    pub fn write(&mut self, key: &str, value: &Recumbent) {
        self.data.insert(key.to_string(), value.reconstruct());
    }

    pub fn read(&self, key: &str) -> Option<Recumbent> {
        self.data.get(key).map(|&v| Recumbent::new(v, self.primary_radius, self.promotion_threshold))
    }

    pub fn depth(&self) -> usize { self.data.len() }
}

// ═══════════════════════════════════════════════════════════════════════
// NS EVOLUTION ON RECUMBENT
// ═══════════════════════════════════════════════════════════════════════

/// One NS step: CFL-limit stencil (c=1/6).
/// Diffusion: (4ω + ω_l + ω_r) / 6
/// Stretching: ω × (ω_r - ω_l) / (2 × SCALE)
/// This stencil shows the corridor dynamics: overshoot then return.
pub fn recumbent_ns_step(omega: &[Recumbent], _n: usize) -> Vec<Recumbent> {
    let n = omega.len();
    let scale = 10_000i64;

    (0..n).map(|j| {
        let jp = (j + 1) % n;
        let jm = (j + n - 1) % n;
        // All arithmetic in i128 to prevent overflow
        let wj = omega[j].reconstruct() as i128;
        let wp = omega[jp].reconstruct() as i128;
        let wm = omega[jm].reconstruct() as i128;

        // Diffusion at CFL limit: (4ω + ω_l + ω_r) / 6
        let diffused = (4 * wj + wm + wp) / 6;

        // Stretching: ω × (ω_r - ω_l) / (2 × SCALE)
        let grad = wp - wm;
        let stretch = wj * grad / (2 * scale as i128);

        let new_val = (diffused + stretch) as i64;

        let mut r = Recumbent::new(0, omega[j].primary_radius, omega[j].promotion_threshold);
        r.overflow_steps = omega[j].overflow_steps;
        r.assign(new_val);
        r
    }).collect()
}

/// Measure overshoot with full Recumbent diagnostics.
pub fn recumbent_overshoot(n: usize, steps: usize) -> RecumbentDiagnostics {
    let ic = integer_ic(n, 10_000);
    let mut omega: Vec<Recumbent> = ic.iter().map(|&v| {
        Recumbent::from_ns(v)
    }).collect();

    let ini = omega.iter().map(|c| c.reconstruct().abs()).max().unwrap();
    let mut pk = ini;
    let mut pk_step = 0;
    let mut max_overflow_steps = 0u64;
    let mut corridor_steps = 0usize;
    let mut total_steps = 0usize;

    for step in 0..steps {
        omega = recumbent_ns_step(&omega, n);
        let cm = omega.iter().map(|c| c.reconstruct().abs()).max().unwrap();
        if cm > pk { pk = cm; pk_step = step + 1; }

        let all_in = omega.iter().all(|c| c.in_corridor());
        if all_in { corridor_steps += 1; }
        total_steps += 1;

        let max_os = omega.iter().map(|c| c.overflow_steps).max().unwrap_or(0);
        if max_os > max_overflow_steps { max_overflow_steps = max_os; }
    }

    let fin = omega.iter().map(|c| c.reconstruct().abs()).max().unwrap();

    RecumbentDiagnostics {
        n, ini, pk, fin, pk_step,
        corridor_steps,
        total_steps,
        max_overflow_steps,
    }
}

pub struct RecumbentDiagnostics {
    pub n: usize,
    pub ini: i64,
    pub pk: i64,
    pub fin: i64,
    pub pk_step: usize,
    pub corridor_steps: usize,
    pub total_steps: usize,
    pub max_overflow_steps: u64,
}

// ═══════════════════════════════════════════════════════════════════════
// TESTS
// ═══════════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    // ── Split rule ──
    #[test]
    fn split_in_corridor() {
        let r = Recumbent::new(123, 1000, 5000);
        assert!(r.in_corridor());
        assert_eq!(r.reconstruct(), 123);
        assert_eq!(r.tier(), "PRIMARY");
    }

    #[test]
    fn split_overflow() {
        let r = Recumbent::new(2000, 1000, 5000);
        assert!(!r.in_corridor());
        assert!(r.overflow.is_some());
        assert_eq!(r.tier(), "OVERFLOW");
        assert_eq!(r.reconstruct(), 2000);
    }

    #[test]
    fn split_hot_promotion() {
        let r = Recumbent::new(1_000_000_000, 1000, 10_000);
        assert_eq!(r.tier(), "HOT");
        assert_eq!(r.reconstruct(), 1_000_000_000);
    }

    #[test]
    fn split_negative() {
        let r = Recumbent::new(-5000, 1000, 100_000);
        assert_eq!(r.reconstruct(), -5000);
        assert!(!r.in_corridor());
    }

    // ── Reconstruction invariant ──
    #[test]
    fn reconstruction_invariant_exhaustive() {
        // For EVERY integer in [-50000, 50000], verify reconstruct() = original
        for v in -50000i64..=50000 {
            let r = Recumbent::new(v, 1000, 10000);
            assert_eq!(r.reconstruct(), v, "reconstruction failed at {}", v);
        }
    }

    // ── Demotion rule ──
    #[test]
    fn demotion_on_return_to_corridor() {
        // Value starts outside corridor, then shrinks back
        let mut r = Recumbent::new(5000, 1000, 100_000);
        assert!(!r.in_corridor());
        assert_eq!(r.overflow_steps, 1);

        // "Diffusion" reduces the value
        r.push(-4500);  // 5000 - 4500 = 500 < 1000 → should demote
        assert!(r.in_corridor(), "should demote back to PRIMARY");
        assert_eq!(r.reconstruct(), 500);
    }

    // ── Arithmetic ──
    #[test]
    fn add_in_corridor() {
        let c = Recumbent::new(400, 500, 1000).add(&Recumbent::new(50, 500, 1000));
        assert_eq!(c.reconstruct(), 450);
        assert!(c.in_corridor());
    }

    #[test]
    fn add_triggers_overflow() {
        let c = Recumbent::new(300, 500, 10000).add(&Recumbent::new(400, 500, 10000));
        assert_eq!(c.reconstruct(), 700);
        assert!(!c.in_corridor());
    }

    #[test]
    fn sub_and_k_div() {
        assert_eq!(Recumbent::new(800, 500, 10000).sub(&Recumbent::new(300, 500, 10000)).reconstruct(), 500);
        assert_eq!(Recumbent::new(42, 100, 1000).k_div(6).reconstruct(), 7);
        assert_eq!(Recumbent::new(-30, 100, 1000).k_div(6).reconstruct(), -5);
    }

    // ── WASSAN Drive ──
    #[test]
    fn wassan_roundtrip() {
        let mut drive = WassonDrive::ns_default();
        let vals = [123i64, -456, 50000, -1_000_000, 0];
        for (i, &v) in vals.iter().enumerate() {
            drive.write(&format!("k{}", i), &Recumbent::from_ns(v));
        }
        assert_eq!(drive.depth(), 5);
        for (i, &v) in vals.iter().enumerate() {
            let r = drive.read(&format!("k{}", i)).unwrap();
            assert_eq!(r.reconstruct(), v, "WASSAN roundtrip failed at {}", v);
        }
    }

    // ── NS Evolution on Recumbent ──
    #[test]
    fn recumbent_ns_constant() {
        let omega: Vec<Recumbent> = (0..8).map(|_| Recumbent::from_ns(600)).collect();
        let result = recumbent_ns_step(&omega, 8);
        for c in &result {
            // Constant field: lap=0, grad=0 → ω'=ω
            assert_eq!(c.reconstruct(), 600);
        }
    }

    #[test]
    fn recumbent_ns_overshoot() {
        println!("\n{}", "=".repeat(78));
        println!("  RECUMBENT NS: corridor dynamics + overflow tracking");
        println!("  Primary R=10000 (contraction zone) | Overflow tracks transient");
        println!("{}\n", "=".repeat(78));

        println!("{:>5} {:>8} {:>8} {:>8} {:>6} {:>8} {:>8}",
            "N", "init", "peak", "final", "pk_st", "corr%", "ovf_st");
        println!("{}", "-".repeat(60));

        for &n in &[16usize, 32, 64, 128, 256] {
            let d = recumbent_overshoot(n, 200);
            let corr_pct = d.corridor_steps * 100 / d.total_steps.max(1);
            println!("{:>5} {:>8} {:>8} {:>8} {:>6} {:>7}% {:>8}",
                d.n, d.ini, d.pk, d.fin, d.pk_step, corr_pct, d.max_overflow_steps);
        }
    }
}

    #[test]
    fn corridor_dynamics_detail() {
        println!("\n{}", "=".repeat(78));
        println!("  CORRIDOR DYNAMICS: value leaves, overflows, returns");
        println!("  Primary R=10000 | Contraction B ≤ 90/1001 applies IN corridor");
        println!("{}\n", "=".repeat(78));

        let n = 64usize;
        let ic = integer_ic(n, 10_000);
        let mut omega: Vec<Recumbent> = ic.iter().map(|&v| {
            Recumbent::from_ns(v)
        }).collect();

        println!("{:>4} {:>8} {:>8} {:>8} {:>8} {:>8}",
            "step", "max|w|", "primary", "ovf_mag", "tier", "in_corr");
        println!("{}", "-".repeat(55));

        let mut returned = false;
        for step in 0..200 {
            omega = recumbent_ns_step(&omega, n);
            let max_cell = omega.iter().max_by_key(|c| c.reconstruct().abs()).unwrap();
            let max_w = max_cell.reconstruct().abs();
            let all_in = omega.iter().all(|c| c.in_corridor());
            let pct_in = omega.iter().filter(|c| c.in_corridor()).count() * 100 / n;

            if step < 10 || step % 20 == 19 || (all_in && !returned) {
                println!("{:>4} {:>8} {:>8} {:>8} {:>8} {:>7}%",
                    step + 1, max_w, max_cell.primary.value,
                    max_cell.overflow_magnitude(),
                    max_cell.tier(), pct_in);
                if all_in && !returned {
                    println!("       ★ ALL CELLS RETURNED TO CORRIDOR");
                    println!("         Contraction B ≤ 90/1001 now applies to every cell");
                    returned = true;
                }
            }
        }

        if !returned {
            let pct_in = omega.iter().filter(|c| c.in_corridor()).count() * 100 / n;
            println!("\n  At step 200: {}% of cells in corridor", pct_in);
        }
    }
