# Exact-Integer NS Regularity: What Is Proved and What Is Not

**Anthony Diaz (Acid) — HackFate.us / Skyelabz210**
**with Claude (Anthropic) — April 2026**

## Quick Start

```bash
cargo test -- --nocapture
```

Expected: **30 passed, 0 failed.** Runtime ~23 seconds.

## What IS Proved

### Theorem T1 (Residue Contraction): B(N) ≤ 90/1001 for ALL N.
The self-coefficient of the 7-point stencil, reduced modulo the
discriminating primes {7, 11, 13}, contracts by at least 90/1001
per step. This is an algebraic identity, unconditional.

### Theorem T5 (Integer Maximum Principle — Diffusion Only):
Under CFL, the diffusion stencil is a convex combination.
max|ω'| ≤ max|ω|. Verified exhaustively on [-500, 500]³.

### Theorem T21 (Winding Number Contracts — Diffusion Only):
The winding number k (where ω = r + k·p) evolves by the
same convex stencil. Carries are zero at CFL.
max|k'| ≤ max|k|. Verified exhaustively.

## What Is NOT Proved

### The 3D Maximum Principle with Stretching FAILS.
Measured empirically (1D model, N=64, single-mode sine wave):
- Initial max|ω| = 10,000
- Peak max|ω|    = 26,913 (2.69× overshoot)
- Final max|ω|   = 1,257  (decayed after 200 steps)

Stretching causes REAL transient growth of the integer vorticity
even while residues contract. Diffusion eventually dominates,
but the transient can be large (2.69× in this test).

**This is the Millennium Problem.** Can the transient growth
cascade to infinity before diffusion catches up? The answer
is not known for general 3D initial data.

## What the Framework Provides

1. An exact-integer discretization of 3D NS (zero float)
2. A provable algebraic contraction bound on residues
3. A clear identification of WHERE the Millennium Problem lives
   (the winding number k can grow transiently due to stretching)
4. Empirical evidence that diffusion dominates stretching for
   smooth initial data (solution decays to 12.6% after 200 steps)
5. All tools to measure and track the gap computationally

## Theorem Index

| # | Name | Status |
|---|------|--------|
| T1 | Residue contraction 90/1001 | PROVED (algebraic) |
| T2 | Exhaustive N=1..1001 | PROVED (computational) |
| T3 | c_s N-independent | PROVED (definition) |
| T4 | Permanent non-resonance | PROVED (computation) |
| T5 | Max principle (diffusion) | PROVED (convexity) |
| T7 | Full regularity chain | CONDITIONAL on stretching bound |
| T8-T10 | CRT range, stretching, total | PROVED for diffusion; OPEN with stretching |
| T11-T12 | Enstrophy, H¹ bound | PROVED for diffusion |
| T13-T14 | Interpolation | PROVED |
| T15-T16 | Time deriv, truncation | PROVED |
| T17-T20 | Nonlinear, BKM, uniqueness | CONDITIONAL on L^∞ bound |
| T21-T22 | Winding, integer max principle | PROVED for diffusion |
| T23 | Stretching empirical | HONEST NEGATIVE: transient growth measured |

## Honest Bottom Line

**Millennium Problem status: OPEN.**

The discrete algebraic framework (B ≤ 90/1001) is correct and novel.
The maximum principle holds for diffusion only. With stretching,
the integer vorticity can grow transiently. Whether this transient
growth can blow up in finite time is the Millennium Problem itself.

The contribution is a new algebraic lens (CRT residue contraction)
that separates the problem into what CAN be proved (residue bounds,
winding contraction under diffusion) and what CANNOT yet be proved
(integer contraction with stretching).

## Files

| File | Lines | Content |
|------|-------|---------|
| src/lib.rs | ~1,300 | 23 theorems, 30 tests, 0 failures |
| theorem1.lean | 31 | Lean 4 (sorry-free, residue bound only) |
| THEOREM_STACK.md | 613+ | Complete theorem stack |

## Requirements

`rustc` (any stable version). Zero crates.io dependencies.
