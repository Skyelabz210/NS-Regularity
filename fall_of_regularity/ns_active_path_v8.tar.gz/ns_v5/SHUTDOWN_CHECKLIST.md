# SHUTDOWN_CHECKLIST.md — SUPERSEDED
# See STATUS.md for the canonical single-source-of-truth status.
# This file preserved for git history only.
