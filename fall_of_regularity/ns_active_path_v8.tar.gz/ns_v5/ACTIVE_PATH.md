# ACTIVE_PATH.md — SUPERSEDED
# See STATUS.md for the canonical single-source-of-truth status.

## Active modules (unchanged)
- src/ns3d.rs, src/ns3d_energy.rs, src/ns3d_sobolev.rs, src/ns3d_wassan.rs
- src/recumbent.rs, src/wassan.rs, src/lib.rs

## Archived
- src/cram_ns.rs (1D regression only)
