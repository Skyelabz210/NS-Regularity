# COMPENDIUM.md — SUPERSEDED
# See STATUS.md for the canonical single-source-of-truth status.
# See NS_SEAM_FORMALIZATION.md for the theorem crusher output.
