//! # Partition Function Chimera
//!
//! ## The Primon Gas: ζ(s) IS the Partition Function
//!
//! Each prime p is a quantum oscillator with energy E_p = ln(p).
//! The partition function of this gas is:
//!
//!   Z(β) = Σ_{n=1}^∞ n^{-β} = ζ(β)
//!
//! The Euler product ζ(s) = Π_p 1/(1-p^{-s}) factors Z into
//! independent single-oscillator partition functions — EXACTLY
//! the CRT decomposition. Each CRT lane IS one oscillator.
//! The occupation number of the p-oscillator is v_p(n) (the
//! p-adic valuation of n). The total energy of state n is:
//!
//!   E(n) = Σ_p v_p(n) · ln(p) = ln(n)
//!
//! ## The Integer Partition Function p(n)
//!
//! p(n) counts the ways to write n as a sum of positive integers.
//! Generating function: Σ p(n) q^n = Π_{k≥1} 1/(1-q^k)
//!
//! The Ramanujan congruences:
//!   p(5n+4)  ≡ 0 (mod 5)   — for ALL n
//!   p(7n+5)  ≡ 0 (mod 7)   — for ALL n
//!   p(11n+6) ≡ 0 (mod 11)  — for ALL n
//!
//! S_R = {5, 7, 11} is COMPLETE. No other first-order congruence exists.
//! This is the MEASUREMENT tier of the CRAM architecture.
//!
//! ## The Chimera
//!
//! The partition chimera computes:
//!   - p(n) mod each S_R prime (exact, via recurrence)
//!   - ζ residues via Euler product on CRT lanes
//!   - The Ramanujan congruence as a CRAM carry event
//!   - The primon gas energy as log-residue on the torus
//!
//! Zero float. All arithmetic exact integer.

/// The Ramanujan primes — the ONLY primes with first-order partition congruences.
pub const S_R: [u64; 3] = [5, 7, 11];

/// The Ramanujan offsets: p(ℓn + δ_ℓ) ≡ 0 (mod ℓ)
pub const RAMANUJAN_OFFSETS: [(u64, u64); 3] = [(5, 4), (7, 5), (11, 6)];

/// Safe Basis (full)
pub const SAFE_BASIS: [u64; 6] = [2, 3, 5, 7, 11, 13];

/// Compute p(n) mod m exactly via the recurrence.
///
/// p(n) = Σ_{k=1}^{n} (-1)^{k+1} [p(n - k(3k-1)/2) + p(n - k(3k+1)/2)]
///
/// where the pentagonal numbers are k(3k±1)/2 for k = 1, 2, 3, ...
/// and p(0) = 1, p(negative) = 0.
///
/// This is EXACT modular arithmetic — no float.
pub fn partition_mod(n: u64, m: u64) -> u64 {
    if n == 0 { return 1 % m; }
    
    // Build table p(0..n) mod m
    let n = n as usize;
    let m_us = m as usize;
    let mut table = vec![0usize; n + 1];
    table[0] = 1 % m_us;
    
    for i in 1..=n {
        let mut val: i64 = 0;
        let mut k: i64 = 1;
        loop {
            // Generalized pentagonal numbers: k(3k-1)/2 and k(3k+1)/2
            // for k = 1, -1, 2, -2, 3, -3, ...
            let pent1 = (k * (3 * k - 1) / 2) as usize;
            if pent1 > i { break; }
            
            // Sign: (-1)^{k+1} for positive k, (-1)^{k} for negative k
            // Euler's pentagonal theorem uses sign pattern +, +, -, -, +, +, ...
            let sign = if (k - 1) % 2 == 0 { 1i64 } else { -1i64 };
            
            val += sign * table[i - pent1] as i64;
            
            let pent2 = (k * (3 * k + 1) / 2) as usize;
            if pent2 <= i {
                val += sign * table[i - pent2] as i64;
            }
            
            val = ((val % m as i64) + m as i64) % m as i64;
            k += 1;
        }
        table[i] = val as usize % m_us;
    }
    
    table[n] as u64
}

/// Verify Ramanujan congruence: p(ℓn + δ) ≡ 0 (mod ℓ) for n = 0..limit
pub fn verify_ramanujan(ell: u64, delta: u64, limit: u64) -> (u64, u64, bool) {
    let mut pass = 0u64;
    let mut fail = 0u64;
    
    for n in 0..limit {
        let arg = ell * n + delta;
        let p_mod = partition_mod(arg, ell);
        if p_mod == 0 {
            pass += 1;
        } else {
            fail += 1;
        }
    }
    
    (pass, fail, fail == 0)
}

/// Euler product residue: Π_{p prime, p≤B} 1/(1 - p^{-s}) mod lane_prime
///
/// For integer s, p^{-s} mod lane_prime = (p^s)^{-1} mod lane_prime.
/// The factor 1/(1-p^{-s}) = p^s/(p^s - 1) mod lane_prime.
///
/// This IS the single-oscillator partition function for the p-oscillator
/// at inverse temperature β = s.
pub fn euler_product_residue(s: u64, primes: &[u64], lane_prime: u64) -> u64 {
    let mut product = 1u64;
    
    for &p in primes {
        if p == lane_prime { continue; } // skip self-interaction
        
        // p^s mod lane_prime
        let ps = mod_pow(p, s, lane_prime);
        
        // p^s - 1 mod lane_prime
        let ps_minus_1 = if ps > 0 { ps - 1 } else { lane_prime - 1 };
        if ps_minus_1 == 0 { continue; } // degenerate: p^s ≡ 1
        
        // (p^s - 1)^{-1} mod lane_prime
        let inv = mod_pow(ps_minus_1, lane_prime - 2, lane_prime);
        
        // Factor: p^s / (p^s - 1) = p^s × (p^s - 1)^{-1}
        let factor = mulmod(ps, inv, lane_prime);
        
        product = mulmod(product, factor, lane_prime);
    }
    
    product
}

/// Primon gas energy level: E(n) = Σ_p v_p(n) · E_p
/// where E_p is represented as p's index in the energy ladder.
/// Returns the occupation vector (v_2(n), v_3(n), v_5(n), ...) for basis primes.
pub fn occupation_vector(n: u64, basis: &[u64]) -> Vec<u64> {
    basis.iter().map(|&p| {
        let mut val = n;
        let mut count = 0u64;
        while val > 0 && val % p == 0 {
            val /= p;
            count += 1;
        }
        count
    }).collect()
}

/// The partition chimera: combines partition function, Euler product,
/// and occupation vector into a single CRT residue tuple.
///
/// For each lane prime ℓ:
///   chimera_ℓ = p(n) mod ℓ + Z_ℓ(s) × occupation(n, ℓ) mod ℓ
///
/// This fuses the additive structure (partition function) with the
/// multiplicative structure (Euler product) on each CRT lane.
pub struct PartitionChimera {
    /// p(n) mod each S_R prime
    pub partition_residues: Vec<u64>,
    /// Euler product residue mod each S_R prime
    pub euler_residues: Vec<u64>,
    /// Occupation vector for basis primes
    pub occupation: Vec<u64>,
    /// The fused chimera value mod each S_R prime
    pub chimera_residues: Vec<u64>,
    /// The input value
    pub n: u64,
}

impl PartitionChimera {
    pub fn compute(n: u64, s: u64) -> Self {
        let primes_to_b: Vec<u64> = (2..=n.min(100))
            .filter(|&p| is_prime_small(p))
            .collect();
        
        let partition_residues: Vec<u64> = S_R.iter()
            .map(|&ell| partition_mod(n, ell))
            .collect();
        
        let euler_residues: Vec<u64> = S_R.iter()
            .map(|&ell| euler_product_residue(s, &primes_to_b, ell))
            .collect();
        
        let occupation = occupation_vector(n, &SAFE_BASIS);
        
        // Fused chimera: additive (partition) + multiplicative (Euler) × occupation
        let chimera_residues: Vec<u64> = S_R.iter().enumerate()
            .map(|(i, &ell)| {
                let p_part = partition_residues[i];
                let e_part = euler_residues[i];
                // Occupation energy on this lane
                let occ_energy: u64 = occupation.iter()
                    .enumerate()
                    .map(|(j, &v)| mulmod(v % ell, (j as u64 + 1) % ell, ell))
                    .fold(0, |acc, x| (acc + x) % ell);
                // Chimera: partition + euler × occupation_energy
                let product = mulmod(e_part, occ_energy, ell);
                (p_part + product) % ell
            })
            .collect();
        
        PartitionChimera {
            partition_residues,
            euler_residues,
            occupation,
            chimera_residues,
            n,
        }
    }
    
    /// Does this n satisfy the Ramanujan congruence at ℓ?
    pub fn ramanujan_at(&self, ell_idx: usize) -> bool {
        self.partition_residues[ell_idx] == 0
    }
    
    /// Is this n at a Ramanujan position for ALL S_R primes?
    pub fn is_triple_ramanujan(&self) -> bool {
        self.partition_residues.iter().all(|&r| r == 0)
    }
}

// Helpers
fn mulmod(a: u64, b: u64, m: u64) -> u64 {
    ((a as u128 * b as u128) % m as u128) as u64
}

fn mod_pow(mut base: u64, mut exp: u64, modulus: u64) -> u64 {
    if modulus == 1 { return 0; }
    let mut result = 1u64;
    base %= modulus;
    while exp > 0 {
        if exp & 1 == 1 {
            result = mulmod(result, base, modulus);
        }
        exp >>= 1;
        base = mulmod(base, base, modulus);
    }
    result
}

fn is_prime_small(n: u64) -> bool {
    if n < 2 { return false; }
    if n < 4 { return true; }
    if n % 2 == 0 || n % 3 == 0 { return false; }
    let mut i = 5;
    while i * i <= n {
        if n % i == 0 || n % (i + 2) == 0 { return false; }
        i += 6;
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_partition_small_values() {
        // p(0)=1, p(1)=1, p(2)=2, p(3)=3, p(4)=5, p(5)=7
        let known = [1, 1, 2, 3, 5, 7, 11, 15, 22, 30, 42];
        for (n, &expected) in known.iter().enumerate() {
            // Check mod a large prime to get the actual value
            let computed = partition_mod(n as u64, 10007);
            assert_eq!(computed, expected % 10007,
                "p({}) = {} but got {}", n, expected, computed);
        }
    }

    #[test]
    fn test_ramanujan_mod5() {
        // p(5n+4) ≡ 0 (mod 5) for all n
        // p(4)=5, p(9)=30, p(14)=135, p(19)=490, p(24)=1575
        for n in 0..20 {
            let arg = 5 * n + 4;
            let r = partition_mod(arg, 5);
            assert_eq!(r, 0, "p({}) mod 5 = {} (should be 0)", arg, r);
        }
    }

    #[test]
    fn test_ramanujan_mod7() {
        // p(7n+5) ≡ 0 (mod 7) for all n
        for n in 0..15 {
            let arg = 7 * n + 5;
            let r = partition_mod(arg, 7);
            assert_eq!(r, 0, "p({}) mod 7 = {} (should be 0)", arg, r);
        }
    }

    #[test]
    fn test_ramanujan_mod11() {
        // p(11n+6) ≡ 0 (mod 11) for all n
        for n in 0..10 {
            let arg = 11 * n + 6;
            let r = partition_mod(arg, 11);
            assert_eq!(r, 0, "p({}) mod 11 = {} (should be 0)", arg, r);
        }
    }

    #[test]
    fn test_ramanujan_mod13_fails() {
        // p=13 should NOT have a universal congruence
        let mut any_nonzero = false;
        for delta in 0..13 {
            let mut all_zero = true;
            for n in 0..10 {
                let arg = 13 * n + delta;
                if partition_mod(arg, 13) != 0 {
                    all_zero = false;
                    break;
                }
            }
            if !all_zero { any_nonzero = true; }
        }
        assert!(any_nonzero, "13 should NOT have a universal partition congruence");
    }

    #[test]
    fn test_euler_product_basic() {
        // At s=2: ζ(2) = π²/6. On the CRT torus, the residues should be nonzero.
        for &ell in &S_R {
            let primes: Vec<u64> = (2..=30).filter(|&p| is_prime_small(p)).collect();
            let r = euler_product_residue(2, &primes, ell);
            // Just check it's computed without panic
            assert!(r < ell, "Euler residue should be < lane prime");
        }
    }

    #[test]
    fn test_occupation_vector() {
        // 60 = 2² × 3 × 5
        let occ = occupation_vector(60, &SAFE_BASIS);
        assert_eq!(occ, vec![2, 1, 1, 0, 0, 0]); // v_2=2, v_3=1, v_5=1, rest=0
    }

    #[test]
    fn test_occupation_prime() {
        // 7 = 7¹
        let occ = occupation_vector(7, &SAFE_BASIS);
        assert_eq!(occ, vec![0, 0, 0, 1, 0, 0]); // only v_7=1
    }

    #[test]
    fn test_chimera_at_ramanujan_point() {
        // n = 4: p(4) = 5 ≡ 0 mod 5
        let ch = PartitionChimera::compute(4, 2);
        assert!(ch.ramanujan_at(0), "p(4) should be 0 mod 5");
    }

    #[test]
    fn test_chimera_at_non_ramanujan() {
        // n = 3: p(3) = 3, not 0 mod 5
        let ch = PartitionChimera::compute(3, 2);
        assert!(!ch.ramanujan_at(0), "p(3) = 3 should not be 0 mod 5");
    }

    #[test]
    fn test_verify_ramanujan_batch() {
        for &(ell, delta) in &RAMANUJAN_OFFSETS {
            let (pass, fail, all_pass) = verify_ramanujan(ell, delta, 20);
            assert!(all_pass,
                "Ramanujan congruence p({}n+{}) mod {} failed: {}/{} pass",
                ell, delta, ell, pass, pass + fail);
        }
    }

    #[test]
    fn test_euler_product_self_consistency() {
        // The Euler product at s=1 diverges (ζ(1) = ∞),
        // but mod a prime it should still compute a residue.
        let primes: Vec<u64> = (2..=20).filter(|&p| is_prime_small(p)).collect();
        let r5 = euler_product_residue(1, &primes, 5);
        let r7 = euler_product_residue(1, &primes, 7);
        // These should be nonzero (ζ mod p is typically nonzero)
        // Just verify computation completes
        assert!(r5 < 5);
        assert!(r7 < 7);
    }

    #[test]
    fn test_primon_energy_prime() {
        // A prime p has occupation (0,...,0,1,0,...,0) at position p
        // Energy = 1 × index_of_p
        let occ = occupation_vector(11, &SAFE_BASIS);
        let energy: u64 = occ.iter().enumerate()
            .map(|(i, &v)| v * (i as u64 + 1))
            .sum();
        // 11 is at index 4 in SAFE_BASIS, so energy = 1 × 5 = 5
        assert_eq!(energy, 5, "Primon energy of 11 should be 5 (index+1)");
    }

    #[test]
    fn test_primon_energy_composite() {
        // 30 = 2 × 3 × 5, occupation = (1,1,1,0,0,0)
        // Energy = 1×1 + 1×2 + 1×3 = 6
        let occ = occupation_vector(30, &SAFE_BASIS);
        assert_eq!(occ, vec![1, 1, 1, 0, 0, 0]);
        let energy: u64 = occ.iter().enumerate()
            .map(|(i, &v)| v * (i as u64 + 1))
            .sum();
        assert_eq!(energy, 6);
    }
}
