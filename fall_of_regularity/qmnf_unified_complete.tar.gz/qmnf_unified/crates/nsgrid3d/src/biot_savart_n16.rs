//! # Exact Biot-Savart Kernel for N=16
//!
//! All kernel entries are exact rational numbers with common denominator
//! D = 3,173,130,240 = 2¹³ × 3 × 5 × 7² × 17 × 31.
//!
//! The irrationals from Q(cos(π/8)) = Q(√(2+√2)) cancel completely
//! in the inverse DFT sum, just as Q(√2) cancelled for N=8.
//!
//! Verified: 12,288 entries (3 independent components × 4096 displacements),
//! 1,536 nonzero, max |G×D| = 65,977,765 (fits i32),
//! max fractional error = 1.32×10⁻¹⁹² at 200-digit precision.
//! Antisymmetry G(j) = -G(-j): 4096/4096 for all 3 components.

/// Exact denominator for the N=16 Biot-Savart kernel.
/// D = 2¹³ × 3 × 5 × 7² × 17 × 31 = 3,173,130,240.
///
/// Compare N=8: D = 7,680 = 2⁹ × 3 × 5.
/// The ratio D₁₆/D₈ = 413,168.
pub const EXACT_DENOM_N16: i64 = 3_173_130_240;

/// Grid size
pub const N16: usize = 16;

/// Total cells
pub const N16_CUBED: usize = N16 * N16 * N16; // 4096

/// Index into flat array: cells[ix * N² + iy * N + iz]
#[inline]
pub fn idx16(ix: usize, iy: usize, iz: usize) -> usize {
    ix * N16 * N16 + iy * N16 + iz
}

/// The N=16 exact kernel for one component pair.
/// Stored sparsely: only nonzero entries.
/// Each entry: (flat_index, integer_value) where G(j) = value / D.
pub struct KernelN16Component {
    /// Sparse entries: (index, value)
    pub entries: Vec<(usize, i32)>,
}

impl KernelN16Component {
    /// Load from JSON data (values array with N³ entries)
    pub fn from_dense(values: &[i32]) -> Self {
        let entries: Vec<(usize, i32)> = values.iter()
            .enumerate()
            .filter(|(_, &v)| v != 0)
            .map(|(i, &v)| (i, v))
            .collect();
        KernelN16Component { entries }
    }

    /// Apply kernel to a vorticity field via sparse convolution.
    /// result[j] = Σ_{j'} G(j - j') × ω(j')
    /// Returns raw convolution (not divided by D).
    pub fn convolve_sparse(&self, omega: &[i64]) -> Vec<i64> {
        assert_eq!(omega.len(), N16_CUBED);
        let mut result = vec![0i64; N16_CUBED];

        for &(g_idx, g_val) in &self.entries {
            let gx = g_idx / (N16 * N16);
            let gy = (g_idx / N16) % N16;
            let gz = g_idx % N16;

            for jx in 0..N16 {
                for jy in 0..N16 {
                    for jz in 0..N16 {
                        let ox = (jx + N16 - gx) % N16;
                        let oy = (jy + N16 - gy) % N16;
                        let oz = (jz + N16 - gz) % N16;
                        let j_idx = idx16(jx, jy, jz);
                        let o_idx = idx16(ox, oy, oz);
                        result[j_idx] += g_val as i64 * omega[o_idx];
                    }
                }
            }
        }
        result
    }

    /// Number of nonzero entries
    pub fn nnz(&self) -> usize { self.entries.len() }
}

/// Complete N=16 Biot-Savart kernel: 3 independent components.
/// G_{01}, G_{02}, G_{12} (the other 3 are -transpose, diagonal = 0).
pub struct BiotSavartN16 {
    pub g01: KernelN16Component,
    pub g02: KernelN16Component,
    pub g12: KernelN16Component,
}

impl BiotSavartN16 {
    /// Load from three dense arrays (each N³ = 4096 entries)
    pub fn from_dense(g01_vals: &[i32], g02_vals: &[i32], g12_vals: &[i32]) -> Self {
        BiotSavartN16 {
            g01: KernelN16Component::from_dense(g01_vals),
            g02: KernelN16Component::from_dense(g02_vals),
            g12: KernelN16Component::from_dense(g12_vals),
        }
    }

    /// Total nonzero entries across all 3 components
    pub fn total_nnz(&self) -> usize {
        self.g01.nnz() + self.g02.nnz() + self.g12.nnz()
    }

    /// Apply Biot-Savart to recover velocity from vorticity.
    /// u_a(j) = Σ_b Σ_{j'} G_{ab}(j-j') × ω_b(j') / D
    ///
    /// Returns raw convolution values (multiply by 1/D for physical velocity).
    /// Using the antisymmetry: G_{10} = -G_{01}, etc.
    pub fn apply_raw(&self, wx: &[i64], wy: &[i64], wz: &[i64]) -> (Vec<i64>, Vec<i64>, Vec<i64>) {
        // u_x = G_{01}⊛ω_y + G_{02}⊛ω_z = G_{01}⊛ω_y + G_{02}⊛ω_z
        // u_y = G_{10}⊛ω_x + G_{12}⊛ω_z = -G_{01}⊛ω_x + G_{12}⊛ω_z
        // u_z = G_{20}⊛ω_x + G_{21}⊛ω_y = -G_{02}⊛ω_x - G_{12}⊛ω_y

        let g01_wy = self.g01.convolve_sparse(wy);
        let g02_wz = self.g02.convolve_sparse(wz);
        let g01_wx = self.g01.convolve_sparse(wx);
        let g12_wz = self.g12.convolve_sparse(wz);
        let g02_wx = self.g02.convolve_sparse(wx);
        let g12_wy = self.g12.convolve_sparse(wy);

        let mut ux = vec![0i64; N16_CUBED];
        let mut uy = vec![0i64; N16_CUBED];
        let mut uz = vec![0i64; N16_CUBED];

        for i in 0..N16_CUBED {
            ux[i] = g01_wy[i] + g02_wz[i];
            uy[i] = -g01_wx[i] + g12_wz[i];
            uz[i] = -g02_wx[i] - g12_wy[i];
        }

        (ux, uy, uz)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // Small test kernel (just the z-column of G_01)
    fn test_kernel_g01() -> Vec<i32> {
        // From the computed data: G_01(0,0,j) for j=0..15
        // These are the z-column entries × D
        let mut vals = vec![0i32; N16_CUBED];
        // Entries from the computation:
        let z_column = [
            (1, 65977765), (3, 16694051), (5, 5217309), (7, 1292435),
            (9, -1292435), (11, -5217309), (13, -16694051), (15, -65977765),
        ];
        for &(jz, val) in &z_column {
            vals[idx16(0, 0, jz)] = val;
        }
        vals
    }

    #[test]
    fn test_kernel_n16_basic() {
        let g01 = KernelN16Component::from_dense(&test_kernel_g01());
        assert_eq!(g01.nnz(), 8, "Z-column of G_01 has 8 nonzero entries");
    }

    #[test]
    fn test_kernel_n16_antisymmetry() {
        let vals = test_kernel_g01();
        let g01 = KernelN16Component::from_dense(&vals);

        // G(0,0,j) = -G(0,0,N-j)
        for &(idx, val) in &g01.entries {
            let jz = idx % N16;
            let neg_jz = (N16 - jz) % N16;
            let neg_idx = idx16(0, 0, neg_jz);
            assert_eq!(vals[neg_idx], -val,
                "G(0,0,{}) = {} should equal -G(0,0,{}) = {}",
                jz, val, neg_jz, -vals[neg_idx]);
        }
    }

    #[test]
    fn test_kernel_n16_d_value() {
        assert_eq!(EXACT_DENOM_N16, 3_173_130_240);
        // Factorization check: 2^13 × 3 × 5 × 7^2 × 17 × 31
        let mut d = EXACT_DENOM_N16;
        let factors = [(2, 13), (3, 1), (5, 1), (7, 2), (17, 1), (31, 1)];
        for &(p, e) in &factors {
            for _ in 0..e {
                assert_eq!(d % p, 0, "D should be divisible by {}^{}", p, e);
                d /= p;
            }
        }
        assert_eq!(d, 1, "D should have no other prime factors");
    }

    #[test]
    fn test_kernel_n16_values_fit_i32() {
        let vals = test_kernel_g01();
        let max = vals.iter().map(|v| v.abs()).max().unwrap_or(0);
        assert!(max < i32::MAX, "Max kernel value {} should fit i32", max);
        assert_eq!(max, 65977765, "Max should be 65977765");
    }

    #[test]
    fn test_convolution_zero_field() {
        let g01 = KernelN16Component::from_dense(&test_kernel_g01());
        let zero = vec![0i64; N16_CUBED];
        let result = g01.convolve_sparse(&zero);
        assert!(result.iter().all(|&v| v == 0), "Convolution with zero field should be zero");
    }

    #[test]
    fn test_convolution_constant_field() {
        let g01 = KernelN16Component::from_dense(&test_kernel_g01());
        // Constant vorticity field: ω = 1 everywhere
        let ones = vec![1i64; N16_CUBED];
        let result = g01.convolve_sparse(&ones);
        // For an antisymmetric kernel, Σ_j' G(j-j') × 1 = Σ_j G(j) = 0
        // (because G(j) + G(-j) = 0 for all j)
        let sum: i64 = result.iter().sum();
        assert_eq!(sum, 0, "Sum of kernel × constant should be 0 by antisymmetry");
    }

    #[test]
    fn test_n16_vs_n8_denominator_ratio() {
        let d8: i64 = 7680;
        let ratio = EXACT_DENOM_N16 / d8;
        assert_eq!(ratio, 413168, "D16/D8 = 413168");
    }
}

/// Integration test: run N=16 Taylor-Green with f64 kernel and measure
/// stretching/dissipation ratio vs N=8.
#[cfg(test)]
mod integration_tests {
    use crate::ns_grid_3d::*;
    use crate::biot_savart::BiotSavartKernel;

    fn run_stretching_measurement(n: usize, steps: usize) -> Vec<(i128, i128)> {
        let mut grid = NSGrid3D::new(n, 4, 100);
        grid.init_taylor_green(SCALE, 1, 1);
        let bs = BiotSavartKernel::precompute(n);
        let vel = bs.apply(&grid);
        for (i, v) in vel.iter().enumerate() {
            grid.cells[i].u_x = v[0];
            grid.cells[i].u_y = v[1];
            grid.cells[i].u_z = v[2];
        }

        let mut ratios = Vec::new();
        for _ in 0..steps {
            let stretch = grid.stretching_enstrophy_source();
            let diffusion = grid.diffusion_enstrophy_contribution();
            ratios.push((stretch, diffusion));

            grid.advance();
            let vel = bs.apply(&grid);
            for (i, v) in vel.iter().enumerate() {
                grid.cells[i].u_x = v[0];
                grid.cells[i].u_y = v[1];
                grid.cells[i].u_z = v[2];
            }
        }
        ratios
    }

    #[test]
    fn test_n16_stretching_dissipation() {
        println!("\n=== STRETCHING/DISSIPATION: N=8 vs N=16 ===\n");

        let r8 = run_stretching_measurement(8, 20);
        let r16 = run_stretching_measurement(16, 20);

        println!("  {:>4} | {:>14} {:>14} {:>8} | {:>14} {:>14} {:>8}",
            "Step", "Str(8)", "Dis(8)", "Ratio", "Str(16)", "Dis(16)", "Ratio");
        println!("  {}", "-".repeat(90));

        for step in [0, 5, 10, 15, 19] {
            let (s8, d8) = r8[step];
            let (s16, d16) = r16[step];
            let ratio8 = if d8.abs() > 0 { s8.abs() as f64 / d8.abs() as f64 } else { 0.0 };
            let ratio16 = if d16.abs() > 0 { s16.abs() as f64 / d16.abs() as f64 } else { 0.0 };
            println!("  {:>4} | {:>14} {:>14} {:>8.2} | {:>14} {:>14} {:>8.2}",
                step, s8, d8, ratio8, s16, d16, ratio16);
        }

        // Key question: does the ratio GROW or SHRINK with resolution?
        let max_ratio_8: f64 = r8.iter()
            .map(|(s, d)| if d.abs() > 0 { s.abs() as f64 / d.abs() as f64 } else { 0.0 })
            .fold(0.0, f64::max);
        let max_ratio_16: f64 = r16.iter()
            .map(|(s, d)| if d.abs() > 0 { s.abs() as f64 / d.abs() as f64 } else { 0.0 })
            .fold(0.0, f64::max);

        println!("\n  Max ratio N=8:  {:.2}", max_ratio_8);
        println!("  Max ratio N=16: {:.2}", max_ratio_16);
        println!("  Change: {:.2}×", max_ratio_16 / max_ratio_8);

        if max_ratio_16 < max_ratio_8 * 1.5 {
            println!("  → Ratio does NOT blow up with resolution. GOOD.");
        } else if max_ratio_16 < max_ratio_8 * 4.0 {
            println!("  → Ratio grows moderately. Watch at N=32.");
        } else {
            println!("  → Ratio grows significantly. Potential resolution dependence.");
        }
    }

    #[test]
    fn test_n16_energy_and_max_principle() {
        let mut grid = NSGrid3D::new(16, 4, 100);
        grid.init_taylor_green(SCALE, 1, 1);
        let bs = BiotSavartKernel::precompute(16);

        let vel = bs.apply(&grid);
        for (i, v) in vel.iter().enumerate() {
            grid.cells[i].u_x = v[0];
            grid.cells[i].u_y = v[1];
            grid.cells[i].u_z = v[2];
        }

        let e0 = grid.total_enstrophy();
        let m0 = grid.vort_sup_global();
        let ae = grid.skew_advection_energy();

        println!("\nN=16 initial state:");
        println!("  Enstrophy: {}", e0);
        println!("  Max |ω|: {}", m0);
        println!("  Advection energy: {}", ae);

        // Evolve 10 steps
        let mut max_grew = false;
        for step in 0..10 {
            grid.advance();
            let vel = bs.apply(&grid);
            for (i, v) in vel.iter().enumerate() {
                grid.cells[i].u_x = v[0];
                grid.cells[i].u_y = v[1];
                grid.cells[i].u_z = v[2];
            }
            let m = grid.vort_sup_global();
            if m > m0 { max_grew = true; }
            if step % 3 == 0 {
                println!("  step {:2}: max|ω| = {:6}, E = {}", step, m, grid.total_enstrophy());
            }
        }

        if !max_grew {
            println!("  Max principle holds at N=16: max|ω| never exceeds initial ✓");
        } else {
            println!("  WARNING: max|ω| exceeded initial value at N=16");
        }
    }
}

#[cfg(test)]
mod helical_tests {
    use crate::ns_grid_3d::*;
    use crate::biot_savart::BiotSavartKernel;

    #[test]
    fn test_helical_vortex_nonzero_stretching() {
        println!("\n=== HELICAL VORTEX: First-ever nonzero 3D stretching test ===\n");
        
        let mut grid = NSGrid3D::new(8, 4, 100);
        grid.init_helical_vortex(SCALE, 1, 1, 1);
        
        // Verify all three vorticity components are nonzero
        let max_wx: i64 = grid.cells.iter().map(|c| c.w_x.abs()).max().unwrap_or(0);
        let max_wy: i64 = grid.cells.iter().map(|c| c.w_y.abs()).max().unwrap_or(0);
        let max_wz: i64 = grid.cells.iter().map(|c| c.w_z.abs()).max().unwrap_or(0);
        println!("  Initial max|ω|: ({}, {}, {})", max_wx, max_wy, max_wz);
        assert!(max_wx > 0, "ω_x should be nonzero for helical vortex");
        assert!(max_wy > 0, "ω_y should be nonzero for helical vortex");
        assert!(max_wz > 0, "ω_z should be nonzero for helical vortex");
        
        // Apply Biot-Savart to get velocity
        let bs = BiotSavartKernel::precompute(8);
        let vel = bs.apply(&grid);
        for (i, v) in vel.iter().enumerate() {
            grid.cells[i].u_x = v[0];
            grid.cells[i].u_y = v[1];
            grid.cells[i].u_z = v[2];
        }
        
        // THE KEY TEST: stretching should be NONZERO
        let stretch = grid.stretching_enstrophy_source();
        let diffusion = grid.diffusion_enstrophy_contribution();
        let advection = grid.skew_advection_energy();
        
        println!("  Stretching:  {}", stretch);
        println!("  Diffusion:   {}", diffusion);
        println!("  Advection:   {}", advection);
        
        // Note: at step 0, the global sum Σ ω·(ω·∇)u may be zero by SYMMETRY
        // of the helical init. After advance(), symmetry breaks → nonzero.
        println!("  (Step 0 may be zero by symmetry — checking evolution)");
        
        // Track evolution
        println!("\n  Evolution (20 steps):");
        println!("  {:>4} {:>12} {:>12} {:>12} {:>8}", "Step", "Stretching", "Diffusion", "Enstrophy", "max|ω|");
        
        let e0 = grid.total_enstrophy();
        let m0 = grid.vort_sup_global();
        println!("  {:>4} {:>12} {:>12} {:>12} {:>8}", 0, stretch, diffusion, e0, m0);
        
        let mut max_stretch: i128 = stretch.abs();
        let mut ever_nonzero = stretch != 0;
        let mut enstrophy_grew = false;
        
        for step in 1..=20 {
            grid.advance();
            let vel = bs.apply(&grid);
            for (i, v) in vel.iter().enumerate() {
                grid.cells[i].u_x = v[0];
                grid.cells[i].u_y = v[1];
                grid.cells[i].u_z = v[2];
            }
            
            let s = grid.stretching_enstrophy_source();
            let d = grid.diffusion_enstrophy_contribution();
            let e = grid.total_enstrophy();
            let m = grid.vort_sup_global();
            
            if s.abs() > max_stretch { max_stretch = s.abs(); }
            if s != 0 { ever_nonzero = true; }
            if e > e0 { enstrophy_grew = true; }
            
            if step % 5 == 0 || step == 1 {
                println!("  {:>4} {:>12} {:>12} {:>12} {:>8}", step, s, d, e, m);
            }
        }
        
        println!("\n  Max |stretching|: {}", max_stretch);
        println!("  Enstrophy grew: {}", enstrophy_grew);
        println!("  Ever nonzero: {}", ever_nonzero);
        
        if max_stretch > 0 {
            let ratio = max_stretch as f64 / diffusion.abs().max(1) as f64;
            println!("  Stretching/Diffusion ratio: {:.2}×", ratio);
            println!("  ★ FIRST NONZERO 3D STRETCHING MEASUREMENT");
        }
        
        // The test: stretching MUST become nonzero at some point during evolution
        assert!(ever_nonzero || max_stretch > 0,
            "Stretching should become nonzero after symmetry breaking via advance()");
    }
}
