# ACTIVE_PATH.md

## Current active closure path

Only these workstreams are active:
1. 3D exact solver path
2. Exact 3D operator family / Biot-Savart consistency
3. Continuum bridge (compactness + nonlinear passage)
4. Uniform 3D return/excursion control
5. BKM only at the end as corollary

## Archived / regression-only
- 1D proxy overshoot studies
- 1D return-to-corridor evidence
- float eradication work already completed
- recumbent/WASSAN plumbing work already completed

## API hygiene
- `cram_ns` is test-only archived regression code.
- `archived_measure_overshoot_1d`, `archived_recumbent_ns_step`, and `archived_recumbent_overshoot` are test-only.
- Active public modules are `recumbent` and `wassan` plus the theorem-bearing core in `src/lib.rs`.


## Agent start-here
- Start in `src/lib.rs`, `src/recumbent.rs`, and `src/wassan.rs`.
- Treat `src/cram_ns.rs` as archived regression only.
- Do not open theorem work by default with any symbol prefixed `archived_`.
