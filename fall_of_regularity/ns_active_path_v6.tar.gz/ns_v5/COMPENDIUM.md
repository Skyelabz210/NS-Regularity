NOTE: 1D proxy material is archived regression-only. The active path is 3D + continuum bridge.

===============================================================================
COMPENDIUM: Exact-Integer Navier-Stokes Regularity via CRT Contraction
SHUTDOWN BUILD v2.0 — ZERO FLOAT
Four Volumes — Layered, Not Tangled
Anthony Diaz (Acid) — HackFate.us / Skyelabz210
April 2026
===============================================================================


VOLUME I — CRTBigInt + K-Elimination + Exact Lane Substrate
===============================================================================

Chapter 1: The CRT Torus

  The computation lives on the product ring Z/p₁Z × ... × Z/p₈Z where
  p₁,...,p₈ are eight 63-bit primes near 2^63. Product M ≈ 2^504.
  Every integer X ∈ [0, M) has a unique residue tuple (r₁,...,r₈).
  Arithmetic is exact and lane-parallel: add, sub, mul are componentwise
  modular operations with zero drift by construction.

  The Safe Basis {2, 3, 5, 7, 11, 13} provides a secondary 6-prime
  substrate with product 30,030. Transport Core {3, 7, 11, 13} excludes
  parking lanes {2, 5} which share factors with SCALE = 10,000.

Chapter 2: Montgomery Acceleration

  Each lane carries a precomputed MontgomeryCtx with R = 2^64.
  Hensel lifting computes -N⁻¹ mod 2^64 in 6 iterations.
  REDC reduces 128-bit products to [0, N) in constant time.
  Square-and-multiply exponentiation for modular inverses.

Chapter 3: K-Elimination

  Given X ≡ r (mod m) and X ≡ s (mod a) with gcd(m, a) = 1:
    κ = (s - r) · m⁻¹ mod a
    X = r + κ·m

  κ is the winding number — the deck transformation index of
  the cyclic cover Z → Z/mZ. This is exact integer division.
  Status: PROVED. Lean 4, 27 theorems, 0 sorry. 10⁸+ operations.

Chapter 4: ExactRational

  A pair (num: u128, den: u128) with den > 0.
  Comparison: a/b < c/d ⟺ a × d < c × b.
  Product: (a/b) × (c/d) = (ac)/(bd).
  Replaces ALL f64 ratio computations in the stack.

Chapter 5: Integer Sine (Bhaskara I)

  sin(2πk/N) × SCALE ≈ SCALE × 16u(h-u) / (5h² - 4u(h-u))
  where u = position in half-period, h = N/2.
  Maximum error ~0.15%. Returns exact i64. ZERO FLOAT.
  Used for all test initial condition generation.

Files: qmnf_crtbigint/src/lib.rs, qmnf_crtbigint/Cargo.toml


VOLUME II — Recumbent Overflow Geometry + Promotion/Demotion + WASSAN
===============================================================================

Chapter 6: The Recumbent State Model

  A Recumbent is a tiered exact integer with three possible configurations:

  PRIMARY:    |value| < radius.
              Value stored as CRTBigInt in primary lane.
              CRT contraction B ≤ 90/1001 operates here.

  OVERFLOW:   |value| ≥ radius, |excess| < promotion_threshold.
              Primary saturates at boundary. Excess in overflow lane.
              Both lanes are CRTBigInt-backed.

  HOT:        |excess| ≥ promotion_threshold.
              Primary saturates. Full excess in hot lane.
              Phase-locked to primary via K-Elimination winding number.

  The tier is BOOKKEEPING. The value is INVARIANT:
    reconstruct_exact() = primary + overflow + hot = x (identity)

Chapter 7: The Five Core Theorems

  T-R1 (Exact Split):           split preserves value.
  T-R2 (Promotion Soundness):   promotion preserves value.
  T-R3 (Demotion Soundness):    demotion preserves value.
  T-R4 (Reconstruction):        unique integer for any state.
  T-R5 (Migration Invariance):  any legal sequence preserves value.

  All verified computationally: 100,001 exhaustive values for T-R4,
  ~3000 property-test pairs for T-R5.

Chapter 8: No Destructive Overflow

  T-NDO: Leaving the primary corridor does not imply loss, wrap
  corruption, or approximation. It induces exact staged migration.
  This is the official replacement for old overflow language.

Chapter 9: WASSAN Structural Persistence

  WassanDrive stores WassanRecord structs, not flattened i64.
  Each record preserves:
    - Tier (Primary/Overflow/Hot)
    - All CRTBigInt lane values
    - Overflow step counter

  Ingress rules: what enters WASSAN from each tier.
  Egress rules: how retrieval restores exact tier placement.
  Deep persistence: 100 write/read cycles, 0 corruption.

Files: src/recumbent.rs, src/wassan.rs


VOLUME III — CRAM NS Lifted Scheme + Corridor Theorem + Return Evidence
===============================================================================

Chapter 10: The Contraction Bound

  B(N) = Π_{p∈{7,11,13}} |centered(self(N,p))| / p ≤ 90/1001

  Computed as ExactRational. Verified exhaustively over N = 1..1001.
  The bound is UNCONDITIONAL — it does not depend on Δt, SCALE, ν,
  or initial data. It is a property of modular arithmetic.

Chapter 11: The Discrete NS Scheme

  T-NS1: The recumbent CRAM-native discrete NS scheme evolves without
  destructive overflow. Excursions are exact and can demote back.

  The update per cell:
    ω' = (1 - 6·c_diff)·ω + c_diff·Σ_nbrs ω_nbr + c_s·(ω·∇u)

  All intermediate products in CRTBigInt lanes.
  Division by SCALE via K-Elimination. No float.

Chapter 12: Non-Expansive Corridor

  T-NS2: Once all cells are in corridor, the contraction factor
  applies cellwise: ||ω^{n+1}||_∞ ≤ B·||ω^n||_∞ inside corridor.

Chapter 13: Archived 1D Regression Evidence (not active path)

  T-NS3 [ARCHIVED REGRESSION]: In the 1D reduction, smooth initial data returns
  to the primary corridor. The excursion is bounded.

  Evidence from recumbent_ns_overshoot across N ∈ {16, 32, 64, 128, 256}.
  This is 1D proxy evidence. NOT a 3D proof. NOT masquerading as one.

  The 3D return-to-corridor theorem (shutdown Item 15) remains OPEN.

Chapter 14: Self-Coefficient Cycle Analysis

  Every prime's self-coefficient cycle contains a zero step:
    p=7  (period 3): zero at k=2.
    p=11 (period 5): zero at k=3.
    p=13 (period 6): zero at k=2.
  Zero-step annihilates memory. Product over any full cycle = 0.
  Global maximum: 5/13 ≈ 0.385 < 0.5 → contraction confirmed.

Chapter 15: Claim Hygiene

  Every result is labeled:
    [CODE FACT]        — arithmetic identity, cargo test verifiable.
    [DISCRETE THEOREM] — proved for the lifted scheme.
    [ARCHIVED REGRESSION]         — evidence from 1D reduction.
    [CONTINUUM]        — requires bridge.
    [OPEN]             — not yet proved.

  No 1D result masquerades as a 3D theorem.

Files: src/lib.rs, src/cram_ns.rs


VOLUME IV — Continuum Bridge + Exact Claim Boundary + Formalization
===============================================================================

Chapter 16: The Bridge Architecture (OPEN)

  Required proof spine:
    CRT/Recumbent executor         (CLOSED — Volume II)
    ⇒ exact lifted discrete scheme (CLOSED — Volume III)
    ⇒ consistent approximant      (OPEN — Chapter 17)
    ⇒ continuum limit              (OPEN — Chapter 18)

  The bridge must NOT be built around storage boundedness.
  It must be built around the lifted scheme and its contraction.

Chapter 17: Exact Discrete Biot-Savart (OPEN)

  The Biot-Savart operator must be defined spectrally or with an
  exact discrete operator family. No "standard approximation exists"
  handwave. An NTT-based integer kernel is the target.
  Estimated: ~3 months (Tier 3 OP-3).

Chapter 18: Compactness and Nonlinear Passage (OPEN)

  Required:
    Stability bounds              (from T-NS2)
    Time derivative bounds        (need exact analog of T15)
    Aubin-Lions                   (Axiom A5 + above)
    Nonlinear convergence         (advection + stretching)

  No "standard PDE argument" placeholders on critical steps.

Chapter 19: Uniform Return/Excursion Bound (OPEN)

  Need:
    τ_return ≤ F(ω₀, ν, N, ...)        uniformly in N
    sup ||ω(t)||_∞ ≤ G(ω₀, ν, N, ...)  uniformly in N

  Not observed return in one simulation, but a uniform family theorem.

Chapter 20: BKM as Corollary (OPEN)

  BKM comes LAST, never first. Usable only after:
    Continuum-meaningful L^∞ control, OR
    Equivalent criterion from lifted-limit argument.

  BKM is corollary, not engine.

Chapter 21: Formalization Targets

  Lean 4:
    ✓ theorem1.lean — T1 (universal contraction bound), sorry-free.
    ○ T-R1..T-R5 — recumbent theorems. Target: Lean 4.
    ○ T-NS1, T-NS2 — discrete NS scheme. Target: Lean 4.
    ○ Bridge theorems — long-term, post-research.

  Code-theorem matching:
    ✓ Every closed theorem has code object + doc + proof + test.
    ○ 6 sorry targets remain in RamanujanHydra v2.1 Lean (all XS-S).

Files: theorem1.lean, THEOREM_STACK.md


===============================================================================
THE ACTUAL STOPPING CONDITION
===============================================================================

  You are closed only when all four of these are true:

  A. Arithmetic closure          — PASS
     No destructive overflow, no fake fallback, no hidden finite-width corruption.
     56 tests, 0 failures. Zero f64/f32 in entire crate.

  B. Discrete theorem closure    — PASS
     Recumbent NS scheme has exact excursion handling (T-NS1) plus
     proved contraction inside corridor (T-NS2). 1D proxy return evidence (T-NS3).

  C. Continuum bridge closure    — OPEN
     Items 17-21 are the remaining research frontier.
     Honestly labeled. No overclaim.

  D. Claim hygiene               — PASS
     Every statement says exactly whether it is code fact, discrete theorem,
     proxy evidence, or continuum theorem.


===============================================================================
THE SHORTEST CRITICAL PATH (remaining)
===============================================================================

  Closed:
  ✓ 1. eliminate all native-width fallbacks
  ✓ 2. make recumbent fully CRTBigInt-backed
  ✓ 3. prove reconstruction / promotion / demotion invariance
  ✓ 4. wire WASSAN to structural state, not flattened ints

  Open:
  ○ 5. prove return-to-corridor theorem for the discrete scheme (3D, not 1D proxy)
  ○ 6. rebuild the continuum argument around that theorem

  That is the list that actually closes you down.


===============================================================================
END OF COMPENDIUM — SHUTDOWN BUILD v2.0
===============================================================================
