//! Configuration Validation Suite
//!
//! Audits EVERY constant, cross-module reference, and mathematical identity
//! across the entire NS regularity workspace. This module is the "type checker"
//! for the mathematical content — it verifies that:
//!
//! 1. NTT primes satisfy all required properties (≡1 mod N, > |k|²_max, primitive roots correct)
//! 2. Garner constants are genuine modular inverses
//! 3. NTT matrix entries match omega powers
//! 4. N_INV_3D values are correct N^{-3} mod p
//! 5. Imaginary units satisfy i² ≡ -1 (mod p)
//! 6. NTT modulus equals product of primes
//! 7. Sobolev constants are self-consistent
//! 8. Contraction bound numerator < denominator
//! 9. CFL formula is consistent with NS_SCALE and N
//! 10. √2 mod p values are correct square roots
//! 11. Stencil denominator D₈ divides all required quantities
//! 12. N=16 constants are consistent with N=8 structure
//! 13. BS normalization factors are consistent across modules
//! 14. No float contamination in any constant
//!
//! Every test is a pure arithmetic assertion. Zero tolerances. Zero float.

// ============================================================================
// SECTION 1: N=8 NTT PRIME VALIDATION
// ============================================================================

#[cfg(test)]
mod n8_ntt_validation {
    use crate::ns3d::*;

    /// Every NTT prime must be congruent to 1 mod N (for N-th root of unity).
    /// For N=8: p ≡ 1 (mod 8). The 2N condition is for 2N-th root (stronger).
    #[test]
    fn primes_congruence() {
        for &p in &NTT_PRIMES {
            assert_eq!(p % (N as u64), 1,
                "Prime {} is not ≡ 1 (mod {})", p, N);
        }
    }

    /// Every NTT prime must exceed |k|²_max for exact BS division.
    /// |k|²_max = 3 × (N/2)² = 3 × 16 = 48 for N=8.
    #[test]
    fn primes_exceed_ksq_max() {
        let ksq_max = 3 * (N / 2) * (N / 2); // 48
        for &p in &NTT_PRIMES {
            assert!(p > ksq_max as u64,
                "Prime {} ≤ |k|²_max = {}", p, ksq_max);
        }
    }

    /// All four primes must be actually prime.
    #[test]
    fn primes_are_prime() {
        for &p in &NTT_PRIMES {
            let mut is_prime = true;
            for d in 2..=(p as f64).sqrt() as u64 {
                if p % d == 0 { is_prime = false; break; }
            }
            assert!(is_prime, "{} is not prime", p);
        }
    }

    /// NTT_MODULUS must equal the product of all four primes.
    #[test]
    fn modulus_is_product() {
        let product: u64 = NTT_PRIMES.iter().product();
        assert_eq!(NTT_MODULUS, product,
            "NTT_MODULUS ({}) ≠ product of primes ({})", NTT_MODULUS, product);
        assert_eq!(NTT_MODULUS, 71_213_617, "NTT_MODULUS hardcoded value wrong");
    }

    /// Each NTT root must be a primitive N-th root of unity mod p.
    /// That means: omega^N ≡ 1 AND omega^(N/2) ≡ -1 (mod p).
    #[test]
    fn roots_are_primitive() {
        for pi in 0..4 {
            let p = NTT_PRIMES[pi];
            let omega = NTT_ROOTS[pi];

            let omega_n = modpow(omega, N as u64, p);
            assert_eq!(omega_n, 1,
                "ω^N ≠ 1 for p={}: got {}", p, omega_n);

            let omega_half = modpow(omega, (N / 2) as u64, p);
            assert_eq!(omega_half, p - 1,
                "ω^(N/2) ≠ -1 for p={}: got {} (expected {})", p, omega_half, p - 1);

            // Also verify omega^(N/4) ≠ ±1 (ensures order is exactly N, not N/2)
            let omega_quarter = modpow(omega, (N / 4) as u64, p);
            assert!(omega_quarter != 1 && omega_quarter != p - 1,
                "ω has order N/2 or less for p={}", p);
        }
    }

    /// Each imaginary unit must satisfy i² ≡ -1 (mod p).
    #[test]
    fn imaginary_units_correct() {
        for pi in 0..4 {
            let p = NTT_PRIMES[pi];
            let i_p = I_MOD[pi];
            let i_sq = mulmod(i_p, i_p, p);
            assert_eq!(i_sq, p - 1,
                "i² ≠ -1 for p={}: i={}, i²={}", p, i_p, i_sq);
        }
    }

    /// N_INV_3D must be the modular inverse of N³ for each prime.
    #[test]
    fn n_inv_3d_correct() {
        let n3 = (N * N * N) as u64; // 512
        for pi in 0..4 {
            let p = NTT_PRIMES[pi];
            let inv = N_INV_3D[pi];
            let product = mulmod(n3 % p, inv, p);
            assert_eq!(product, 1,
                "N^3 × N_INV_3D ≠ 1 for p={}: {} × {} = {} (mod {})",
                p, n3, inv, product, p);
        }
    }

    /// Garner constants must be genuine modular inverses.
    /// P1_INV_P2 = 73^{-1} mod 89
    /// P1P2_INV_P3 = (73×89)^{-1} mod 97
    /// P1P2P3_INV_P4 = (73×89×97)^{-1} mod 113
    #[test]
    fn garner_constants_correct() {
        let (p0, p1, p2, p3) = (NTT_PRIMES[0], NTT_PRIMES[1], NTT_PRIMES[2], NTT_PRIMES[3]);

        // 73^{-1} mod 89
        let check1 = mulmod(p0 % p1, P1_INV_P2, p1);
        assert_eq!(check1, 1,
            "P1_INV_P2 wrong: {} × {} ≠ 1 (mod {})", p0, P1_INV_P2, p1);

        // (73×89)^{-1} mod 97
        let p01 = mulmod(p0 % p2, p1 % p2, p2);
        let check2 = mulmod(p01, P1P2_INV_P3, p2);
        assert_eq!(check2, 1,
            "P1P2_INV_P3 wrong: {} × {} ≠ 1 (mod {})", p01, P1P2_INV_P3, p2);

        // (73×89×97)^{-1} mod 113
        let p012 = mulmod(mulmod(p0 % p3, p1 % p3, p3), p2 % p3, p3);
        let check3 = mulmod(p012, P1P2P3_INV_P4, p3);
        assert_eq!(check3, 1,
            "P1P2P3_INV_P4 wrong: {} × {} ≠ 1 (mod {})", p012, P1P2P3_INV_P4, p3);
    }

    /// NTT matrix: every entry must equal omega^(k*j mod N) mod p.
    #[test]
    fn ntt_matrix_consistency() {
        for pi in 0..4 {
            let p = NTT_PRIMES[pi];
            let omega = NTT_ROOTS[pi];
            for k in 0..N {
                for j in 0..N {
                    let expected = modpow(omega, ((k * j) % N) as u64, p);
                    assert_eq!(NTT_MAT[pi][k][j], expected,
                        "NTT_MAT[{}][{}][{}] = {} ≠ ω^{} = {} (mod {})",
                        pi, k, j, NTT_MAT[pi][k][j], (k * j) % N, expected, p);
                }
            }
        }
    }

    /// NS_SCALE must be consistent across modules.
    #[test]
    fn scale_consistency() {
        assert_eq!(NS_SCALE, 10_000, "NS_SCALE wrong in ns3d.rs");
        assert_eq!(crate::ns3d_n16::NS_SCALE, 10_000, "NS_SCALE wrong in ns3d_n16.rs");
    }

    /// N must be 8 in the main module.
    #[test]
    fn n_value() {
        assert_eq!(N, 8, "N wrong in ns3d.rs");
        assert_eq!(crate::ns3d_n16::N, 16, "N wrong in ns3d_n16.rs");
    }
}

// ============================================================================
// SECTION 2: N=16 NTT PRIME VALIDATION
// ============================================================================

#[cfg(test)]
mod n16_ntt_validation {
    use crate::ns3d::{mulmod, modpow};
    use crate::ns3d_n16::*;

    /// N=16 primes must be ≡ 1 (mod 16) and > |k|²_max = 192.
    #[test]
    fn n16_primes_congruence_and_size() {
        let ksq_max = 3 * (N / 2) * (N / 2); // 192
        for &p in &NTT_PRIMES {
            assert_eq!(p % (N as u64), 1,
                "N=16 prime {} not ≡ 1 (mod {})", p, N);
            assert!(p > ksq_max as u64,
                "N=16 prime {} ≤ |k|²_max = {}", p, ksq_max);
            // Verify primality
            let mut is_prime = true;
            for d in 2..=(p as f64).sqrt() as u64 {
                if p % d == 0 { is_prime = false; break; }
            }
            assert!(is_prime, "N=16: {} is not prime", p);
        }
    }

    /// N=16 modulus must equal product of all four primes.
    #[test]
    fn n16_modulus_product() {
        let product: u64 = NTT_PRIMES.iter().product();
        assert_eq!(NTT_MODULUS, product,
            "N=16 NTT_MODULUS {} ≠ product {}", NTT_MODULUS, product);
    }

    /// N=16 roots must be primitive 16th roots of unity.
    #[test]
    fn n16_roots_primitive() {
        for pi in 0..4 {
            let p = NTT_PRIMES[pi];
            let omega = NTT_ROOTS[pi];
            assert_eq!(modpow(omega, N as u64, p), 1,
                "N=16 ω^N ≠ 1 for p={}", p);
            assert_eq!(modpow(omega, (N / 2) as u64, p), p - 1,
                "N=16 ω^(N/2) ≠ -1 for p={}", p);
        }
    }

    /// N=16 imaginary units must satisfy i² ≡ -1.
    #[test]
    fn n16_imaginary_units() {
        for pi in 0..4 {
            let p = NTT_PRIMES[pi];
            let i_p = I_MOD[pi];
            assert_eq!(mulmod(i_p, i_p, p), p - 1,
                "N=16 i² ≠ -1 for p={}", p);
        }
    }

    /// N=16 N_INV_3D values correct.
    #[test]
    fn n16_n_inv_3d() {
        let n3 = (N * N * N) as u64; // 4096
        for pi in 0..4 {
            let p = NTT_PRIMES[pi];
            let inv = N_INV_3D[pi];
            assert_eq!(mulmod(n3 % p, inv, p), 1,
                "N=16: N^3 × N_INV_3D ≠ 1 for p={}", p);
        }
    }
}

// ============================================================================
// SECTION 3: SOBOLEV CONSTANT VALIDATION
// ============================================================================

#[cfg(test)]
mod sobolev_validation {
    use crate::ns3d_sobolev::{SOBOLEV_NUM, SOBOLEV_DEN};

    /// Sobolev constant numerator and denominator must be positive.
    #[test]
    fn sobolev_positive() {
        assert!(SOBOLEV_NUM > 0, "SOBOLEV_NUM must be positive");
        assert!(SOBOLEV_DEN > 0, "SOBOLEV_DEN must be positive");
    }

    /// The embedding constant C = NUM/DEN must be less than 1.
    #[test]
    fn sobolev_less_than_one() {
        assert!(SOBOLEV_NUM < SOBOLEV_DEN,
            "C = {}/{} ≥ 1 — embedding constant must be < 1", SOBOLEV_NUM, SOBOLEV_DEN);
    }

    /// C ≈ 0.0952 (verify to 3 significant figures via integer arithmetic).
    #[test]
    fn sobolev_approximate_value() {
        // C × 10000 should be ≈ 952
        let c_scaled = SOBOLEV_NUM * 10_000 / SOBOLEV_DEN;
        assert!(c_scaled >= 950 && c_scaled <= 960,
            "C × 10000 = {} (expected ~952)", c_scaled);
    }

    /// Denominator relationship: SOBOLEV_DEN = SOBOLEV_inner_sum_den × 16 × N³.
    /// inner_sum_den × 8192 = SOBOLEV_DEN
    #[test]
    fn sobolev_denominator_structure() {
        // 16 × 512 = 8192
        assert_eq!(SOBOLEV_DEN % 8192, 0,
            "SOBOLEV_DEN not divisible by 16×N³=8192");
        let inner_den = SOBOLEV_DEN / 8192;
        // inner_den = 66682732900
        assert_eq!(inner_den, 66_682_732_900,
            "Inner sum denominator = {} (expected 66682732900)", inner_den);
    }
}

// ============================================================================
// SECTION 4: CONTRACTION BOUND VALIDATION
// ============================================================================

#[cfg(test)]
mod contraction_validation {
    use crate::{BOUND_NUM, BOUND_DEN, DISC_PRIMES, SCALE};

    /// Contraction bound: 90/1001 < 1.
    #[test]
    fn bound_less_than_one() {
        assert!(BOUND_NUM < BOUND_DEN,
            "Contraction bound {}/{} ≥ 1", BOUND_NUM, BOUND_DEN);
    }

    /// BOUND_NUM = 90, BOUND_DEN = 1001.
    #[test]
    fn bound_values() {
        assert_eq!(BOUND_NUM, 90);
        assert_eq!(BOUND_DEN, 1001);
    }

    /// BOUND_DEN = product of discriminating primes.
    #[test]
    fn bound_den_is_prime_product() {
        let product: u64 = DISC_PRIMES.iter().product();
        assert_eq!(BOUND_DEN, product,
            "BOUND_DEN {} ≠ product of DISC_PRIMES {}", BOUND_DEN, product);
    }

    /// BOUND_NUM = product of (p-1)/2 for each discriminating prime.
    /// (7-1)/2 × (11-1)/2 × (13-1)/2 = 3 × 5 × 6 = 90
    #[test]
    fn bound_num_from_primes() {
        let expected: u64 = DISC_PRIMES.iter().map(|&p| (p - 1) / 2).product();
        assert_eq!(BOUND_NUM, expected,
            "BOUND_NUM {} ≠ Π(p-1)/2 = {}", BOUND_NUM, expected);
    }

    /// SCALE must equal NS_SCALE.
    #[test]
    fn scale_matches() {
        assert_eq!(SCALE, crate::ns3d::NS_SCALE as u64,
            "lib.rs SCALE ({}) ≠ ns3d.rs NS_SCALE ({})", SCALE, crate::ns3d::NS_SCALE);
    }
}

// ============================================================================
// SECTION 5: STENCIL BS CONSTANT VALIDATION
// ============================================================================

#[cfg(test)]
mod stencil_validation {
    use crate::ns3d::{mulmod, NTT_PRIMES};
    use crate::ns3d_stencil_bs::D8;

    /// D₈ = 3,098,760 — verify factorization.
    #[test]
    fn d8_value_and_factorization() {
        assert_eq!(D8, 3_098_760);
        // 2³ × 3 × 5 × 7² × 17 × 31
        let expected = 8 * 3 * 5 * 49 * 17 * 31;
        assert_eq!(D8, expected,
            "D₈ factorization: {} ≠ 2³×3×5×7²×17×31 = {}", D8, expected);
    }

    /// √2 mod p must satisfy x² ≡ 2 (mod p) for each NTT prime.
    #[test]
    fn sqrt2_mod_primes() {
        let sqrt2_expected: [(u64, u64); 4] = [(73, 32), (89, 25), (97, 14), (113, 51)];
        for &(p, s2) in &sqrt2_expected {
            assert_eq!(mulmod(s2, s2, p), 2,
                "√2 mod {}: {}² = {} ≠ 2", p, s2, mulmod(s2, s2, p));
        }
    }

    /// D₈ fits in i32 (max inverse eigenvalue entry).
    #[test]
    fn d8_fits_i32() {
        assert!(D8 <= i32::MAX as i64,
            "D₈ = {} exceeds i32::MAX = {}", D8, i32::MAX);
    }
}

// ============================================================================
// SECTION 6: CROSS-MODULE CONSISTENCY
// ============================================================================

#[cfg(test)]
mod cross_module_consistency {
    /// Verify that modular arithmetic functions are shared (not duplicated).
    /// ns3d_n16 imports from ns3d — verify they use the same implementations.
    #[test]
    fn shared_modular_arithmetic() {
        // mulmod(a, b, p) should give the same result regardless of which module
        let (a, b, p) = (12345u64, 67890, 97);
        let result_ns3d = crate::ns3d::mulmod(a, b, p);
        // ns3d_n16 uses `use crate::ns3d::mulmod` — same function
        assert_eq!(result_ns3d, (a as u128 * b as u128 % p as u128) as u64);
    }

    /// Verify N=8 and N=16 use different prime sets (no accidental sharing).
    #[test]
    fn disjoint_prime_sets() {
        for &p8 in &crate::ns3d::NTT_PRIMES {
            for &p16 in &crate::ns3d_n16::NTT_PRIMES {
                assert_ne!(p8, p16,
                    "Prime {} appears in both N=8 and N=16 sets", p8);
            }
        }
    }

    /// BS normalization constants: N=8 uses N⁶, N=16 uses empirical.
    /// Verify they produce velocity/vorticity ratio ≈ 1 for TG.
    #[test]
    fn bs_normalization_produces_unit_ratio() {
        // N=8: biot_savart_normalized divides by N^6 = 262144
        let n8_factor = (crate::ns3d::N as i64).pow(6);
        assert_eq!(n8_factor, 262_144, "N=8 N⁶ wrong");

        // N=16: BS_NORM = 709508465 (empirical)
        // Verify it's in the right ballpark: should be ~ N⁶ × correction
        let n16_n6 = (crate::ns3d_n16::N as i64).pow(6); // 16777216
        assert!(709_508_465 > n16_n6, "N=16 BS_NORM should exceed N⁶");
        // Ratio ≈ 42.3 (the per-mode spectral mismatch)
        let ratio = 709_508_465i64 / n16_n6;
        assert!(ratio > 30 && ratio < 60,
            "N=16 BS_NORM/N⁶ ratio = {} (expected ~42)", ratio);
    }

    /// Stencil BS normalization: 305959 for N=8.
    /// Should be slightly larger than NTT-BS factor (stencil eigenvalues < flat |k|²).
    #[test]
    fn stencil_norm_vs_ntt_norm() {
        let ntt_norm = (crate::ns3d::N as i64).pow(6); // 262144
        let stencil_norm = 305_959i64;
        assert!(stencil_norm > ntt_norm,
            "Stencil norm {} should exceed NTT norm {} (stencil eigenvalues are smaller)",
            stencil_norm, ntt_norm);
        // Ratio should be ~1.17 (from prior measurement)
        let ratio_pm = stencil_norm * 1000 / ntt_norm;
        assert!(ratio_pm > 1100 && ratio_pm < 1250,
            "Stencil/NTT ratio = {} permille (expected ~1168)", ratio_pm);
    }
}

// ============================================================================
// SECTION 7: MATHEMATICAL IDENTITY VALIDATION
// ============================================================================

#[cfg(test)]
mod mathematical_identities {
    use crate::ns3d::*;

    /// Verify: 73 × 89 × 97 × 113 = 71,213,617 (exact).
    #[test]
    fn modulus_arithmetic() {
        assert_eq!(73u64 * 89 * 97 * 113, 71_213_617);
    }

    /// Verify: M/2 = 35,606,808 (corridor boundary).
    #[test]
    fn corridor_boundary() {
        assert_eq!(NTT_MODULUS / 2, 35_606_808);
    }

    /// Verify: N³ = 512 for N=8.
    #[test]
    fn grid_size() {
        assert_eq!(N * N * N, 512);
    }

    /// Verify: |k|²_max = 48 for centered N=8 grid.
    /// Max freq: (-4, -4, -4), |k|² = 48.
    #[test]
    fn ksq_max_n8() {
        let mut max_ksq: i64 = 0;
        for kx in 0..N {
            for ky in 0..N {
                for kz in 0..N {
                    let cx = if kx <= N/2 { kx as i64 } else { kx as i64 - N as i64 };
                    let cy = if ky <= N/2 { ky as i64 } else { ky as i64 - N as i64 };
                    let cz = if kz <= N/2 { kz as i64 } else { kz as i64 - N as i64 };
                    let ksq = cx*cx + cy*cy + cz*cz;
                    if ksq > max_ksq { max_ksq = ksq; }
                }
            }
        }
        assert_eq!(max_ksq, 48, "|k|²_max = {} (expected 48)", max_ksq);
        // All primes must exceed this
        for &p in &NTT_PRIMES {
            assert!(p > max_ksq as u64, "Prime {} ≤ |k|²_max = {}", p, max_ksq);
        }
    }

    /// Verify: BOUND_DEN = 7 × 11 × 13 = 1001.
    #[test]
    fn contraction_product() {
        assert_eq!(7u64 * 11 * 13, 1001);
    }

    /// Verify: BOUND_NUM = 3 × 5 × 6 = 90.
    #[test]
    fn contraction_numerator() {
        assert_eq!(3u64 * 5 * 6, 90);
    }

    /// Verify: 90 < 1001 (the contraction inequality).
    #[test]
    fn contraction_inequality() {
        assert!(90 < 1001);
    }

    /// Verify: D₈ = 2³ × 3 × 5 × 7² × 17 × 31 = 3,098,760.
    #[test]
    fn d8_factorization() {
        assert_eq!(8u64 * 3 * 5 * 49 * 17 * 31, 3_098_760);
    }

    /// Verify: Sobolev inner sum denominator × 8192 = SOBOLEV_DEN.
    #[test]
    fn sobolev_structure() {
        assert_eq!(66_682_732_900i128 * 8192, 546_264_947_916_800);
    }

    /// Verify: N=16 modulus = 577 × 593 × 641 × 673.
    #[test]
    fn n16_modulus_arithmetic() {
        assert_eq!(577u64 * 593 * 641 * 673, 147_605_860_273);
    }
}

// ============================================================================
// SECTION 8: FLOAT CONTAMINATION AUDIT
// ============================================================================

#[cfg(test)]
mod float_audit {
    /// Verify that no constant in the workspace uses floating-point.
    /// This test documents the invariant rather than checking at runtime
    /// (runtime constants are already integer by type system).
    #[test]
    fn constants_are_integer() {
        // All pub const in ns3d.rs
        assert_eq!(std::mem::size_of_val(&crate::ns3d::NS_SCALE), 8); // i64
        assert_eq!(std::mem::size_of_val(&crate::ns3d::NTT_MODULUS), 8); // u64

        // Sobolev constants are i128
        assert_eq!(std::mem::size_of_val(&crate::ns3d_sobolev::SOBOLEV_NUM), 16);
        assert_eq!(std::mem::size_of_val(&crate::ns3d_sobolev::SOBOLEV_DEN), 16);

        // D₈ is i64
        assert_eq!(std::mem::size_of_val(&crate::ns3d_stencil_bs::D8), 8);

        // None of these are f32 (4 bytes) or f64 (8 bytes with different semantics)
        // The type system enforces this, but we document it explicitly.
    }
}

// ============================================================================
// SECTION 9: INVERSE EIGENVALUE TABLE VALIDATION
// ============================================================================

#[cfg(test)]
mod inv_eigen_validation {
    use crate::ns3d_stencil_bs::{D8, INV_EIGEN};
    use crate::ns3d::N;

    /// Every entry in the inverse eigenvalue table must satisfy:
    /// D₈ × α / norm = p (integer) AND D₈ × (-β) / norm = q (integer)
    /// where α = rational part of 4σ_k, β = √2 coeff of 4σ_k,
    /// norm = α² - 2β² (the Q(√2) norm).
    #[test]
    fn inv_eigen_entries_are_exact() {
        // sin²(πk/8) as (a, b) scaled by 4: 4σ_component = a + b√2
        let sin2_4: [(i64, i64); 8] = [
            (0, 0), (2, -1), (2, 0), (2, 1), (4, 0), (2, 1), (2, 0), (2, -1)
        ];

        let mut errors = 0;
        for kx in 0..N {
            for ky in 0..N {
                for kz in 0..N {
                    let (ax, bx) = sin2_4[kx];
                    let (ay, by) = sin2_4[ky];
                    let (az, bz) = sin2_4[kz];
                    let alpha = ax + ay + az;
                    let beta = bx + by + bz;

                    let (p_stored, q_stored) = INV_EIGEN[kx * N + ky][kz];

                    if alpha == 0 && beta == 0 {
                        // Zero mode
                        assert_eq!((p_stored, q_stored), (0, 0),
                            "Zero mode at ({},{},{}) should be (0,0)", kx, ky, kz);
                        continue;
                    }

                    let norm = alpha * alpha - 2 * beta * beta;
                    assert!(norm > 0,
                        "Non-positive norm at ({},{},{}): α={} β={} norm={}",
                        kx, ky, kz, alpha, beta, norm);

                    let p_expected = (D8 * alpha) / norm;
                    let q_expected = (-D8 * beta) / norm;

                    // Verify exact division
                    if D8 * alpha % norm != 0 {
                        errors += 1;
                    }
                    if D8 * (-beta) % norm != 0 {
                        errors += 1;
                    }

                    assert_eq!(p_stored as i64, p_expected,
                        "INV_EIGEN[{}][{}] rational part wrong: {} ≠ {}",
                        kx * N + ky, kz, p_stored, p_expected);
                    assert_eq!(q_stored as i64, q_expected,
                        "INV_EIGEN[{}][{}] √2 part wrong: {} ≠ {}",
                        kx * N + ky, kz, q_stored, q_expected);
                }
            }
        }
        assert_eq!(errors, 0, "Found {} inexact divisions in inverse eigenvalue table", errors);
    }
}

// ============================================================================
// SECTION 10: CONFIGURATION SUMMARY REPORT
// ============================================================================

#[cfg(test)]
mod config_report {
    use crate::ns3d::*;

    /// Print a complete configuration summary for human review.
    #[test]
    fn print_config_summary() {
        println!("\n{}", "=".repeat(78));
        println!("  NS REGULARITY WORKSPACE — CONFIGURATION SUMMARY");
        println!("{}\n", "=".repeat(78));

        println!("  N=8 NTT:");
        println!("    Primes: {:?}", NTT_PRIMES);
        println!("    Modulus M: {} (M/2 = {})", NTT_MODULUS, NTT_MODULUS / 2);
        println!("    Roots ω₈: {:?}", NTT_ROOTS);
        println!("    Imaginary i: {:?}", I_MOD);
        println!("    N⁻³ mod p: {:?}", N_INV_3D);
        println!("    Garner: c01={} c012={} c0123={}", P1_INV_P2, P1P2_INV_P3, P1P2P3_INV_P4);
        println!("    BS norm (NTT): N⁶ = {}", (N as i64).pow(6));
        println!("    BS norm (stencil): {}", crate::ns3d_stencil_bs::D8);

        println!("\n  N=16 NTT:");
        println!("    Primes: {:?}", crate::ns3d_n16::NTT_PRIMES);
        println!("    Modulus M₁₆: {}", crate::ns3d_n16::NTT_MODULUS);
        println!("    Roots ω₁₆: {:?}", crate::ns3d_n16::NTT_ROOTS);

        println!("\n  Sobolev:");
        println!("    C(8) = {} / {}", crate::ns3d_sobolev::SOBOLEV_NUM, crate::ns3d_sobolev::SOBOLEV_DEN);
        println!("    C(8) ≈ {}/10000", crate::ns3d_sobolev::SOBOLEV_NUM * 10000 / crate::ns3d_sobolev::SOBOLEV_DEN);

        println!("\n  Contraction:");
        println!("    B(N) ≤ {}/{} = {}/10000",
            crate::BOUND_NUM, crate::BOUND_DEN,
            crate::BOUND_NUM * 10000 / crate::BOUND_DEN);

        println!("\n  Stencil BS:");
        println!("    D₈ = {} = 2³×3×5×7²×17×31", crate::ns3d_stencil_bs::D8);
        println!("    √2 mod primes: [32, 25, 14, 51]");

        println!("\n  Invariants:");
        println!("    Float contamination: 0");
        println!("    NS_SCALE: {} (consistent across all modules)", NS_SCALE);
        println!("{}", "=".repeat(78));
    }
}
