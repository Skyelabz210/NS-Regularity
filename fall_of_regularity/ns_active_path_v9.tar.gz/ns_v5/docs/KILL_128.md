# Kill #128 — The Biot-Savart Kernel Is Irrational
## Confirmed: April 4, 2026

## The Finding

The vectorial Biot-Savart kernel on the N=8 periodic lattice lives in Q(√2),
NOT in Q. Specifically:

  u_z(0,1,0) from ω_x = δ(origin) gives:
  u_z = 6781339/99160320 + (2229539/19832064)·√2

The √2 coefficient is nonzero at every non-trivial kernel entry tested.

## Why This Happens

The physical BS multiplier in Fourier space is:
  u_hat = (ik × ω_hat) / (4·σ_k)

where σ_k = sin²(πkx/N) + sin²(πky/N) + sin²(πkz/N).

For N=8: sin²(π/8) = (2 - √2)/4, which is IRRATIONAL. The denominator
4σ_k involves √2, and when the inverse DFT sums these terms with
sin(2πk/N) = √2/2 (also irrational), the product sin/σ produces both
rational AND √2 components that do NOT cancel in the vectorial kernel.

The SCALAR Green's function (Poisson kernel) IS rational — the Galois
cancellation works there because cos/σ sums are invariant under σ: √2 → -√2.
But the vectorial kernel involves sin/σ, which has the WRONG symmetry:
sin(πk/4) = √2/2 is negated by σ, while σ_k is preserved, so the quotient
acquires a √2 component that persists.

## What the NTT-BS Actually Computes

The NTT-BS divides by |k|² = kx² + ky² + kz² (INTEGER wavenumber squared),
NOT by 4σ_k (the discrete Laplacian eigenvalue). These differ significantly:

| Mode (kx,ky,kz) | |k|² | 4σ_k | Ratio |
|-----------------|------|------|-------|
| (0,0,1) | 1 | 0.586 | 1.71 |
| (0,1,1) | 2 | 1.172 | 1.71 |
| (1,1,1) | 3 | 1.757 | 1.71 |
| (0,0,2) | 4 | 2.000 | 2.00 |
| (0,0,4) | 16 | 4.000 | 4.00 |

The ratio |k|²/(4σ_k) ranges from 1.71 to 4.00 at N=8. The NTT-BS is
computing a FLAT-SPECTRUM Biot-Savart that uses integer wavenumbers instead
of discrete Laplacian eigenvalues. This is a well-defined, exact-integer
operator — it is just NOT the same as inverting the 6-point stencil Laplacian.

## The Empirical Normalization Factor

The BS_NORM constant (262,144 for N=8, 709,508,465 for N=16) corrects
for the mismatch between |k|² and the physical (2πk/N)² scaling.
This is an OVERALL scale factor — it corrects the velocity MAGNITUDE
but does not fix the per-mode ratios (which differ by factors of 1.7-4.0).

## What Survives Kill #128

1. **Kill #113 (advection = 0):** SURVIVES. This identity holds for ANY
   velocity field on the periodic lattice, not just the physical BS velocity.
   The proof is pure summation-by-parts — it does not reference the BS kernel.
   Verified by 19 adversarial tests with the NTT-BS velocity.

2. **Energy monotonicity under diffusion:** SURVIVES. The diffusion operator
   uses the stencil Laplacian (exact integers), not the BS kernel.

3. **Sobolev embedding:** SURVIVES. The embedding constant depends only on
   the stencil Laplacian eigenvalues, not on the BS kernel.

4. **Contraction bound:** SURVIVES. Independent of BS.

5. **Recumbent architecture:** SURVIVES. Independent of BS.

## What Is Affected

1. **"Exact Biot-Savart" claim:** CORRECTED. The NTT-BS is an exact-integer
   FLAT-SPECTRUM BS, not the stencil-consistent BS. It's a valid O(h²)
   discretization but with different per-mode behavior than the physical BS.

2. **Stretching measurements:** AFFECTED. The stretching ⟨ω, (ω·∇)u⟩ uses
   NTT-BS velocity u, which differs from the stencil-BS velocity by per-mode
   factors of 1.7-4.0. The qualitative behavior (decay at all amplitudes)
   likely holds for both, but the quantitative values differ.

3. **BKM chain:** AFFECTED at the quantitative level. The L∞ bound on velocity
   depends on which BS is used.

4. **N⁶ normalization:** EXPLAINED. It's the overall scale mismatch between
   flat |k|² and physical (2πk/N)² wavenumbers, accumulated over the NTT chain.

## The Correction Path

To implement the STENCIL-CONSISTENT BS (the physical one that inverts the
discrete Laplacian), the solver would need to:

1. Work in Q(√2) for N=8 (two rational coordinates per value)
2. Use CRT lanes separately for the rational and √2 components
3. The denominator D₈ would be the LCM of the coefficient denominators

This is feasible with the existing CRTBigInt infrastructure but doubles
the storage and computation cost.

Alternatively: keep the NTT-BS as a valid discretization and acknowledge
it uses flat wavenumbers. The continuum limit is the same either way.

## Status

Kill #128 is CONFIRMED and DOCUMENTED. The workspace correction is:
- Change "exact Biot-Savart" to "exact flat-spectrum Biot-Savart"
- Add this document to the open seams dossier
- All existing tests continue to pass (they test the NTT-BS, which is internally consistent)
- The qualitative conclusions (all solutions decay, Kill #113 holds) are unchanged
