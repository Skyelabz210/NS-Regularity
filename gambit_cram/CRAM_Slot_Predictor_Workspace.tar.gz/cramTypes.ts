// CRAM 8-Liner Slot Predictor Types

export interface LaneParams {
  a: number;
  c: number;
}

export interface LaneStatus {
  modulus: number;
  residue: number;
  status: 'pending' | 'calibrating' | 'ok' | 'error';
  params?: LaneParams;
}

export interface SyndromeResult {
  laneA: number;
  laneQ: number;
  kObserved: number;
  kPredicted: number;
  match: boolean;
}

export interface PredictionResult {
  predicted: number;
  observed: number;
  paylines: number[];
  syndromes: SyndromeResult[];
  allMatch: boolean;
}

export interface CalibrationState {
  isCalibrating: boolean;
  progress: number;
  totalSamples: number;
  currentSamples: number;
  lanes: LaneStatus[];
  globalA?: number;
  globalC?: number;
}

export interface SpinHistory {
  spinNumber: number;
  value: number;
  predicted?: number;
  syndromeOk?: boolean;
  timestamp: Date;
}

export interface CRAMState {
  basis: number[];
  M: number;
  mode: 'standard' | 'shadow-zero';
  params?: { a: number; c: number };
  spins: number[];
  predictions: PredictionResult[];
  calibration: CalibrationState;
}

export type LogLevel = 'info' | 'success' | 'warning' | 'error';

export interface SystemLog {
  id: string;
  timestamp: Date;
  message: string;
  level: LogLevel;
}
