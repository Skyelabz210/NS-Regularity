/**
 * CRAM (Configurable Residue Arithmetic Machine) Engine
 * 
 * Core mathematical implementation for 8-Liner Slot Prediction:
 * - Chinese Remainder Theorem (CRT) decomposition and reconstruction
 * - K-Elimination syndrome checking
 * - Linear Congruential Generator (LCG) prediction
 * - Per-lane calibration
 */

import type { LaneParams, SyndromeResult, PredictionResult, CalibrationState } from '@/types';

// Safe Basis moduli (coprime)
export const SAFE_BASIS = [3, 5, 7, 11, 13];
export const SAFE_M = SAFE_BASIS.reduce((a, b) => a * b, 1); // 15015

// Shadow-Zero Basis (composite moduli for hierarchical error detection)
export const SHADOW_BASIS = [9, 25, 7, 11, 13];
export const SHADOW_M = SHADOW_BASIS.reduce((a, b) => a * b, 1); // 86625

/**
 * Compute greatest common divisor
 */
export function gcd(a: number, b: number): number {
  return b === 0 ? a : gcd(b, a % b);
}

/**
 * Modular inverse using extended Euclidean algorithm
 */
export function modInverse(a: number, m: number): number {
  const g = gcd(a, m);
  if (g !== 1) {
    throw new Error(`Modular inverse does not exist for ${a} mod ${m}`);
  }
  
  // Extended Euclidean algorithm
  let [old_r, r] = [a, m];
  let [old_s, s] = [1, 0];
  
  while (r !== 0) {
    const quotient = Math.floor(old_r / r);
    [old_r, r] = [r, old_r - quotient * r];
    [old_s, s] = [s, old_s - quotient * s];
  }
  
  return ((old_s % m) + m) % m;
}

/**
 * Chinese Remainder Theorem reconstruction
 * Reconstructs global value from per-lane residues
 */
export function crtReconstruct(residues: number[], moduli: number[]): number {
  if (residues.length !== moduli.length) {
    throw new Error('Residues and moduli must have same length');
  }
  
  const M = moduli.reduce((a, b) => a * b, 1);
  let result = 0;
  
  for (let i = 0; i < residues.length; i++) {
    const r = residues[i];
    const m = moduli[i];
    const Mi = M / m;
    const yi = modInverse(Mi, m);
    result += r * Mi * yi;
  }
  
  return result % M;
}

/**
 * K-Elimination: Compute winding number between two lanes
 * This is the core bridging mechanism for error detection
 * 
 * k = ((r_q - r_a) * m_a^(-1)) mod m_q
 */
export function kElimination(
  rA: number, 
  rQ: number, 
  mA: number, 
  mQ: number
): number {
  const diff = ((rQ - rA) % mQ + mQ) % mQ;
  const inv = modInverse(mA, mQ);
  return (diff * inv) % mQ;
}

/**
 * Calibrate a single lane to find LCG parameters (a, c)
 * Uses consecutive spin pairs to solve for parameters
 */
export function calibrateLane(
  spins: number[], 
  modulus: number
): LaneParams | null {
  if (spins.length < 3) return null;
  
  for (let k = 0; k < spins.length - 2; k++) {
    const r1 = spins[k] % modulus;
    const r2 = spins[k + 1] % modulus;
    const r3 = spins[k + 2] % modulus;
    
    const diffR = ((r2 - r1) % modulus + modulus) % modulus;
    const diff1 = ((r3 - r2) % modulus + modulus) % modulus;
    
    // Ensure modular inverse exists
    if (gcd(diffR, modulus) === 1) {
      const a = (diff1 * modInverse(diffR, modulus)) % modulus;
      const c = ((r2 - (a * r1) % modulus) % modulus + modulus) % modulus;
      return { a, c };
    }
  }
  
  return null;
}

/**
 * Full calibration across all lanes
 */
export function calibrateAllLanes(
  spins: number[], 
  basis: number[] = SAFE_BASIS
): { laneParams: Map<number, LaneParams>; globalA: number; globalC: number } | null {
  const laneParams = new Map<number, LaneParams>();
  
  for (const m of basis) {
    const params = calibrateLane(spins, m);
    if (!params) {
      return null; // Calibration failed for this lane
    }
    laneParams.set(m, params);
  }
  
  // Reconstruct global parameters via CRT
  const aResidues = basis.map(m => laneParams.get(m)!.a);
  const cResidues = basis.map(m => laneParams.get(m)!.c);
  
  const globalA = crtReconstruct(aResidues, basis);
  const globalC = crtReconstruct(cResidues, basis);
  
  return { laneParams, globalA, globalC };
}

/**
 * Predict next LCG value
 * x_next = (a * x_current + c) mod M
 */
export function predictLCG(current: number, a: number, c: number, M: number): number {
  return (a * current + c) % M;
}

/**
 * Generate 8-liner paylines from predicted RNG state
 * Each payline uses a different modulus offset
 */
export function generatePaylines(rngState: number): number[] {
  // 8 paylines with different modulus bases (32-39)
  return Array.from({ length: 8 }, (_, i) => rngState % (32 + i));
}

/**
 * Check all pairwise K-Elimination syndromes
 * Returns detailed results for each lane pair
 */
export function checkAllSyndromes(
  observed: number,
  predicted: number,
  basis: number[] = SAFE_BASIS
): SyndromeResult[] {
  const results: SyndromeResult[] = [];
  
  for (let i = 0; i < basis.length; i++) {
    for (let j = i + 1; j < basis.length; j++) {
      const mA = basis[i];
      const mQ = basis[j];
      
      const rPredA = predicted % mA;
      const rObsA = observed % mA;
      const rPredQ = predicted % mQ;
      const rObsQ = observed % mQ;
      
      const kObs = kElimination(rObsA, rObsQ, mA, mQ);
      const kPred = kElimination(rPredA, rPredQ, mA, mQ);
      
      results.push({
        laneA: mA,
        laneQ: mQ,
        kObserved: kObs,
        kPredicted: kPred,
        match: kObs === kPred
      });
    }
  }
  
  return results;
}

/**
 * Full prediction with syndrome checking
 */
export function makePrediction(
  currentSpin: number,
  lastSpin: number,
  a: number,
  c: number,
  M: number,
  basis: number[] = SAFE_BASIS
): PredictionResult {
  const predicted = predictLCG(lastSpin, a, c, M);
  const paylines = generatePaylines(predicted);
  const syndromes = checkAllSyndromes(currentSpin, predicted, basis);
  const allMatch = syndromes.every(s => s.match);
  
  return {
    predicted,
    observed: currentSpin,
    paylines,
    syndromes,
    allMatch
  };
}

/**
 * Initialize calibration state
 */
export function initCalibrationState(basis: number[] = SAFE_BASIS): CalibrationState {
  return {
    isCalibrating: false,
    progress: 0,
    totalSamples: 20,
    currentSamples: 0,
    lanes: basis.map(m => ({
      modulus: m,
      residue: 0,
      status: 'pending' as const
    }))
  };
}

/**
 * Simulate an LCG for testing (deterministic)
 */
export function simulateLCG(
  seed: number,
  a: number,
  c: number,
  M: number,
  count: number
): number[] {
  const spins: number[] = [];
  let current = seed;
  
  for (let i = 0; i < count; i++) {
    current = predictLCG(current, a, c, M);
    spins.push(current);
  }
  
  return spins;
}

/**
 * Generate a random LCG for simulation purposes
 */
export function generateRandomLCG(M: number = SAFE_M): { a: number; c: number; seed: number } {
  // Generate valid LCG parameters
  const a = Math.floor(Math.random() * (M - 2)) + 2;
  const c = Math.floor(Math.random() * M);
  const seed = Math.floor(Math.random() * M);
  return { a, c, seed };
}
