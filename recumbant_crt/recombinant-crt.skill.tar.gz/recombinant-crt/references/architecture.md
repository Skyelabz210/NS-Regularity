# Architecture Reference — Recombinant CRT Bridge

## Implementation Details (lib.rs v2)

### Exact Moduli

Eight 63-bit primes, all of the form 2^63 - offset:

```
p0 = 9223372036854775783  (2^63 - 25)
p1 = 9223372036854775643  (2^63 - 165)
p2 = 9223372036854775549  (2^63 - 259)
p3 = 9223372036854775507  (2^63 - 301)
p4 = 9223372036854775337  (2^63 - 471)
p5 = 9223372036854775291  (2^63 - 517)
p6 = 9223372036854775279  (2^63 - 529)
p7 = 9223372036854775207  (2^63 - 601)
```

Product M ≈ 2^504. All odd (required for Montgomery). All pairwise coprime
(all prime). None equal to 2, 3, 5, 7, or 11 (required for Safe Basis
separation).

### CRTBigInt Memory Layout

```rust
pub struct CRTBigInt {
    pub residues: [u64; 8],  // 64 bytes, stack-allocated, cache-line friendly
    pub sign: i8,            // -1, 0, or 1 (separate from residues)
}
```

Total size: 65 bytes (72 with padding). No heap allocation. No Vec overhead.
This is a deliberate change from v1 which used Vec<u64>.

### Montgomery Context

One MontgomeryCtx per exact modulus, precomputed at startup via lazy_static:

```rust
pub struct MontgomeryCtx {
    pub modulus: u64,
    r_squared: u64,   // R² mod N where R = 2^64
    n_inv_neg: u64,   // -N⁻¹ mod 2^64 via Hensel lifting
}
```

REDC reduces a 128-bit product to [0, N) in constant time (no branching
on value, only a single conditional subtraction at the end).

Hensel lifting: 6 iterations of y = y·(2 - n·y) doubles correct bits each
time: 1→2→4→8→16→32→64 bits.

### K-Elimination Implementation

```rust
pub fn k_eliminate(
    r_main: u64, m_main: u64,
    r_anchor: u64, m_anchor: u64
) -> Option<KElimResult>
```

Steps:
1. Compute m_main⁻¹ mod m_anchor (returns None if gcd ≠ 1)
2. Compute diff = (r_anchor - r_main % m_anchor) mod m_anchor
3. k = diff × m_inv mod m_anchor
4. Return KElimResult with k, both residues, both moduli

Reconstruction: X = r_main + k × m_main (u128 to handle overflow).

### 11-Smooth Factorization

```rust
pub fn factor_11_smooth(mut n: u64) -> SmoothFactors {
    let mut exponents = [0u32; 5];
    for (i, &p) in [2, 3, 5, 7, 11].iter().enumerate() {
        while n % p == 0 {
            n /= p;
            exponents[i] += 1;
        }
    }
    SmoothFactors { exponents, cofactor: n }
}
```

If cofactor == 1, the number is fully 11-smooth. Otherwise, cofactor contains
the product of all prime factors > 11.

### TriadValue Absorb Operation

```rust
pub fn absorb(&mut self, scaled_numerator: i64, denominator: u64,
              epsilon: u64, source: ApproxSource) {
    let factors = factor_11_smooth(denominator);
    assert!(factors.is_fully_smooth());
    for (prime, exp, modulus) in factors.sublane_moduli() {
        let residue = scaled_numerator.unsigned_abs() % modulus;
        self.approx.push(ApproxLane { prime, exp, modulus, residue,
                                       epsilon, scale: denominator, source });
    }
}
```

Example: absorb(31416, 10000, 1, EnergyEstimate)
- factor_11_smooth(10000) → {2: 4, 5: 4} (16 × 625)
- Creates lane mod 16: residue = 31416 % 16 = 8
- Creates lane mod 625: residue = 31416 % 625 = 166
- Both frozen with epsilon = 1

### Error Propagation Rules (implemented)

TriadValue::add:
```rust
epsilon: a.epsilon.saturating_add(b.epsilon)  // triangle inequality
```

TriadValue::mul:
```rust
epsilon: a.epsilon.saturating_add(b.epsilon)
    .saturating_mul(a.residue.max(b.residue).max(1))  // conservative scaling
```

K-Elimination: k itself is exact (u64). Only interpretation carries error.

---

## Genealogy (Innovation Lineage)

```
SEED: "Truth cannot be approximated" (Gen 0)
 ├─→ Integer Primacy (Gen 1)
 │   └─→ CRTBigInt v1 (Gen 2) — 418ns, 2.4M ops/sec, 675 lines Rust
 │       └─→ CRTBigInt v2 (Gen 3) — fixed [u64;8], Triad architecture
 │
 ├─→ CRT Foundation (Gen 1)
 │   ├─→ K-Elimination (Gen 3) — 60-year exact division problem KILLED
 │   ├─→ Garner MRC (Gen 2) — mixed-radix reconstruction
 │   └─→ PLMG Phase-Locked Modular Geometry (Gen 2)
 │
 ├─→ Airlock (Gen 3, Dec 2025) — float quarantine with error tracking
 │   └─→ Triad Architecture v1 (Gen 4, Mar 2026) — permanent absorption
 │       └─→ Recombinant Bridge (Gen 5, Mar 2026) — denominator-factored
 │           composite sub-lanes with phase-lock guarantee
 │
 ├─→ Adaptive CRT (Gen 3, Oct 2025) — dynamic prime expansion
 │   └─→ 11-Smooth Factorization (Gen 4) — Safe Basis decomposition
 │
 ├─→ Clockwork Prime Principle (Gen 2) — automatic coprimality
 │   └─→ Safe Prime Basis {2,3,5,7,11} (Gen 3)
 │       └─→ Composite capacity via exponents (Gen 4) — never > 11
 │
 └─→ Goldbach CRT Torus Testing (Gen 3, Feb 2026)
     └─→ Phase-Lock Saturation Proof (Gen 4) — empirical, N ≤ 500k
```

---

## Comparison With Prior QMNF Components

| Component | What It Did | What Recombinant Bridge Adds |
|-----------|------------|------------------------------|
| CRTBigInt v1 | Exact arithmetic in 8 lanes | TriadValue extends with approx sub-lanes |
| K-Elimination | Exact division via anchor residues | Cross-lane K-Elim between exact and approx |
| Airlock | Float quarantine (revolving door) | Permanent absorption (citizenship) |
| Adaptive CRT | Dynamic prime set changes | Denominator-dictated factored sub-lanes |
| Clockwork Prime | Automatic coprime prime hierarchy | Safe Basis composites (exponent stacking) |
| PLMG | Phase-locked modular geometry | Phase-lock saturation PROVEN for Safe Basis |

---

## Capacity Reference Table

### Safe Basis Composite Capacity

All configurations use ONLY {2, 3, 5, 7, 11}. All pairwise coprime.

| Target Bits | Exponents [2,3,5,7,11] | Actual Bits | Sub-Lanes |
|-------------|------------------------|-------------|-----------|
| 11 | [1,1,1,1,1] | 11.2 | 5 |
| 23 | [4,3,2,2,1] | 22.5 | 5 |
| 44 | [10,6,4,3,2] | 44.1 | 5 |
| 86 | [20,12,8,5,4] | 85.5 | 5 |
| 128 | [25,16,11,9,7] | 125.4 | 5 |
| 155 | [32,20,14,11,8] | 154.8 | 5 |
| 256 | [50,32,22,18,14] | ~255 | 5 |
| 314 | [64,40,27,22,18] | 314.1 | 5 |

### Common Denominators (all 11-smooth)

| Source | Denominator | Factorization | Sub-Lanes |
|--------|------------|---------------|-----------|
| f32 mantissa | 2^23 | 2^23 | 1 |
| f64 mantissa | 2^52 | 2^52 | 1 |
| Decimal ×1000 | 1000 | 2³×5³ | 2 |
| Decimal ×10000 | 10000 | 2⁴×5⁴ | 2 |
| CORDIC scale | 2^30 | 2^30 | 1 |
| Grid N=1024 | 1024 | 2^10 | 1 |
| Full safe basis | 2310 | 2×3×5×7×11 | 5 |
| Time dt=1/360 | 360 | 2³×3²×5 | 3 |
