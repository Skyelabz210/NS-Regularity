# Constraints and Boundaries Reference

## Hard Mathematical Constraints

### C1: Prime Separation
Exact lane primes (63-bit) must share no factor with Safe Basis primes
{2,3,5,7,11}. Since all exact primes are themselves large primes > 2^62,
and 2, 3, 5, 7, 11 are each less than 12, this is guaranteed: a prime
p > 12 cannot equal 2, 3, 5, 7, or 11. Verified in lib.rs via debug_assert.

Violation consequence: gcd(exact_modulus, sub_lane_modulus) > 1 → CRT ring
isomorphism breaks → K-Elimination returns incorrect winding number.

### C2: Coprimality of Sub-Lanes
All approximation sub-lanes created by Denominator Factorization are
pairwise coprime because they have DISTINCT prime bases. gcd(p^a, q^b) = 1
for distinct primes p, q. This is the Fundamental Theorem of Arithmetic.

Violation scenario: if two sub-lanes have the SAME prime base with DIFFERENT
exponents (e.g., one from denominator 8=2^3 and another from denominator
4=2^2), they are NOT coprime. The architecture prevents this by creating
sub-lanes from a single denominator factorization. Multiple absorb() calls
with overlapping prime factors would create duplicate bases — the caller
must ensure distinct denominator decompositions or merge them.

### C3: Range Bound
CRT uniqueness holds only for 0 ≤ X < product of all moduli. For the exact
lanes, this is ≈ 2^504 (no practical limitation). For sub-lane pairs, the
product is the two sub-lane moduli multiplied. K-Elimination is only valid
when the true value X is less than this product.

### C4: Odd Modulus for Montgomery
Montgomery REDC requires gcd(modulus, R) = 1 where R = 2^64. Since R is a
power of 2, modulus must be odd. All eight exact primes are odd (they are
large primes > 2). Sub-lane moduli: 3^e, 5^e, 7^e, 11^e are always odd.
Only 2^e sub-lanes are even and CANNOT use Montgomery directly (use plain
mulmod instead). This is handled transparently in the implementation.

### C5: Quantization is Irreversible
Once a continuous value is quantized into a sub-lane residue, the original
real number cannot be recovered from the residue alone. The epsilon bound
records the maximum distance between the true value and the quantized
integer, but the exact real value is lost. This is not a bug; it is the
Landauer principle at work (information erasure costs energy).

---

## The Prime-13 Boundary (Empirical, from Phase 3c Testing)

### What Was Tested
CRT torus fiber coverage for even integers 4 through 500,000, measuring
what fraction of admissible CRT cells (cells not ruled out by sieving with
the basis primes) contained at least one Goldbach-participating prime.

### Saturation Results by Codimension

Codimension 2 (pairs): ALL pairs from {3,5,7,11,13,17} → 100%.
Codimension 3 (triples): ALL triples → 100%.
Codimension 4 (quads): 18/20 quads → 100%. Two largest (containing
  both 13 and 17) at 99.32% and 99.96%.
Codimension 5 (quints): 3×5×7×11×13 → 100%, but
  5×7×11×13×17 (no mod-3) → 69.97%.
Codimension 6 (full): 45.06% (prime supply still catching up).

### Interpretation

The saturation criterion: π(N) ≫ ∏(mᵢ − 1)

For {2,3,5,7,11}: ∏(mᵢ−1) = 1×2×4×6×10 = 480. Need π(N) ≈ 2500,
so N ≈ 25,000 saturates. We tested to 500,000. Heavily saturated.

For {5,7,11,13,17}: ∏(mᵢ−1) = 4×6×10×12×16 = 46,080. Need
π(N) ≈ 230,000, so N ≈ 3M. Testing only went to 500k. Not saturated.

### The Decision

The composite-prime strategy eliminates this boundary entirely:
never use a prime modulus > 11. If you need more capacity from a
sub-lane, raise the exponent: 2^4 → 2^8 → 2^16 → 2^32 etc.
This stays within the proven saturation zone while achieving
arbitrarily large capacity.

---

## Engineering Constraints

### Garner Reconstruction Overflow
The garner_reconstruct() method returns u128. For values exceeding
2^127, the reconstruction wraps. The current implementation is sufficient
for i64 round-trips but NOT for full 504-bit exact-lane values. A future
enhancement would use a BigUint for full reconstruction.

For most use cases (comparison, K-Elimination, residue arithmetic),
full reconstruction is NOT needed — operations happen in residue space.

### Sign Handling
CRTBigInt uses a separate sign bit (i8: -1, 0, or 1) with unsigned
residues storing the absolute value. This means:
- Subtraction of a larger value from a smaller value produces incorrect
  sign when both are positive (the residues wrap correctly but sign
  doesn't track the underflow).
- Mixed-sign addition should be performed as subtraction externally.
- The current implementation works correctly for same-sign operands
  and for values where the sign is tracked externally.

Full signed CRT arithmetic requires either centered representation
(residues in [-M/2, M/2]) or explicit magnitude comparison before
each operation. This is a known limitation documented in the codebase.

### Duplicate Sub-Lane Bases
If absorb() is called twice with denominators sharing a prime factor
(e.g., first absorb with denominator 4=2^2, then with denominator 6=2×3),
the resulting sub-lanes include TWO lanes with base-2 moduli (4 and 2).
These are NOT coprime (gcd(4,2) = 2). The verify_coprimality() method
will catch this, but the caller is responsible for avoiding it. Future
enhancement: merge sub-lanes with shared prime bases automatically.

### Error Bound Conservatism
The multiplication error bound in TriadValue::mul uses a conservative
estimate (eps_a + eps_b scaled by max residue). The true error bound
for the product of two approximate values is tighter:
  |ab_true - ab_approx| ≤ |a|·eps_b + |b|·eps_a + eps_a·eps_b
But since we only have residues (not magnitudes) in the sub-lanes,
we use the residue as a proxy for magnitude. This is conservative
but safe (never underestimates error).

---

## Known Open Problems

### O1: Formal Phase-Lock Proof
Saturation is empirical (N ≤ 500,000). A formal proof requires either:
(a) Hardy-Littlewood singular series with explicit error bounds for
    primes in arithmetic progressions on the CRT torus, or
(b) An equidistribution theorem for primes mod M = ∏basis_primes at
    the specific modulus M = 2310.
The Bombieri-Vinogradov theorem gives equidistribution up to
Q ≈ √N / (log N)^A, which is sufficient for M = 2310 when N > 10^7.
But the explicit constants are not worked out for this specific setting.

### O2: NS Discrete Vector Calculus
The Recombinant Bridge provides the algebraic substrate, but the
specific PDE operators (div, grad, curl, Laplacian) on the CRTBigInt
integer grid have not yet been implemented. This is an engineering task,
not a mathematical one — the operators are well-defined finite differences.

### O3: Continuum Limit Correspondence
Translating a discovery in the discrete CRT space back into a continuum
PDE estimate requires a discrete-to-continuous correspondence theorem.
This does not yet exist for the Recombinant Bridge architecture.

### O4: Automatic Sub-Lane Merging
When multiple absorb() calls produce sub-lanes with shared prime bases,
they should be automatically merged into a single sub-lane with the
LCM of the exponents. Not yet implemented.
