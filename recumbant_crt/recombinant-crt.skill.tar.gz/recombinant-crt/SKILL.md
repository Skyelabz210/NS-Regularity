---
name: recombinant-crt
description: >
  QMNF Recombinant CRT Bridge: exact CRT lanes, 11-smooth composite
  approximation sub-lanes, K-Elimination winding numbers, frozen-error
  propagation, phase-locked lane transfers, Safe Prime Basis {2,3,5,7,11}.
  Use when working with CRTBigInt, TriadValue, ApproxLane, K-Elimination,
  11-smooth factorization, exact-to-approximate bridging, or Recombinant
  CRT architecture. Triggers on: 'CRT lanes', 'triad value', 'absorb
  approximation', 'safe basis', 'phase lock', '11-smooth', 'frozen error',
  'winding number', 'composite modulus', 'denominator factoring', 'operator
  substrate', 'recombinant bridge', 'sub-lane', 'cascade detection'. Always
  use when modifying qmnf_crtbigint, designing CRT lane types, planning NS
  or PDE work in CRT space, or reasoning about error propagation.
---

# Recombinant CRT Bridge — Architecture Skill

Complete reference for the QMNF Recombinant CRT Bridge: the unified exact +
approximate computation space built on Chinese Remainder Theorem lane
architecture with 11-smooth composite base extension.

## Core Philosophy

"Truth cannot be approximated. But approximation can be exactly absorbed."

Approximate values from continuous mathematics enter the CRT space through
denominator-factored quantization, become permanent exact residents, and
never drift. The quantization error is frozen metadata, not growing noise.

## When to Use This Skill

Read this skill BEFORE any work involving:
- CRTBigInt implementation or modification
- TriadValue operations (exact + approximate lanes)
- K-Elimination between any lane types
- 11-smooth factorization or Safe Basis selection
- Error budget analysis through CRT operations
- Designing new approximation lane integrations
- NS, PDE, FHE, or physics simulation on the CRT substrate
- Reasoning about phase-lock boundaries (prime 13 threshold)
- Capacity planning (exponent profiles for Safe Basis composites)

For implementation details, read `references/architecture.md`.
For the constraint/boundary reference, read `references/constraints.md`.

---

## Quick Architecture Reference

### The Three Worlds

**World 1 — Exact Lanes (CRTBigInt):** 8 channels, each mod a 63-bit prime.
Product capacity ≈ 2^504. Fixed `[u64; 8]` array. Add/Sub/Mul/Neg all
componentwise modular. Garner reconstruction for i64 round-trip. Montgomery
exponentiation per lane. Zero drift by construction.

**World 2 — Approximation Sub-Lanes (ApproxLane):** Composite moduli from
the Safe Prime Basis {2, 3, 5, 7, 11}. Created by factoring an approximation's
denominator into prime-power components: d = 2^a × 3^b × 5^c × 7^d × 11^e.
Each factor → one sub-lane. Error frozen at creation. All subsequent CRT
operations on sub-lane residues are exact.

**World 3 — K-Elimination Bridge:** Exact winding-number extraction across
any coprime lane pair. k ≡ (s − r) · m⁻¹ (mod a). Works exact↔exact,
exact↔approx, and approx↔approx. The winding number k is always an exact
integer. Only its physical interpretation inherits quantization error.

### The Recombinant Operation (absorb)

```
INPUT:  scaled_numerator (i64), denominator (u64), epsilon, source
STEP 1: Factor denominator → 2^a × 3^b × 5^c × 7^d × 11^e
STEP 2: Assert fully 11-smooth (cofactor == 1)
STEP 3: Create one ApproxLane per prime-power factor
STEP 4: Encode numerator: residue = numerator % prime^exp
STEP 5: Freeze epsilon (immutable from this point)
STEP 6: All future operations are exact modular arithmetic
```

The denominator dictates the lane structure. You don't choose — you listen.

### Key Invariants

1. **Coprimality:** All exact lane primes > 11. All approx sub-lane moduli
   are powers of {2,3,5,7,11}. By distinct-prime-base theorem, all pairs
   are coprime. Enforced by `verify_coprimality()`.

2. **Frozen Error:** ApproxLane.epsilon is set once at creation and NEVER
   modified by any CRT operation. Error bounds propagate by algebra:
   addition uses triangle inequality (eps_a + eps_b), multiplication
   scales by max residue.

3. **Phase-Lock Saturation:** For sub-lane moduli built from {2,3,5,7,11},
   all triples achieve 100% fiber coverage at N ≈ 5000. Empirically proven
   through 500,000 (Phase 3c CRT torus testing).

4. **11-Smooth Completeness:** Every IEEE 754 denominator (power of 2),
   decimal scale (power of 10), grid spacing (power of 2), and CORDIC scale
   is already 11-smooth. No natural computational denominator requires
   primes above 11.

---

## Operator Interchangeability

ALL operations work across ALL lane types because the CRT ring isomorphism
does not distinguish between exact and approximate lanes. Z/qZ is Z/qZ
regardless of how the residue arrived.

| Operation | Exact↔Exact | Exact↔Approx | Approx↔Approx |
|-----------|:-----------:|:------------:|:--------------:|
| Add/Sub   | exact       | exact (eps adds) | exact (eps adds) |
| Mul       | exact       | exact (eps scales) | exact (eps scales) |
| K-Elim    | exact k     | exact k (meaning inherits eps) | exact k |
| mod_inv   | exact       | exact if gcd=1 | exact if gcd=1 |

---

## The Safe Prime Basis: {2, 3, 5, 7, 11}

### Why These Five

Phase-lock saturation testing (Goldbach CRT torus, N ≤ 500,000) proved:
- All 10 pairs from {3,5,7,11} → 100% coverage
- All 20 triples from {3,5,7,11,13} → 100% coverage
- Including mod-3 is essential (drops from 100% to 70% without it)
- The saturation threshold product(m_i - 1) = 480 for {2,3,5,7,11}

### Why Never Above 11

Capacity comes from EXPONENTS, not from larger primes:

| Profile | Exponents [2,3,5,7,11] | Capacity |
|---------|------------------------|----------|
| Medium  | [10, 6, 4, 3, 2]      | ~2^44    |
| Heavy   | [20, 12, 8, 5, 4]     | ~2^86    |
| Extreme | [32, 20, 14, 11, 8]   | ~2^155   |
| Crypto  | [64, 40, 27, 22, 18]  | ~2^314   |

All pairwise coprime. All phase-locked. Unlimited by raising exponents.

### The Prime-13 Boundary

| Threshold | Coverage | Risk |
|-----------|----------|------|
| Primes ≤ 11 | 100% saturation (proven) | None |
| Prime 13 | 99.32% for quads | Low — near-saturated |
| Prime 17 | 69.97% for quints without mod-3 | Medium |
| Primes > 17 | Decreasing with size | High — use composites |

**Rule:** NEVER use a prime modulus > 11 in approximation sub-lanes.
If higher capacity is needed, raise the exponent on an existing basis prime.

---

## K-Elimination Reference

The fundamental cross-lane operation. Given:
- X ≡ r (mod m) in one lane
- X ≡ s (mod a) in another lane
- gcd(m, a) = 1

Compute: k ≡ (s − r) · m⁻¹ (mod a)
Reconstruct: X = r + k·m (unique for 0 ≤ X < m·a)

The winding number k is:
- Always an exact integer (pure modular arithmetic)
- A topological invariant (counts wrapping events)
- Computable across any coprime pair (exact, approx, or mixed)
- The bridge between scales in multi-resolution analysis

---

## Error Budget Rules

**At quantization (one-time):**
- epsilon ≤ 1/2 (rounding to nearest integer before mod)

**Addition:** eps_result = eps_a + eps_b (triangle inequality)

**Multiplication by exact value:** eps_result = |exact| × eps_approx

**Multiplication of two approx values:**
eps_result ≈ eps_a × |b| + eps_b × |a| + eps_a × eps_b
(conservative: sum scaled by max residue)

**K-Elimination:** k is exact. Physical meaning of k inherits eps from
whichever lane carried approximation.

**Re-quantization:** If time-varying quantity is re-quantized N times,
total error = N × eps_single. Still linear, not multiplicative.

**CRT operations themselves:** ZERO additional error. Ever.

---

## Implementation Map (lib.rs v2)

| Struct/Function | Layer | Purpose |
|----------------|-------|---------|
| `CRTBigInt` | Exact | 8-lane CRT value, [u64; 8] |
| `MontgomeryCtx` | Exact | Precomputed REDC constants per lane |
| `mulmod/addmod/submod` | Primitives | Modular arithmetic building blocks |
| `mod_inverse/newton_inverse` | Primitives | Modular inverse (EEA + Newton) |
| `gcd` | Primitives | Stein's binary GCD |
| `SmoothFactors` | Bridge | 11-smooth factorization result |
| `factor_11_smooth` | Bridge | Decompose into Safe Basis powers |
| `ApproxLane` | Approx | Single prime-power sub-lane |
| `TriadValue` | Unified | Exact + Approx in one CRT space |
| `k_eliminate` | Bridge | Winding number between any coprime pair |
| `KElimResult` | Bridge | k + reconstruction data |
| `MAAElement` | Application | Apollonian quadruple on CRTBigInt |

---

## Application Quick Reference

**Navier-Stokes:** Exact velocity in large-prime lanes. Energy/enstrophy/spectral
in denominator-factored sub-lanes. Cross-lane K-Elimination detects cascade
phase-locking. Winding numbers are candidate missing invariant.

**FHE (NINE65):** Noise bounds become CRT sub-lane residents. Bootstrap
decision: K-Elimination between noise lane and budget lane returns exact
comparison. No float needed.

**ML (RNS-Net):** Loss function in approx lane, gradient in exact lanes.
Gradient is exact; only loss-to-risk relationship carries frozen error.

**Physics (QEDDE):** Koopman truncation error frozen into sub-lane. All
subsequent unitary evolution exact. Zero-drift Lorenz, pendulum, etc.

---

## Anti-Patterns

1. **Using primes > 11 for approx lanes.** Use composite powers instead.
2. **Forgetting coprimality check.** Always verify no exact lane prime
   divides any sub-lane modulus. (Currently guaranteed by construction.)
3. **Treating frozen error as zero.** It's not zero — it's bounded and
   known. Track it. Propagate it. Report it.
4. **Re-quantizing without tracking cumulative error.** Each re-quantization
   event adds eps. Count them.
5. **Comparing exact and approx lane values directly.** Comparison only
   meaningful in context of eps. Use K-Elimination winding numbers instead.
6. **Mixing signed and unsigned carelessly.** CRTBigInt uses separate sign
   bit. ApproxLane stores unsigned residues. Handle sign at boundaries.

---

## Accuracy Checklist (verified against lib.rs tests)

- [x] CRTBigInt from_i64 round-trips for full i64 range (21 tests pass)
- [x] add/sub/mul produce correct results vs native arithmetic
- [x] mod_inverse: a × a⁻¹ ≡ 1 in all 8 lanes
- [x] mod_pow: 17^10 matches native computation
- [x] K-Elimination: k=6 for (42 mod 7, 42 mod 11), reconstruct=42
- [x] factor_11_smooth: correct for 1, 2, 10, 100, 2310, 1024, 10000
- [x] Rejects non-smooth: 13, 17, 26 all return cofactor > 1
- [x] IEEE 754 denominators 2^0 through 2^63: all 11-smooth
- [x] Decimal scales 10^1 through 10^15: all 11-smooth
- [x] TriadValue absorb 31416/10000: creates mod-16 and mod-625 sub-lanes
- [x] TriadValue absorb 42/2310: creates 5 sub-lanes, all pairwise coprime
- [x] Cross K-Elimination: returns valid winding number, k < m_anchor
- [x] TriadValue add: exact=300, error=2 (1+1 triangle inequality)
- [x] try_absorb rejects denominator 13 with cofactor=13
- [x] Safe Basis capacity [25,16,11,9,7]: exceeds 120 bits, all coprime
