# Hydra v2: Carry Spectral Fingerprint and HL Correction Factor

## Innovation ID: HYDRA-CORRECTION
## Date: March 14, 2026 (v1) / March 11, 2026 (v2 integration)
## Status: VERIFIED (5/5 tests, correction factors computed for 5 families)

## Abstract

The ratio F(d,B)/F_product(d,B) -- actual carry-forbidden ratio divided by
the Hardy-Littlewood product approximation -- is a new mathematical
observable measuring carry propagation topology that the singular series
does not encode. The correction factor ranges from 0.49 to 1.71 across
tested families and bases, with systematic patterns.

## Definition (Carry Spectral Fingerprint)

For prime family with gap d and CRT base B = product(p_i):
  F(d,B) = |{forbidden carry patterns}| / |{all carry patterns}|

The fingerprint is the 2D table (base x family -> forbidden ratio).

## Definition (HL Product Approximation)

  F_product(d,B) = 1 - product_p(admissible_p(d) / p)
  where admissible_p(d) = p-1 if p|d, p-2 if p does not divide d

## Definition (Correction Factor)

  C(d,B) = F(d,B) / F_product(d,B)

C = 1: carry topology matches HL independence assumption exactly.
C < 1: carry topology suppresses forbidden patterns (more survival than HL).
C > 1: carry topology enhances forbidden patterns (less survival than HL).

## Theorem H1 (Monotonicity)

For any fixed family, F(d,B) is monotone non-decreasing in |B|.
Larger bases always eliminate at least as many carry patterns.
Verified for all 5 families across 8 bases.

## Theorem H2 (Linear Pair Universality)

For any odd prime p and any linear pair family (r, ar+b) with gcd(a,p)=1:
per-prime survival = (p-2)/p. Universal across all tested families.
Verified for 10 primes x 2 families.

## Theorem H3 (Gap-Divisibility Enhancement)

When p|d: admissible count = p-1 (not p-2). This IS the HL extra factor
product((p-1)/(p-2)) for p|d, derived constructively from the sieve.
Verified for primes {5,7,11,13}.

## Key Correction Factor Data

| Gap | Base | Actual F% | HL Prod% | Correction |
|-----|------|-----------|----------|------------|
| 2 (twin) | 385 | 50.0% | 64.9% | 0.770 |
| 2 (twin) | 1001 | 62.5% | 50.5% | 1.236 |
| 4 (cousin) | 2310 | 93.8% | 94.2% | 0.996 |
| 6 (sexy) | 30030 | 98.4% | 90.1% | 1.092 |
| 210 | 385 | 75.0% | 43.9% | 1.709 |
| 30 | 1001 | 25.0% | 50.5% | 0.495 |

## Champion-30030 Head (v3)

The full Safe Basis {2,3,5,7,11,13} as one Hydra head:
59/64 carry patterns forbidden for twins (92.2%).
Most powerful single topological constraint tested.

## Open: Characterize convergence of C(d,B) as B grows.
Does C -> 1 for all families? Is C systematically != 1 for some?

## Physics Compliance: All operations exact integer arithmetic.
