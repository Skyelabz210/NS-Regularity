#!/usr/bin/env python3
"""
EXECUTABLE MAYA CRT TEST SUITE
Core validation of Ramanujan + Primes + Phi through CRT lanes
"""

import math
from collections import Counter
from typing import List, Tuple, Dict
import time

# ═══════════════════════════════════════════════════════════════════
# PRIMITIVES
# ═══════════════════════════════════════════════════════════════════

def gcd(a: int, b: int) -> int:
    while b: a, b = b, a % b
    return abs(a)

def lcm(a: int, b: int) -> int:
    return abs(a * b) // gcd(a, b) if a and b else 0

def euler_phi(n: int) -> int:
    result, temp = n, n
    p = 2
    while p * p <= temp:
        if temp % p == 0:
            while temp % p == 0: temp //= p
            result -= result // p
        p += 1
    if temp > 1: result -= result // temp
    return result

def mobius(n: int) -> int:
    if n == 1: return 1
    factors = []
    temp, p = n, 2
    while p * p <= temp:
        if temp % p == 0:
            count = 0
            while temp % p == 0:
                temp //= p
                count += 1
            if count > 1: return 0
            factors.append(p)
        p += 1
    if temp > 1: factors.append(temp)
    return (-1) ** len(factors)

def ramanujan_sum(q: int, n: int) -> int:
    g = gcd(q, n)
    q_over_g = q // g
    if q_over_g == 1: return euler_phi(q)
    mu_val = mobius(q_over_g)
    if mu_val == 0: return 0
    return mu_val * euler_phi(q) // euler_phi(q_over_g)

def carmichael_lambda(n: int) -> int:
    """Carmichael function λ(n)"""
    if n == 1: return 1
    if n == 2: return 1
    if n == 4: return 2
    
    # Factor n
    factors = {}
    temp = n
    p = 2
    while p * p <= temp:
        while temp % p == 0:
            factors[p] = factors.get(p, 0) + 1
            temp //= p
        p += 1
    if temp > 1:
        factors[temp] = 1
    
    # λ(n) = lcm of λ(p^k) for each prime power
    result = 1
    for p, k in factors.items():
        if p == 2 and k >= 3:
            lambda_pk = 2 ** (k - 2)
        else:
            lambda_pk = p ** (k - 1) * (p - 1)
        result = lcm(result, lambda_pk)
    
    return result

# ═══════════════════════════════════════════════════════════════════
# MAYA CRT CYCLES
# ═══════════════════════════════════════════════════════════════════

MAYA_CYCLES = {
    'tzolkin':     {'M': 260,     'factors': [4,5,13],        'phi': 96,    'lambda': 12},
    'haab':        {'M': 365,     'factors': [5,73],          'phi': 288,   'lambda': 72},
    'venus':       {'M': 584,     'factors': [8,73],          'phi': 288,   'lambda': 72},
    '819':         {'M': 819,     'factors': [9,7,13],        'phi': 432,   'lambda': 12},
    'eclipse':     {'M': 11960,   'factors': [8,5,13,23],     'phi': 4224,  'lambda': 132},
    'calendar':    {'M': 18980,   'factors': [4,5,13,73],     'phi': 6912,  'lambda': 72},
    'xultun':      {'M': 1195740, 'factors': [4,9,5,7,13,73], 'phi': 248832, 'lambda': 72},
    '210':         {'M': 210,     'factors': [2,3,5,7],       'phi': 48,    'lambda': 12},
    '30030':       {'M': 30030,   'factors': [2,3,5,7,11,13], 'phi': 5760,  'lambda': 60},
}

# ═══════════════════════════════════════════════════════════════════
# TEST HARNESS
# ═══════════════════════════════════════════════════════════════════

class MayaCRTTests:
    def __init__(self):
        self.results = []
        self.start_time = time.time()
    
    def add_result(self, test_name: str, passed: bool, details: str = ""):
        self.results.append({
            'test': test_name,
            'passed': passed,
            'details': details
        })
    
    # ═══════════════════════════════════════════════════════════════
    # TEST 1: MAYA CYCLE PROPERTIES
    # ═══════════════════════════════════════════════════════════════
    
    def test_maya_cycle_properties(self):
        print("\n[TEST 1] Maya Cycle Properties")
        for name, cycle in MAYA_CYCLES.items():
            M = cycle['M']
            
            # Verify φ(M)
            computed_phi = euler_phi(M)
            expected_phi = cycle['phi']
            phi_ok = computed_phi == expected_phi
            
            # Verify λ(M)
            computed_lambda = carmichael_lambda(M)
            expected_lambda = cycle['lambda']
            lambda_ok = computed_lambda == expected_lambda
            
            # Verify factorization
            product = 1
            for f in cycle['factors']:
                product *= f
            factor_ok = product == M
            
            passed = phi_ok and lambda_ok and factor_ok
            
            self.add_result(
                f"Maya cycle {name}",
                passed,
                f"M={M}, φ={computed_phi}/{expected_phi}, λ={computed_lambda}/{expected_lambda}"
            )
            
            if passed:
                print(f"  ✓ {name:12s}: M={M:7d}  φ={computed_phi:5d}  λ={computed_lambda:3d}")
            else:
                print(f"  ✗ {name:12s}: MISMATCH")
    
    # ═══════════════════════════════════════════════════════════════
    # TEST 2: RAMANUJAN SUM PROPERTIES
    # ═══════════════════════════════════════════════════════════════
    
    def test_ramanujan_sums(self):
        print("\n[TEST 2] Ramanujan Sum Properties")
        
        # Test c_q(0) = φ(q)
        for name, cycle in [('tzolkin', MAYA_CYCLES['tzolkin']), 
                            ('819', MAYA_CYCLES['819'])]:
            q = cycle['M']
            c_0 = ramanujan_sum(q, 0)
            phi_q = euler_phi(q)
            
            passed = (c_0 == phi_q)
            self.add_result(f"c_{q}(0) = φ({q})", passed, f"{c_0} vs {phi_q}")
            
            if passed:
                print(f"  ✓ c_{q}(0) = φ({q}) = {phi_q}")
            else:
                print(f"  ✗ c_{q}(0) = {c_0}, expected {phi_q}")
        
        # Test multiplicativity: c_{q1*q2}(n) = c_{q1}(n) * c_{q2}(n)
        test_pairs = [(4, 5), (5, 13), (7, 13)]
        multiplicativity_ok = 0
        multiplicativity_total = 0
        
        for q1, q2 in test_pairs:
            if gcd(q1, q2) == 1:
                for n in range(10):  # Sample
                    c_product = ramanujan_sum(q1 * q2, n)
                    c_factors = ramanujan_sum(q1, n) * ramanujan_sum(q2, n)
                    
                    if c_product == c_factors:
                        multiplicativity_ok += 1
                    multiplicativity_total += 1
        
        mult_passed = multiplicativity_ok == multiplicativity_total
        self.add_result(
            "Ramanujan sum multiplicativity",
            mult_passed,
            f"{multiplicativity_ok}/{multiplicativity_total}"
        )
        print(f"  ✓ Multiplicativity: {multiplicativity_ok}/{multiplicativity_total}")
    
    # ═══════════════════════════════════════════════════════════════
    # TEST 3: CRT DECOMPOSITION
    # ═══════════════════════════════════════════════════════════════
    
    def test_crt_decomposition(self):
        print("\n[TEST 3] CRT Decomposition Verification")
        
        # Test Tzolkin: 260 = 4 × 5 × 13
        tzolkin = MAYA_CYCLES['tzolkin']
        M = tzolkin['M']
        moduli = tzolkin['factors']
        
        # Verify Chinese Remainder Theorem structure
        all_coprime = True
        for i in range(len(moduli)):
            for j in range(i+1, len(moduli)):
                if gcd(moduli[i], moduli[j]) != 1:
                    all_coprime = False
        
        # Verify product
        product = 1
        for m in moduli:
            product *= m
        
        crt_ok = all_coprime and product == M
        
        self.add_result("Tzolkin CRT structure", crt_ok, f"coprime={all_coprime}, product={product}")
        
        if crt_ok:
            print(f"  ✓ Tzolkin = Z/{moduli[0]} × Z/{moduli[1]} × Z/{moduli[2]}")
        
        # Test 819-day: 819 = 9 × 7 × 13
        cycle_819 = MAYA_CYCLES['819']
        moduli_819 = cycle_819['factors']
        
        all_coprime_819 = True
        for i in range(len(moduli_819)):
            for j in range(i+1, len(moduli_819)):
                if gcd(moduli_819[i], moduli_819[j]) != 1:
                    all_coprime_819 = False
        
        self.add_result("819-day CRT structure", all_coprime_819)
        
        if all_coprime_819:
            print(f"  ✓ 819-day = Z/{moduli_819[0]} × Z/{moduli_819[1]} × Z/{moduli_819[2]}")
    
    # ═══════════════════════════════════════════════════════════════
    # TEST 4: DRESDEN ECLIPSE OPTIMALITY
    # ═══════════════════════════════════════════════════════════════
    
    def test_dresden_eclipse(self):
        print("\n[TEST 4] Dresden Eclipse Cycle")
        
        dresden = 11960
        tzolkin = 260
        
        # Test 11960 = 46 × 260
        exact_cycles = dresden // tzolkin
        remainder = dresden % tzolkin
        
        cycles_ok = (exact_cycles == 46) and (remainder == 0)
        
        # Test Ramanujan sum optimality: c_260(11960) = φ(260)
        c_dresden = ramanujan_sum(tzolkin, dresden)
        phi_260 = euler_phi(tzolkin)
        
        optimal = (c_dresden == phi_260)
        
        passed = cycles_ok and optimal
        
        self.add_result(
            "Dresden eclipse optimality",
            passed,
            f"46×260={exact_cycles*tzolkin}, c_260(11960)={c_dresden}, φ(260)={phi_260}"
        )
        
        if passed:
            print(f"  ✓ 11960 = 46 × 260 (exact)")
            print(f"  ✓ c_260(11960) = φ(260) = {phi_260} (φ-optimal)")
    
    # ═══════════════════════════════════════════════════════════════
    # TEST 5: PISANO PERIODS
    # ═══════════════════════════════════════════════════════════════
    
    def test_pisano_periods(self):
        print("\n[TEST 5] Pisano Periods (Fibonacci mod n)")
        
        def pisano_period(m):
            if m == 1: return 1
            f_prev, f_curr = 0, 1
            for i in range(1, m * m + 1):
                f_prev, f_curr = f_curr, (f_prev + f_curr) % m
                if f_prev == 0 and f_curr == 1:
                    return i
            return None
        
        # Known Pisano periods for Maya moduli
        known_periods = {
            4: 6, 5: 20, 7: 16, 8: 12, 9: 24, 13: 28, 23: 48, 73: 148
        }
        
        for m, expected in known_periods.items():
            computed = pisano_period(m)
            passed = computed == expected
            
            self.add_result(f"π({m})", passed, f"{computed} vs {expected}")
            
            if passed:
                print(f"  ✓ π({m:2d}) = {computed:3d}")
            else:
                print(f"  ✗ π({m:2d}) = {computed}, expected {expected}")
        
        # Test CRT multiplicativity: π(260) = lcm(π(4), π(5), π(13))
        pi_4 = pisano_period(4)
        pi_5 = pisano_period(5)
        pi_13 = pisano_period(13)
        
        pi_260_expected = lcm(lcm(pi_4, pi_5), pi_13)
        pi_260_actual = pisano_period(260)
        
        crt_mult = (pi_260_actual == pi_260_expected)
        
        self.add_result("Pisano CRT multiplicativity", crt_mult)
        
        if crt_mult:
            print(f"  ✓ π(260) = lcm(π(4), π(5), π(13)) = lcm({pi_4}, {pi_5}, {pi_13}) = {pi_260_actual}")
    
    # ═══════════════════════════════════════════════════════════════
    # TEST 6: GOLDBACH SINGULAR SERIES STRUCTURE
    # ═══════════════════════════════════════════════════════════════
    
    def test_goldbach_structure(self):
        print("\n[TEST 6] Goldbach Singular Series (Structure Only)")
        
        def goldbach_factor(p, n):
            """Local factor at prime p"""
            if p == 2:
                return 1.0
            if n % p == 0:
                return (p - 1) / (p - 2)
            return 1 - 1/(p - 1)**2
        
        # Test structure on Maya primes
        maya_primes = [2, 3, 5, 7, 13, 73]
        
        # For n=260 (Tzolkin)
        n = 260
        factors = [goldbach_factor(p, n) for p in maya_primes]
        S_partial = 1.0
        for f in factors:
            S_partial *= f
        
        # Structure should be positive and reasonable
        structure_ok = S_partial > 0 and S_partial < 10
        
        self.add_result("Goldbach singular series structure", structure_ok)
        
        if structure_ok:
            print(f"  ✓ S(260) partial product = {S_partial:.6f}")
            print(f"    Factors from primes {maya_primes}")
    
    # ═══════════════════════════════════════════════════════════════
    # TEST 7: COMPOSITE COPRIME K-ELIMINATION
    # ═══════════════════════════════════════════════════════════════
    
    def test_k_elimination(self):
        print("\n[TEST 7] K-Elimination with Composite Anchors (NOVEL)")
        
        def k_elim(v_M, v_A, M, A):
            """κ = (v_A - v_M) · M^{-1} mod A when gcd(M,A)=1"""
            if gcd(M, A) != 1:
                return None
            
            # Find M^{-1} mod A
            def mod_inv(a, m):
                def extended_gcd(a, b):
                    if a == 0: return b, 0, 1
                    g, x1, y1 = extended_gcd(b % a, a)
                    return g, y1 - (b // a) * x1, x1
                
                g, x, _ = extended_gcd(a % m, m)
                if g != 1: return None
                return (x % m + m) % m
            
            M_inv = mod_inv(M, A)
            if M_inv is None:
                return None
            
            return ((v_A - v_M) * M_inv) % A
        
        # Test with composite coprime pair: M=360, A=13
        # 360 = 8×9×5 (composite), 13 (prime), gcd(360,13)=1
        M, A = 360, 13
        V = 5000
        
        v_M = V % M
        v_A = V % A
        
        kappa = k_elim(v_M, v_A, M, A)
        
        if kappa is not None:
            # Verify: V = v_M + κ·M should be ≡ v_A (mod A)
            reconstructed = (v_M + kappa * M) % A
            passed = (reconstructed == v_A)
            
            self.add_result(
                "K-Elimination composite anchor",
                passed,
                f"M=360 (composite), A=13, κ={kappa}"
            )
            
            if passed:
                print(f"  ✓ K-Elimination works for composite M=360, coprime A=13")
                print(f"    κ={kappa}, reconstruction verified")
        else:
            self.add_result("K-Elimination composite anchor", False, "Failed to compute")
    
    # ═══════════════════════════════════════════════════════════════
    # TEST 8: 819-DAY TRIPLE RESONANCE
    # ═══════════════════════════════════════════════════════════════
    
    def test_819_resonance(self):
        print("\n[TEST 8] 819-Day Triple Cosmological Resonance")
        
        # 819 = 7 × 9 × 13 (all pairwise coprime)
        factors = [7, 9, 13]
        
        # Verify pairwise coprimality
        coprime = gcd(7, 9) == 1 and gcd(7, 13) == 1 and gcd(9, 13) == 1
        
        # Verify φ(819) = φ(7)×φ(9)×φ(13) (multiplicativity)
        phi_819 = euler_phi(819)
        phi_product = euler_phi(7) * euler_phi(9) * euler_phi(13)
        
        multiplicative = (phi_819 == phi_product == 432)
        
        # Test resonance: c_819(819) = φ(819)
        c_819_819 = ramanujan_sum(819, 819)
        resonance = (c_819_819 == phi_819)
        
        passed = coprime and multiplicative and resonance
        
        self.add_result("819-day triple resonance", passed)
        
        if passed:
            print(f"  ✓ 819 = 7 × 9 × 13 (pairwise coprime)")
            print(f"  ✓ φ(819) = φ(7)×φ(9)×φ(13) = 6×6×12 = 432")
            print(f"  ✓ c_819(819) = φ(819) = {phi_819} (perfect resonance)")
    
    # ═══════════════════════════════════════════════════════════════
    # TEST 9: GOLDEN RATIO φ³ THRESHOLD
    # ═══════════════════════════════════════════════════════════════
    
    def test_golden_ratio(self):
        print("\n[TEST 9] Golden Ratio φ³ Consciousness Threshold")
        
        phi = (1 + math.sqrt(5)) / 2
        phi_cubed = phi ** 3
        
        # φ³ = 2φ + 1 (algebraic identity)
        algebraic = 2 * phi + 1
        
        tolerance = 1e-10
        identity_ok = abs(phi_cubed - algebraic) < tolerance
        
        # Expected value ≈ 4.236067977
        expected = 4.236067977
        value_ok = abs(phi_cubed - expected) < 1e-8
        
        passed = identity_ok and value_ok
        
        self.add_result("φ³ consciousness threshold", passed)
        
        if passed:
            print(f"  ✓ φ³ = {phi_cubed:.10f}")
            print(f"  ✓ φ³ = 2φ + 1 identity verified")
            print(f"  ✓ Maya Tone 4 = φ⁴ = {phi**4:.6f} exceeds threshold")
    
    # ═══════════════════════════════════════════════════════════════
    # SUMMARY
    # ═══════════════════════════════════════════════════════════════
    
    def run_all_tests(self):
        print("="*80)
        print("MAYA CRT COMPREHENSIVE TEST SUITE")
        print("Testing 2000-year-old Mayan computational mathematics")
        print("="*80)
        
        self.test_maya_cycle_properties()
        self.test_ramanujan_sums()
        self.test_crt_decomposition()
        self.test_dresden_eclipse()
        self.test_pisano_periods()
        self.test_goldbach_structure()
        self.test_k_elimination()
        self.test_819_resonance()
        self.test_golden_ratio()
        
        elapsed = time.time() - self.start_time
        
        print("\n" + "="*80)
        print("TEST SUMMARY")
        print("="*80)
        
        total = len(self.results)
        passed = sum(1 for r in self.results if r['passed'])
        failed = total - passed
        
        print(f"\nTotal tests: {total}")
        print(f"Passed: {passed} ({100*passed/total:.1f}%)")
        print(f"Failed: {failed}")
        
        if failed > 0:
            print("\nFailed tests:")
            for r in self.results:
                if not r['passed']:
                    print(f"  ✗ {r['test']}: {r['details']}")
        
        print(f"\nExecution time: {elapsed:.3f}s")
        print("="*80)
        
        if passed == total:
            print("\n🎉 ALL TESTS PASSED - MAYA CRT FRAMEWORK VALIDATED")
            print("Truth cannot be approximated. ∞ 🌀 🐢")
        
        return {
            'total': total,
            'passed': passed,
            'failed': failed,
            'rate': passed / total,
            'time': elapsed
        }

# ═══════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    harness = MayaCRTTests()
    results = harness.run_all_tests()
    
    import sys
    sys.exit(0 if results['failed'] == 0 else 1)
