# Recombinant CRT Bridge - Skill Reference (v3)

## Core Philosophy

Exact absorption of approximation into CRT space. Approximate values
enter through denominator-factored quantization into Safe Basis composite
sub-lanes. Error is frozen at absorption and never grows. A single large
prime anchor provides O(1) magnitude recovery. WASSAN bands decompose
summit-scale numbers into L1-cache execution lanes. PLMG rails/voids give
free O(1) error detection. The Double Helix provides dual-strand
compute-verify with zero contention.

"Truth cannot be approximated. But approximation can be exactly absorbed."

---

## Quick Architecture Reference

### The Seven Layers

| Layer | Name | Function | Key Property |
|-------|------|----------|-------------|
| 0 | Modular Primitives | mulmod, addmod, gcd, mod_inverse | O(1) exact operations |
| 1 | Exact CRT Lanes | 8 x 63-bit primes, ~504-bit capacity | Zero drift, core computation |
| 2 | Safe Basis Composites | {2,3,5,7,11,13} power sub-lanes | Phase-locked, frozen error |
| 3 | Safe Anchor | Single large prime P | O(1) magnitude, overflow detection |
| 4 | WASSAN Bands | 144 phi-harmonic execution lanes | L1-cache per band, parallel |
| 5 | PLMG Rails/Voids | 28% rails, 72% voids per band | O(1) free error detection |
| 6 | Double Helix | Dual-strand compute + verify | Simultaneous R/W, phi-phase separation |

### The Recombinant Operation

1. Express approximation as n/d (rational form)
2. Factor d into Safe Basis powers: d = 2^a x 3^b x 5^c x 7^d x 11^e x 13^f
3. Create one sub-lane per prime-power factor (automatically coprime)
4. Encode residue: r_{p^k} = n mod p^k
5. Freeze error epsilon - NEVER grows again
6. K-Eliminate against anchor for magnitude recovery

### Safe Anchor (Layer 3)

One large prime P (coprime to all Safe Basis composites by primality).
K-Elimination between composite product M_safe and P recovers the global
winding number k such that X = r_safe + k * M_safe. Cost: O(1).

Recommended anchors: P = 2^31-1 (general), P = 2^61-1 (precision),
P = 2^63-25 (CRTBigInt native), P = 2^136,279,841-1 (summit).

### Infinite Scaffold

The anchor is not a ceiling. Each new prime multiplies capacity.
Euclid guarantees the next prime. Composite coprimes of P-1
provide cross-brace scaffolding. The recursion has no ceiling.

### Key Invariants

- Coprimality: every layer coprime to every other layer
- Frozen Error: epsilon set once at absorption, never modified
- Phase Lock: Safe Basis quintuple 3x5x7x11x13 at 100% saturation
- Self-Similarity: same pattern (decompose, compute, K-Eliminate) at every scale

---

## Safe Prime Basis (v3): {2, 3, 5, 7, 11, 13}

Product at exp=1: 30,030 (primorial 13#). 13x capacity vs 5-prime basis.
Quintuple 3x5x7x11x13: 100% saturation at 5,760 cells (N <= 500,000).
Primes <= 13: phase-lock proven. Prime 17 without mod-3: 69.97%.

### Capacity Profiles

| Profile | Exponents [2,3,5,7,11,13] | Bits |
|---------|--------------------------|------|
| Minimal | [1,1,1,1,1,1] | 14.9 |
| Light | [4,3,2,2,1,1] | 26.2 |
| Heavy | [10,6,4,3,2,1] | 47.8 |
| Crypto | [64,40,27,22,18,14] | 365.9 |

---

## K-Elimination Reference

Formula: k = (r_anchor - r_main) * m_main^{-1} (mod m_anchor)
Reconstruction: X = r_main + k * m_main
Requirement: gcd(m_main, m_anchor) = 1

Works between: exact-exact, exact-approx, approx-approx,
composite-anchor, band-band. Same operation at every scale.

---

## WASSAN Band Reference

144 bands (F_12). Each band is an independent execution lane.
Band-domain modular arithmetic avoids full reconstruction.
WASSAN-CRT isomorphism: coprime moduli = phi-harmonic frequencies.

---

## PLMG Rails/Voids

28% rails (valid), 72% voids (instant error detection). O(1) check.

---

## Double Helix

Strand A computes. Strand B verifies previous. Mobius twist every 2 steps.
Golden ratio phase offset guarantees zero-contention R/W.

---

## Error Budget

- Addition: eps_a + eps_b
- Multiplication: eps_a*|b| + eps_b*|a| + eps_a*eps_b
- CRT operations: ZERO additional error
- K-Elimination: ZERO error
- WASSAN decomposition: ZERO error

---

## Anti-Patterns

1. NEVER use a prime > 13 in the Safe Basis
2. NEVER modify epsilon after absorption
3. NEVER mix sub-lane bases (2^a and 2^b violates coprimality)
4. NEVER skip coprimality checks for custom sub-lanes
5. NEVER reconstruct full number when band-domain suffices
6. NEVER use multiple anchors (one suffices)

---

## Implementation: qmnf_crtbigint v3 (Rust)

40/40 tests passing. Key types: CRTBigInt, TriadValue, ApproxLane,
SafeAnchor, WassanBanded, PLMGValidator, DoubleHelix<T>, InfiniteScaffold,
SmoothFactors, KElimResult.

Triggers: CRTBigInt, TriadValue, ApproxLane, K-Elimination, 13-smooth,
frozen error, winding number, composite modulus, denominator factoring,
operator substrate, recombinant bridge, sub-lane, cascade detection,
safe basis, phase lock, safe anchor, WASSAN bands, PLMG rails, voids,
double helix, scaffold, summit, Mersenne anchor.
